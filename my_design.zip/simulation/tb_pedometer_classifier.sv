// =============================================================================
// tb_pedometer_classifier.sv
// Testbench for Pedometer & Leg-Shaking / Activity Classifier
// =============================================================================

`timescale 1ns/1ps

module tb_pedometer_classifier;

  logic clk = 0;
  logic rst_n = 0;
  logic en = 1;

  logic sample_valid = 0;
  logic signed [15:0] ax = 0, ay = 0, az = 0;
  logic [15:0] feat_mag = 0;
  logic [15:0] feat_zcr = 0;

  logic shake_filter_en = 1;
  logic [15:0] step_thresh = 16'd1000;
  logic [15:0] run_thresh = 16'd3000;
  logic [15:0] min_period = 16'd10;  // 10 samples
  logic [15:0] max_period = 16'd50;  // 50 samples
  logic clear_counters = 0;

  logic [2:0]  activity_class;
  logic        step_detected;
  logic        shake_detected;
  logic [31:0] total_steps;
  logic [31:0] walk_steps;
  logic [31:0] run_steps;
  logic [31:0] shake_events;
  logic [31:0] shake_duration;
  logic [31:0] active_time;
  logic [15:0] cadence_spm;

  int errors = 0;

  pedometer_classifier #(
    .DATA_W(16),
    .DEFAULT_STEP_THRESH(16'd1000),
    .DEFAULT_RUN_THRESH(16'd3000),
    .DEFAULT_MIN_STEP_PER(10),
    .DEFAULT_MAX_STEP_PER(50)
  ) dut (
    .clk_i                (clk),
    .rst_ni               (rst_n),
    .en_i                 (en),
    .sample_valid_i       (sample_valid),
    .accel_x_i            (ax),
    .accel_y_i            (ay),
    .accel_z_i            (az),
    .feat_magnitude_i     (feat_mag),
    .feat_zcr_i           (feat_zcr),
    .shake_filter_en_i    (shake_filter_en),
    .step_threshold_i     (step_thresh),
    .run_threshold_i      (run_thresh),
    .min_step_period_i    (min_period),
    .max_step_period_i    (max_period),
    .clear_counters_i     (clear_counters),
    .activity_class_o     (activity_class),
    .step_detected_o      (step_detected),
    .shake_detected_o     (shake_detected),
    .step_count_total_o   (total_steps),
    .step_count_walk_o    (walk_steps),
    .step_count_run_o     (run_steps),
    .shake_event_count_o  (shake_events),
    .shake_duration_sec_o (shake_duration),
    .active_time_sec_o    (active_time),
    .cadence_spm_o        (cadence_spm)
  );

  always #5 clk = ~clk;

  task automatic check(string name, logic cond);
    if (!cond) begin
      $display("[FAIL] %s @ t=%0t", name, $time);
      errors++;
    end else begin
      $display("[PASS] %s", name);
    end
  endtask

  task automatic feed_sample(input logic signed [15:0] x, y, z, input logic [15:0] mag, input logic [15:0] zcr);
    @(posedge clk);
    #1;
    ax = x; ay = y; az = z; feat_mag = mag; feat_zcr = zcr; sample_valid = 1;
    @(posedge clk);
    #1;
    sample_valid = 0;
  endtask

  task automatic generate_cycle(input int num_samples, input int peak_mag, input logic is_single_axis);
    for (int i = 0; i < num_samples; i++) begin
      int mag_val;
      if (i < (num_samples / 2)) begin
        mag_val = (peak_mag * (i + 1)) / (num_samples / 2);
      end else begin
        mag_val = peak_mag - ((peak_mag * (i - (num_samples / 2) + 1)) / (num_samples / 2));
        if (mag_val < 0) mag_val = 0;
      end

      if (is_single_axis) begin
        feed_sample(16'sd20, 16'sd15, 16'(mag_val), 16'(mag_val), 16'd32);
      end else begin
        feed_sample(16'(mag_val / 2), 16'(-mag_val / 3), 16'(mag_val), 16'(mag_val), 16'd8);
      end
    end
  endtask

  initial begin
    rst_n = 0;
    repeat (4) @(posedge clk);
    rst_n = 1;
    repeat (2) @(posedge clk);

    $display("--- Test 1: Rest / Still Baseline ---");
    for (int i = 0; i < 20; i++) begin
      feed_sample(16'sd10, 16'sd20, 16'sd50, 16'd100, 16'd0);
    end
    check("Rest baseline: zero steps counted", total_steps == 0);
    check("Rest baseline: activity class is REST(0)", activity_class == 3'd0);

    $display("\n--- Test 2: Rhythmic Leg Shaking / Fidgeting (Fast 5-sample bounces) ---");
    // Generate 15 rapid shake cycles (5 samples/cycle, faster than min_period = 10)
    for (int c = 0; c < 15; c++) begin
      generate_cycle(5, 2200, 1'b1);
    end
    repeat (2) @(posedge clk);

    check("Leg shaking rejection: total_steps remains 0", total_steps == 0);
    check("Leg shaking rejection: walk_steps remains 0", walk_steps == 0);
    check("Leg shaking detected: activity class is ACT_LEG_SHAKE(1)", activity_class == 3'd1);
    check("Leg shaking logged: shake_events > 0", shake_events > 0);
    $display("INFO: Leg shake events logged = %0d, shake duration = %0d", shake_events, shake_duration);

    $display("\n--- Test 3: Normal Walking (Cadence ~20 samples/step, within window [10..50]) ---");
    // Generate 8 consecutive walking strides
    for (int c = 0; c < 8; c++) begin
      generate_cycle(20, 1800, 1'b0);
    end
    repeat (2) @(posedge clk);

    check("Walking: 4-step confirmation locked and steps incremented", total_steps >= 4);
    check("Walking: walk_steps incremented", walk_steps >= 4);
    check("Walking: activity class is ACT_WALK(2)", activity_class == 3'd2);
    check("Walking: run_steps is 0", run_steps == 0);
    $display("INFO: Total steps after walking = %0d (walk=%0d, run=%0d)", total_steps, walk_steps, run_steps);

    $display("\n--- Test 4: Jogging / Running (High impact 3500 mag, 14 samples/step) ---");
    for (int c = 0; c < 6; c++) begin
      generate_cycle(14, 3500, 1'b0);
    end
    repeat (2) @(posedge clk);

    check("Running: total_steps incremented further", total_steps >= 10);
    check("Running: run_steps incremented", run_steps >= 4);
    check("Running: activity class is ACT_RUN(3)", activity_class == 3'd3);
    $display("INFO: Total steps after running = %0d (walk=%0d, run=%0d)", total_steps, walk_steps, run_steps);

    $display("\n--- Test 5: Counter Clear Command ---");
    @(posedge clk);
    clear_counters = 1;
    feed_sample(0, 0, 0, 0, 0);
    clear_counters = 0;
    repeat (2) @(posedge clk);
    check("Counters cleared to zero", total_steps == 0 && walk_steps == 0 && run_steps == 0);

    if (errors == 0) $display("\n=== ALL PEDOMETER CLASSIFIER TESTS PASSED ===");
    else $display("\n=== %0d TEST(S) FAILED ===", errors);

    $finish;
  end

  initial begin
    #200000;
    $display("[FAIL] TIMEOUT");
    $finish;
  end

endmodule
