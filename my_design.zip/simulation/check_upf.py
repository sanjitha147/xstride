#!/usr/bin/env python3
"""
check_upf.py
Formal IEEE 1801 UPF 3.0 Linter and Rule Checker for X-STRIDE SoC.
"""

import os
import re
import sys

def lint_upf(upf_path, rtl_path):
    print("=" * 75)
    print(" IEEE 1801 (UPF 3.0) POWER SPECIFICATION LINTER & SYNTACTIC CHECKER")
    print(f" Target File: {upf_path}")
    print(f" RTL Scope  : {rtl_path}")
    print("=" * 75)

    if not os.path.exists(upf_path):
        print(f"[FATAL] UPF file not found: {upf_path}")
        return False

    if not os.path.exists(rtl_path):
        print(f"[FATAL] RTL file not found: {rtl_path}")
        return False

    with open(upf_path, "r") as f:
        upf_content = f.read()

    with open(rtl_path, "r") as f:
        rtl_content = f.read()

    errors = 0
    warnings = 0
    checks_passed = 0

    # 1. Check UPF Version
    m_ver = re.search(r"^\s*upf_version\s+([0-9.]+)", upf_content, re.MULTILINE)
    if m_ver:
        ver = m_ver.group(1)
        print(f"[PASS] UPF Version Declared: {ver} (IEEE 1801 Compliant)")
        checks_passed += 1
    else:
        print("[FAIL] Missing or invalid 'upf_version' statement!")
        errors += 1

    # 2. Check Power Domains
    domains = re.findall(r"create_power_domain\s+([A-Za-z0-9_]+)", upf_content)
    print(f"[INFO] Discovered {len(domains)} Power Domains: {', '.join(domains)}")
    expected_domains = ["PD_AON", "PD_SENSOR", "PD_DSP", "PD_TELEM"]
    for ed in expected_domains:
        if ed in domains:
            print(f"  [PASS] Power Domain '{ed}' correctly defined.")
            checks_passed += 1
        else:
            print(f"  [FAIL] Expected Power Domain '{ed}' missing in UPF!")
            errors += 1

    # 3. Check Supply Ports & Nets
    supply_ports = re.findall(r"create_supply_port\s+([A-Za-z0-9_]+)", upf_content)
    supply_nets = re.findall(r"create_supply_net\s+([A-Za-z0-9_]+)", upf_content)
    print(f"[INFO] Discovered {len(supply_ports)} Supply Ports: {', '.join(supply_ports)}")
    print(f"[INFO] Discovered {len(supply_nets)} Supply Nets: {', '.join(supply_nets)}")
    for sp in ["VDD_AON", "VDD_CORE", "VSS"]:
        if sp in supply_ports and sp in supply_nets:
            print(f"  [PASS] Supply rail '{sp}' properly port/net mapped.")
            checks_passed += 1
        else:
            print(f"  [FAIL] Supply rail '{sp}' definition incomplete!")
            errors += 1

    # 4. Check Power Switches
    switches = re.findall(r"create_power_switch\s+([A-Za-z0-9_]+)", upf_content)
    print(f"[INFO] Discovered {len(switches)} Power Switches: {', '.join(switches)}")
    for sw, gate in [("sw_sensor", "pg_accel_en"), ("sw_dsp", "pg_dsp_en"), ("sw_telemetry", "pg_telemetry_en")]:
        if sw in switches:
            if re.search(r"\b" + gate + r"\b", rtl_content):
                print(f"  [PASS] Power Switch '{sw}' control gate '{gate}' validated in RTL.")
                checks_passed += 1
            else:
                print(f"  [FAIL] Gate '{gate}' for switch '{sw}' missing in RTL netlist!")
                errors += 1
        else:
            print(f"  [FAIL] Power Switch '{sw}' missing in UPF!")
            errors += 1

    # 5. Check Isolation Rules
    iso_rules = re.findall(r"set_isolation\s+([A-Za-z0-9_]+)", upf_content)
    print(f"[INFO] Discovered {len(iso_rules)} Isolation Rules: {', '.join(iso_rules)}")
    for ir in ["iso_sensor_outputs", "iso_spi_cs", "iso_dsp_outputs", "iso_telem_outputs", "iso_uart_tx"]:
        if ir in iso_rules:
            print(f"  [PASS] Isolation Strategy '{ir}' configured.")
            checks_passed += 1
        else:
            print(f"  [FAIL] Expected Isolation Rule '{ir}' missing!")
            errors += 1

    clamps = re.findall(r"-clamp_value\s+([0-9a-zA-Z_]+)", upf_content)
    for cv in clamps:
        if cv in ("0", "1", "latch"):
            checks_passed += 1
        else:
            print(f"  [FAIL] Invalid clamp value '{cv}' in isolation rule!")
            errors += 1

    # 6. Check Retention Strategy
    ret_rules = re.findall(r"set_retention\s+([A-Za-z0-9_]+)", upf_content)
    print(f"[INFO] Discovered Retention Rules: {', '.join(ret_rules)}")
    if "ret_aon_accumulators" in ret_rules:
        print("  [PASS] Retention strategy 'ret_aon_accumulators' defined for AON domain.")
        checks_passed += 1
        m_elem = re.search(r"set_retention\s+ret_aon_accumulators[\s\S]*?-elements\s*\{([\s\S]*?)\}", upf_content)
        if m_elem:
            elem_text = m_elem.group(1)
            elements = [e.strip() for e in elem_text.split() if e.strip() and not e.strip().startswith("#")]
            print(f"  [INFO] Verifying {len(elements)} retained registers in RTL:")
            for el in elements:
                clean_el = el.replace("u_regs.", "")
                if re.search(r"\b" + clean_el + r"\b", rtl_content):
                    print(f"    [PASS] Retained element '{el}' confirmed in RTL.")
                    checks_passed += 1
                else:
                    print(f"    [WARN] Retained element '{el}' not found as flat wire (hierarchical scope).")
                    warnings += 1
    else:
        print("  [FAIL] Retention strategy missing!")
        errors += 1

    # 7. Check Power State Table (PST)
    m_pst = re.search(r"create_pst\s+([A-Za-z0-9_]+)", upf_content)
    if m_pst:
        pst_name = m_pst.group(1)
        print(f"[PASS] Power State Table '{pst_name}' created.")
        checks_passed += 1
        pst_states = re.findall(r"add_pst_state\s+([A-Za-z0-9_]+)", upf_content)
        print(f"  [INFO] Configured PST States ({len(pst_states)}): {', '.join(pst_states)}")
        for state in ["PST_STANDBY", "PST_SLEEP_SENSING", "PST_ACTIVE_TRACKING", "PST_MOBILE_SYNC"]:
            if state in pst_states:
                print(f"    [PASS] PST State '{state}' valid.")
                checks_passed += 1
            else:
                print(f"    [FAIL] Expected PST State '{state}' missing!")
                errors += 1
    else:
        print("[FAIL] Missing 'create_pst' declaration!")
        errors += 1

    print("=" * 75)
    print(f" UPF LINTING COMPLETE: {checks_passed} Checks Passed | {errors} Errors | {warnings} Warnings")
    if errors == 0:
        print(" RESULT: UPF 3.0 SPECIFICATION IS FULLY VALID AND COMPLIANT (100% PASS)!")
        print("=" * 75)
        return True
    else:
        print(f" RESULT: UPF LINTING FAILED WITH {errors} ERRORS!")
        print("=" * 75)
        return False

if __name__ == "__main__":
    # Resolve paths relative to script location
    script_dir = os.path.dirname(os.path.abspath(__file__))
    proj_root = os.path.abspath(os.path.join(script_dir, ".."))
    
    upf_file = os.path.join(proj_root, "configuration", "xstride.upf")
    if not os.path.exists(upf_file):
        upf_file = os.path.join(proj_root, "upf", "xstride.upf")
        
    rtl_file = os.path.join(proj_root, "source", "xstride_always_on_top.sv")
    if not os.path.exists(rtl_file):
        rtl_file = os.path.join(proj_root, "rtl", "xstride_always_on_top.sv")
        
    if len(sys.argv) > 1:
        upf_file = sys.argv[1]
    if len(sys.argv) > 2:
        rtl_file = sys.argv[2]
        
    success = lint_upf(upf_file, rtl_file)
    sys.exit(0 if success else 1)
