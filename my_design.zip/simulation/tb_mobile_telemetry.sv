// =============================================================================
// tb_mobile_telemetry.sv
// Testbench for Headless Low-Power Mobile App Telemetry Unit
// =============================================================================

`timescale 1ns/1ps

module tb_mobile_telemetry;

  logic clk = 0;
  logic rst_n = 0;
  logic en = 1;

  logic        step_pulse = 0;
  logic        shake_pulse = 0;
  logic [2:0]  act_class = 3'd2; // WALK
  logic [31:0] tot_steps = 32'd105;
  logic [31:0] walk_steps = 32'd105;
  logic [31:0] run_steps = 32'd0;
  logic [31:0] shake_events = 32'd2;
  logic [31:0] shake_dur = 32'd30;
  logic [15:0] cadence_spm = 16'd112;
  logic [15:0] feat_mag = 16'd1600;

  logic        uart_tx;
  logic        uart_rx = 1'b1;
  logic        mobile_wake;
  logic        mobile_wake_in = 0;

  logic        stream_en = 1;
  logic        fifo_pop = 0;
  logic [31:0] fifo_rdata;
  logic [7:0]  fifo_count;
  logic        fifo_empty;
  logic        fifo_full;
  logic        clear_counters;

  int errors = 0;

  mobile_telemetry_unit #(
    .CLK_FREQ_HZ(50_000_000),
    .BAUD_RATE  (5_000_000),
    .FIFO_DEPTH (8)
  ) dut (
    .clk_i                (clk),
    .rst_ni               (rst_n),
    .en_i                 (en),
    .step_pulse_i         (step_pulse),
    .shake_pulse_i        (shake_pulse),
    .activity_class_i     (act_class),
    .step_count_total_i   (tot_steps),
    .step_count_walk_i    (walk_steps),
    .step_count_run_i     (run_steps),
    .shake_event_count_i  (shake_events),
    .shake_duration_sec_i (shake_dur),
    .cadence_spm_i        (cadence_spm),
    .feat_magnitude_i     (feat_mag),
    .uart_tx_o            (uart_tx),
    .uart_rx_i            (uart_rx),
    .mobile_wake_o        (mobile_wake),
    .mobile_wake_i        (mobile_wake_in),
    .stream_en_i          (stream_en),
    .fifo_pop_i           (fifo_pop),
    .fifo_rdata_o         (fifo_rdata),
    .fifo_count_o         (fifo_count),
    .fifo_empty_o         (fifo_empty),
    .fifo_full_o          (fifo_full),
    .clear_counters_o     (clear_counters)
  );

  always #5 clk = ~clk;

  task automatic check(string name, logic cond);
    if (!cond) begin
      $display("[FAIL] %s @ t=%0t", name, $time);
      errors++;
    end else begin
      $display("[PASS] %s", name);
    end
  endtask

  task automatic send_uart_byte(input logic [7:0] data);
    uart_rx = 1'b0;
    repeat (10) @(posedge clk);
    for (int b = 0; b < 8; b++) begin
      uart_rx = data[b];
      repeat (10) @(posedge clk);
    end
    uart_rx = 1'b1;
    repeat (10) @(posedge clk);
  endtask

  task automatic recv_uart_byte(output logic [7:0] data);
    @(negedge uart_tx);
    repeat (5) @(posedge clk);
    for (int b = 0; b < 8; b++) begin
      repeat (10) @(posedge clk);
      data[b] = uart_tx;
    end
    repeat (10) @(posedge clk);
  endtask

  logic [7:0] rx_byte0, rx_byte1, rx_byte2;

  initial begin
    rst_n = 0;
    repeat (3) @(posedge clk);
    rst_n = 1;
    repeat (2) @(posedge clk);

    check("Boot: UART TX idle high", uart_tx == 1'b1);
    check("Boot: FIFO is empty", fifo_empty == 1'b1);

    // Test 1: Telemetry Packet transmission on step event
    fork
      begin
        @(posedge clk);
        #1;
        step_pulse = 1'b1;
        @(posedge clk);
        #1;
        step_pulse = 1'b0;
      end
      begin
        recv_uart_byte(rx_byte0);
        recv_uart_byte(rx_byte1);
        recv_uart_byte(rx_byte2);
      end
    join

    check("Telemetry Packet Header Byte 0 is 0xAA", rx_byte0 == 8'hAA);
    check("Telemetry Packet Header Byte 1 is 0x55", rx_byte1 == 8'h55);
    check("Telemetry Packet Length Byte is 26", rx_byte2 == 8'd26);
    check("FIFO buffered step count", fifo_count == 8'd1 && fifo_rdata == 32'd105);

    // Test 2: Mobile App Command CMD_CLEAR_COUNTERS (0x11)
    repeat (10) @(posedge clk);
    fork
      send_uart_byte(8'h11);
      begin
        @(posedge clear_counters);
        check("Mobile App Command 0x11 asserts clear_counters", clear_counters == 1'b1);
      end
    join

    // Test 3: FIFO Pop
    @(posedge clk);
    #1;
    fifo_pop = 1'b1;
    @(posedge clk);
    #1;
    fifo_pop = 1'b0;
    repeat (2) @(posedge clk);
    check("FIFO empty after pop", fifo_empty == 1'b1);

    if (errors == 0) $display("\n=== ALL MOBILE TELEMETRY TESTS PASSED ===");
    else $display("\n=== %0d TEST(S) FAILED ===", errors);

    $finish;
  end

  initial begin
    #200000;
    $display("[FAIL] TIMEOUT");
    $finish;
  end

endmodule
