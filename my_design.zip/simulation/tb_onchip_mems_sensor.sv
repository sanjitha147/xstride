// =============================================================================
// tb_onchip_mems_sensor.sv
// Testbench for Integrated On-Chip MEMS Accelerometer & ADC Subsystem
// =============================================================================

`timescale 1ns/1ps

module tb_onchip_mems_sensor;

  logic clk = 0;
  logic rst_n = 0;
  logic en = 1;

  logic signed [15:0] analog_x = 16'sd1000;
  logic signed [15:0] analog_y = -16'sd2000;
  logic signed [15:0] analog_z = 16'sd4000;

  logic        self_test_en = 0;
  logic [1:0]  range_sel = 2'b00; // +/-2g
  logic signed [15:0] trim_x = 0;
  logic signed [15:0] trim_y = 0;
  logic signed [15:0] trim_z = 0;

  logic        sample_valid;
  logic signed [15:0] ax, ay, az;
  logic        self_test_ready;

  int errors = 0;

  onchip_mems_sensor #(
    .SAMPLE_PERIOD_CYCLES(20)
  ) dut (
    .clk_i             (clk),
    .rst_ni            (rst_n),
    .en_i              (en),
    .mems_analog_x_i   (analog_x),
    .mems_analog_y_i   (analog_y),
    .mems_analog_z_i   (analog_z),
    .self_test_en_i    (self_test_en),
    .range_sel_i       (range_sel),
    .trim_x_i          (trim_x),
    .trim_y_i          (trim_y),
    .trim_z_i          (trim_z),
    .sample_valid_o    (sample_valid),
    .accel_x_o         (ax),
    .accel_y_o         (ay),
    .accel_z_o         (az),
    .self_test_ready_o (self_test_ready)
  );

  always #5 clk = ~clk;

  task automatic check(string name, logic cond);
    if (!cond) begin
      $display("[FAIL] %s @ t=%0t", name, $time);
      errors++;
    end else begin
      $display("[PASS] %s", name);
    end
  endtask

  initial begin
    rst_n = 0;
    repeat (3) @(posedge clk);
    rst_n = 1;
    repeat (2) @(posedge clk);

    // Test 1: Standard digitization
    @(posedge sample_valid);
    #1;
    check("On-Chip ADC X matches input", ax == 16'sd1000);
    check("On-Chip ADC Y matches input", ay == -16'sd2000);
    check("On-Chip ADC Z matches input", az == 16'sd4000);

    // Test 2: Zero-g Trim calibration
    @(posedge clk);
    trim_x = 16'sd100;
    trim_y = -16'sd50;
    @(posedge sample_valid);
    #1;
    check("Zero-g trim applied to X", ax == 16'sd1100);
    check("Zero-g trim applied to Y", ay == -16'sd2050);

    // Test 3: Range scaling (4g mode)
    @(posedge clk);
    range_sel = 2'b01; // divide by 2
    @(posedge sample_valid);
    #1;
    check("Range scaling 4g applies 1-bit right shift", ax == 16'sd550);

    // Test 4: Electrostatic Self-Test
    @(posedge clk);
    range_sel    = 2'b00;
    trim_x       = '0;
    trim_y       = '0;
    self_test_en = 1'b1;
    @(posedge sample_valid);
    #1;
    check("Self-test deflects proof-mass by +4096 counts", ax == (16'sd1000 + 16'sd4096));
    check("Self-test ready flag asserts", self_test_ready == 1'b1);

    if (errors == 0) $display("\n=== ALL ON-CHIP MEMS SENSOR TESTS PASSED ===");
    else $display("\n=== %0d TEST(S) FAILED ===", errors);

    $finish;
  end

  initial begin
    #20000;
    $display("[FAIL] TIMEOUT");
    $finish;
  end

endmodule
