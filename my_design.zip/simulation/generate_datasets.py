#!/usr/bin/env python3
"""
generate_datasets.py
Generates realistic 50 Hz ODR human biomechanical accelerometer dataset files (.mem)
modeling clinical activity profiles (WISDM / UCI-HAR benchmarks).

Output Format:
  12-character hex words: {X[15:0], Y[15:0], Z[15:0]} (48 bits per sample)
"""

import math
import os

def clamp_s16(val):
    v = int(round(val))
    if v > 32767: v = 32767
    if v < -32768: v = -32768
    return v & 0xFFFF

def sample_to_hex(x, y, z):
    hx = clamp_s16(x)
    hy = clamp_s16(y)
    hz = clamp_s16(z)
    return f"{hx:04X}{hy:04X}{hz:04X}"

def generate_leg_shake(num_samples=192):
    # 4.2 Hz vertical knee tremor, Z-dominant, rapid period ~12 samples at 50 Hz
    lines = []
    freq = 4.2
    odr = 50.0
    for i in range(num_samples):
        t = i / odr
        envelope = 0.8 + 0.2 * math.sin(2 * math.pi * 0.5 * t)
        z = 1000 + 1500 * envelope * math.sin(2 * math.pi * freq * t)
        x = 35 * math.sin(2 * math.pi * 1.1 * t)
        y = 30 * math.cos(2 * math.pi * 1.3 * t)
        lines.append(sample_to_hex(x, y, z))
    return lines

def generate_slow_walk(num_samples=256):
    # ~1.16 Hz slow walking gait (cadence ~70 SPM, period 43 samples)
    # Peak mag ~1800, valley dips to 400 (< 1200 threshold)
    lines = []
    freq = 1.1628 # 3000 / 43 = 69.8 SPM
    odr = 50.0
    for i in range(num_samples):
        t = i / odr
        # Pure fundamental stride wave ensuring clear peak and valley
        z = 1000 + 1100 * math.sin(2 * math.pi * freq * t)
        x = 500 * math.sin(2 * math.pi * (freq / 2.0) * t)
        y = 650 * math.cos(2 * math.pi * freq * t)
        lines.append(sample_to_hex(x, y, z))
    return lines

def generate_normal_walk(num_samples=224):
    # ~1.785 Hz normal walking gait (cadence ~107 SPM, period 28 samples)
    # Peak mag ~2200, valley dips to 300
    lines = []
    freq = 1.7857 # 3000 / 28 = 107.1 SPM
    odr = 50.0
    for i in range(num_samples):
        t = i / odr
        z = 1000 + 1300 * math.sin(2 * math.pi * freq * t)
        x = 600 * math.sin(2 * math.pi * (freq / 2.0) * t)
        y = 750 * math.cos(2 * math.pi * freq * t)
        lines.append(sample_to_hex(x, y, z))
    return lines

def generate_brisk_walk(num_samples=184):
    # ~2.174 Hz brisk speed walking (cadence ~130 SPM, period 23 samples)
    # Stance/impact phase reaches peak ~3100, swing phase dips to ~600
    lines = []
    freq = 2.1739 # 3000 / 23 = 130.4 SPM
    odr = 50.0
    for i in range(num_samples):
        t = i / odr
        phase = (t * freq) % 1.0
        if phase < 0.5: # stance / footfall impact
            p = phase / 0.5
            z = int(300 + 2200 * math.sin(p * math.pi))
            x = int(100 + 500 * math.sin(p * math.pi))
            y = int(100 + 700 * math.sin(p * math.pi))
        else:            # airborne swing phase (magnitude dips below step threshold)
            p = (phase - 0.5) / 0.5
            z = int(300 - 100 * math.sin(p * math.pi))
            x = int(50 * math.cos(p * math.pi))
            y = int(50 * math.cos(p * math.pi))
        lines.append(sample_to_hex(x, y, z))
    return lines

def generate_running(num_samples=216):
    # ~2.778 Hz running gait (cadence ~167 SPM, period 18 samples)
    # Ground impact: 3.5g peak (z ~ 3500, x ~ 1000, y ~ 1200) -> Mag ~ 5700
    # Ballistic flight phase: near 0g (z ~ 200, x ~ 50, y ~ 50) -> Mag ~ 300 (< 1200 threshold)
    lines = []
    freq = 2.7777 # 3000 / 18 = 166.7 SPM
    odr = 50.0
    for i in range(num_samples):
        t = i / odr
        phase = (t * freq) % 1.0
        if phase < 0.45: # Ground impact & push-off phase
            p = phase / 0.45
            z = int(300 + 3200 * math.sin(p * math.pi))
            x = int(100 + 900 * math.sin(p * math.pi))
            y = int(100 + 1100 * math.sin(p * math.pi))
        else:            # Airborne ballistic flight phase
            p = (phase - 0.45) / 0.55
            z = int(300 - 150 * math.sin(p * math.pi))
            x = int(50 * math.cos(p * math.pi))
            y = int(50 * math.cos(p * math.pi))
        lines.append(sample_to_hex(x, y, z))
    return lines

def generate_desk_bumps(num_samples=128):
    # Non-periodic table bumps, rapid typing bursts (12 Hz), and mouse shifts (no 4-step rhythmic lock)
    lines = []
    for i in range(num_samples):
        # Baseline resting noise
        x = 15 * math.sin(i * 0.1)
        y = 10 * math.cos(i * 0.15)
        z = 1000 + 20 * math.sin(i * 0.08)
        # Rapid typing burst at 12.5 Hz (period = 4 samples, rejected as high-frequency tremor / fidgeting)
        if 16 <= i <= 24 and (i % 2 == 0):
            z += 800
            x += 150
        # Single isolated transient table bump (no rhythm lock)
        elif i in (58, 59):
            z += 1200
            x += 200
            y -= 150
        # Mouse lift and set-down (irregular interval)
        elif i in (85, 96):
            z += 700
            x -= 100
        lines.append(sample_to_hex(x, y, z))
    return lines

def generate_sitting_rest(num_samples=128):
    # Motionless sitting stance with sensor thermal noise
    lines = []
    for i in range(num_samples):
        x = 10 * math.sin(i * 0.2)
        y = 8 * math.cos(i * 0.25)
        z = 1000 + 12 * math.sin(i * 0.15)
        lines.append(sample_to_hex(x, y, z))
    return lines

def main():
    os.makedirs("data", exist_ok=True)
    datasets = {
        "data/leg_shake.mem": generate_leg_shake(),
        "data/slow_walk.mem": generate_slow_walk(),
        "data/walking.mem": generate_normal_walk(),
        "data/brisk_walk.mem": generate_brisk_walk(),
        "data/running.mem": generate_running(),
        "data/desk_bumps.mem": generate_desk_bumps(),
        "data/sitting_rest.mem": generate_sitting_rest()
    }
    for filename, data in datasets.items():
        with open(filename, "w") as f:
            f.write("\n".join(data) + "\n")
        print(f"[OK] Generated {filename} ({len(data)} samples)")

if __name__ == "__main__":
    main()
