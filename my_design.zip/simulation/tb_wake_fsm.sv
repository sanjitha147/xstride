`timescale 1ns/1ps
module tb_wake_fsm;

  logic clk = 0;
  logic rst_n = 0;
  logic motion_detected = 0;
  logic feature_ready = 0;
  logic core_ack = 0;
  logic core_irq;
  logic pg_accel_en, pg_dsp_en, pg_core_domain_en;
  logic [1:0] state;

  int errors = 0;

  wake_fsm #(
    .MOTION_TIMEOUT_CYCLES(10),
    .SYNC_TIMEOUT_CYCLES(5)
  ) dut (
    .clk_i(clk), .rst_ni(rst_n),
    .motion_detected_i(motion_detected),
    .feature_ready_i(feature_ready),
    .core_ack_i(core_ack),
    .core_irq_o(core_irq),
    .pg_accel_en_o(pg_accel_en),
    .pg_dsp_en_o(pg_dsp_en),
    .pg_core_domain_en_o(pg_core_domain_en),
    .state_o(state)
  );

  always #5 clk = ~clk;

  task automatic check(string name, logic cond);
    if (!cond) begin
      $display("[FAIL] %s @ t=%0t (state=%0d)", name, $time, state);
      errors++;
    end else begin
      $display("[PASS] %s", name);
    end
  endtask

  initial begin
    rst_n = 0;
    repeat (3) @(posedge clk);
    rst_n = 1;
    @(posedge clk);
    check("reset -> SLEEP", state == 2'b00);
    check("SLEEP powers only accel", pg_accel_en && !pg_dsp_en && !pg_core_domain_en);

    // SLEEP -> IDLE on motion
    motion_detected = 1;
    @(posedge clk);
    #1;
    check("SLEEP->IDLE on motion", state == 2'b01);
    motion_detected = 0;

    // IDLE times out back to SLEEP if no motion (MOTION_TIMEOUT_CYCLES=10)
    repeat (12) @(posedge clk);
    #1;
    check("IDLE->SLEEP on timeout", state == 2'b00);

    // Wake again, this time go all the way to ACTIVE
    motion_detected = 1;
    @(posedge clk); #1;
    check("SLEEP->IDLE (2nd)", state == 2'b01);
    @(posedge clk); #1;
    check("IDLE->ACTIVE on continued motion", state == 2'b10);
    motion_detected = 0;
    check("ACTIVE powers accel+dsp, not core", pg_accel_en && pg_dsp_en && !pg_core_domain_en);

    // ACTIVE -> CORE_SYNC on feature_ready
    feature_ready = 1;
    @(posedge clk);
    feature_ready = 0;
    #1;
    check("ACTIVE->CORE_SYNC on feature_ready", state == 2'b11);
    check("CORE_SYNC raises irq + powers core domain", core_irq && pg_core_domain_en);

    // core acks -> back to ACTIVE
    core_ack = 1;
    @(posedge clk);
    core_ack = 0;
    #1;
    check("CORE_SYNC->ACTIVE on core_ack", state == 2'b10);
    check("irq drops after ack", !core_irq);

    // Test CORE_SYNC safety timeout (no ack given)
    feature_ready = 1;
    @(posedge clk);
    feature_ready = 0;
    #1;
    check("back in CORE_SYNC", state == 2'b11);
    repeat (7) @(posedge clk); // > SYNC_TIMEOUT_CYCLES=5
    #1;
    check("CORE_SYNC times out to ACTIVE without ack (no deadlock)", state == 2'b10);

    if (errors == 0) $display("\n=== ALL TESTS PASSED ===");
    else $display("\n=== %0d TEST(S) FAILED ===", errors);

    $finish;
  end

  initial begin
    #2000;
    $display("[FAIL] TIMEOUT -- simulation ran too long");
    $finish;
  end

endmodule
