// =============================================================================
// tb_heep_wrapper.sv
// Testbench for X-HEEP Platform Wrapper & CV32E40P Coprocessor Integration
//
// Verifies:
//   1. OBI slave bus read/write access via wrapper (base address decode)
//   2. Fast interrupt vector propagation (irq_fast_o[3:0])
//   3. Power Manager handshake (sleep req -> ack, and autonomous wake assertion)
// =============================================================================

`timescale 1ns/1ps

module tb_heep_wrapper;

  logic clk = 0;
  always #10 clk = ~clk; // 50 MHz clock

  logic rst_n = 0;

  // OBI Bus
  logic        obi_req = 0;
  logic        obi_gnt;
  logic [31:0] obi_addr = 0;
  logic        obi_we = 0;
  logic [3:0]  obi_be = 4'hF;
  logic [31:0] obi_wdata = 0;
  logic        obi_rvalid;
  logic [31:0] obi_rdata;

  // Interrupts
  logic [3:0] intr_vector;

  // Power Manager
  logic cpu_pg_req = 0;
  logic cpu_pg_ack;
  logic cpu_wake_req;

  // Sensor & Telemetry Pins
  logic spi_sclk, spi_cs_n, spi_mosi, spi_miso = 0;
  logic i2c_scl, i2c_scl_oe, i2c_sda_out, i2c_sda_oe, i2c_sda = 1;
  logic uart_tx, uart_rx = 1, mobile_wake_out, mobile_wake_in = 0;
  logic signed [15:0] analog_x = 0, analog_y = 0, analog_z = 0;

  localparam logic [31:0] HEEP_BASE_ADDR = 32'h2000_0000;

  // Wrapper Instantiation
  x_heep_xstride_wrapper #(
    .BASE_ADDR             (HEEP_BASE_ADDR),
    .SPI_CLK_DIV           (4),
    .I2C_CLK_DIV           (2),
    .SAMPLE_PERIOD_CYCLES  (200),
    .WINDOW_SAMPLES        (32)
  ) dut_wrapper (
    .clk_i               (clk),
    .rst_ni              (rst_n),
    .obi_req_i           (obi_req),
    .obi_gnt_o           (obi_gnt),
    .obi_addr_i          (obi_addr),
    .obi_we_i            (obi_we),
    .obi_be_i            (obi_be),
    .obi_wdata_i         (obi_wdata),
    .obi_rvalid_o        (obi_rvalid),
    .obi_rdata_o         (obi_rdata),
    .intr_vector_o       (intr_vector),
    .cpu_powergate_req_i (cpu_pg_req),
    .cpu_powergate_ack_o (cpu_pg_ack),
    .cpu_wakeup_req_o    (cpu_wake_req),
    .spi_sclk_o          (spi_sclk),
    .spi_cs_no           (spi_cs_n),
    .spi_mosi_o          (spi_mosi),
    .spi_miso_i          (spi_miso),
    .i2c_scl_o           (i2c_scl),
    .i2c_scl_oe          (i2c_scl_oe),
    .i2c_sda_o           (i2c_sda_out),
    .i2c_sda_oe          (i2c_sda_oe),
    .i2c_sda_i           (i2c_sda),
    .uart_tx_o           (uart_tx),
    .uart_rx_i           (uart_rx),
    .mobile_wake_o       (mobile_wake_out),
    .mobile_wake_i       (mobile_wake_in),
    .mems_analog_x_i     (analog_x),
    .mems_analog_y_i     (analog_y),
    .mems_analog_z_i     (analog_z)
  );

  task automatic obi_read(input logic [31:0] addr, output logic [31:0] data);
    @(posedge clk);
    #1;
    obi_addr = addr; obi_we = 0; obi_req = 1;
    @(posedge clk);
    #1;
    obi_req = 0;
    while (!obi_rvalid) @(posedge clk);
    data = obi_rdata;
  endtask

  task automatic obi_write(input logic [31:0] addr, input logic [31:0] data);
    @(posedge clk);
    #1;
    obi_addr = addr; obi_we = 1; obi_wdata = data; obi_req = 1;
    @(posedge clk);
    #1;
    obi_req = 0; obi_we = 0;
    repeat(4) @(posedge clk);
  endtask

  int errors = 0;
  logic [31:0] rdata;

  initial begin
    $display("\n========================================================");
    $display(" X-HEEP PLATFORM WRAPPER VERIFICATION TESTBENCH");
    $display(" Target: CV32E40P RISC-V SoC Integration");
    $display("========================================================");

    // Reset sequence
    rst_n = 0;
    repeat (5) @(posedge clk);
    rst_n = 1;
    repeat (10) @(posedge clk);

    // 1. Verify Power Manager handshake into sleep
    $display("\n[TEST 1] Power Manager CPU Powergate Handshake");
    cpu_pg_req = 1;
    repeat (5) @(posedge clk);
    if (cpu_pg_ack == 1'b1) begin
      $display("  [PASS] CPU Powergate Request Acknowledged by AON Wrapper");
    end else begin
      $display("  [FAIL] CPU Powergate Ack not asserted!");
      errors++;
    end

    // 2. Verify Autonomous Wakeup Request on Mobile / Motion Trigger
    $display("\n[TEST 2] Autonomous Wakeup Request to X-HEEP Power Manager");
    mobile_wake_in = 1; // Inject asynchronous mobile BLE wake trigger
    repeat (20) @(posedge clk);
    if (cpu_wake_req == 1'b1) begin
      $display("  [PASS] Autonomous Wakeup Request asserted to CPU Power Manager!");
    end else begin
      $display("  [FAIL] Wakeup request was not asserted upon mobile wake trigger!");
      errors++;
    end
    mobile_wake_in = 0;

    // Power Manager wakes up CPU domain
    cpu_pg_req = 0;
    repeat (10) @(posedge clk);
    if (cpu_pg_ack == 1'b0) begin
      $display("  [PASS] CPU Domain restored to ACTIVE state");
    end else begin
      $display("  [FAIL] CPU Domain did not exit handshake state!");
      errors++;
    end

    // 3. Verify OBI Slave Access via CV32E40P address map
    $display("\n[TEST 3] OBI Bus Read/Write Access via Base Address Map (0x2000_0000)");
    obi_write(HEEP_BASE_ADDR + 32'h48, 32'd1250); // Set STEP_THRESHOLD
    obi_read(HEEP_BASE_ADDR + 32'h48, rdata);
    if (rdata == 32'd1250) begin
      $display("  [PASS] STEP_THRESHOLD Register RW matched: %0d", rdata);
    end else begin
      $display("  [FAIL] STEP_THRESHOLD Read Mismatch! Expected 1250, got %0d", rdata);
      errors++;
    end

    // 4. Verify Interrupt Routing
    $display("\n[TEST 4] CV32E40P Fast Interrupt Vector Verification");
    $display("  -> Core Wake IRQ [0] state: %b", intr_vector[0]);
    obi_write(HEEP_BASE_ADDR + 32'h18, 32'h1); // IRQ_ACK
    repeat (5) @(posedge clk);
    $display("  -> After ACK: Core Wake IRQ [0] state: %b", intr_vector[0]);

    if (errors == 0) begin
      $display("\n========================================================");
      $display(" ALL X-HEEP WRAPPER INTEGRATION TESTS PASSED (100%% SUCCESS)!");
      $display("========================================================\n");
    end else begin
      $display("\n[-] %0d TEST(S) FAILED IN X-HEEP WRAPPER!\n", errors);
    end

    $finish;
  end

  initial begin
    #500000;
    $display("[FAIL] Timeout in tb_heep_wrapper");
    $finish;
  end

endmodule
