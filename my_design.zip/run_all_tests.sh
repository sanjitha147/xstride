#!/usr/bin/env bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -d "$SCRIPT_DIR/../source" ]; then
    PROJ_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
else
    PROJ_ROOT="$SCRIPT_DIR"
fi

SRC_DIR="$PROJ_ROOT/source"
INC_DIR="$PROJ_ROOT/include"
SIM_DIR="$PROJ_ROOT/simulation"

cd "$SIM_DIR"

echo "=== 1. Wake FSM ==="
iverilog -g2012 -o sim_wake_fsm $SRC_DIR/wake_fsm.sv tb_wake_fsm.sv && vvp sim_wake_fsm

echo "=== 2. DSP Front-End ==="
iverilog -g2012 -o sim_dsp $SRC_DIR/dsp_frontend.sv tb_dsp_frontend.sv && vvp sim_dsp

echo "=== 3. Accelerometer SPI Master ==="
iverilog -g2012 -o sim_accel $SRC_DIR/accel_spi_intf.sv tb_accel_spi_intf.sv && vvp sim_accel

echo "=== 4. Integrated On-Chip MEMS Sensor & ADC ==="
iverilog -g2012 -o sim_onchip $SRC_DIR/mems_afe_adc.sv $SRC_DIR/onchip_mems_sensor.sv tb_onchip_mems_sensor.sv && vvp sim_onchip

echo "=== 5. Unified Sensor Hub ==="
iverilog -g2012 -o sim_hub $SRC_DIR/sensor_hub.sv tb_sensor_hub.sv && vvp sim_hub

echo "=== 6. Headless Mobile App Telemetry Unit ==="
iverilog -g2012 -o sim_telemetry $SRC_DIR/mobile_telemetry_unit.sv tb_mobile_telemetry.sv && vvp sim_telemetry

echo "=== 7. Pedometer Classifier ==="
iverilog -g2012 -o sim_classifier $SRC_DIR/pedometer_classifier.sv tb_pedometer_classifier.sv && vvp sim_classifier

echo "=== 8. OBI Register File ==="
iverilog -g2012 -I$INC_DIR -o sim_regs $INC_DIR/xstride_regs_pkg.sv $SRC_DIR/xstride_regs_obi.sv tb_xstride_regs_obi.sv && vvp sim_regs

echo "=== 9. Full Top-Level SoC Integration & SVA ==="
iverilog -g2012 -I$INC_DIR -o sim_top $INC_DIR/xstride_regs_pkg.sv $SRC_DIR/rst_sync.sv $SRC_DIR/sync_2ff.sv $SRC_DIR/mems_afe_adc.sv $SRC_DIR/accel_spi_intf.sv $SRC_DIR/accel_i2c_intf.sv $SRC_DIR/onchip_mems_sensor.sv $SRC_DIR/sensor_hub.sv $SRC_DIR/calib_stage.sv $SRC_DIR/dsp_frontend.sv $SRC_DIR/pedometer_classifier.sv $SRC_DIR/feature_stats.sv $SRC_DIR/mobile_telemetry_unit.sv $SRC_DIR/wake_fsm.sv $SRC_DIR/xstride_regs_obi.sv $SRC_DIR/xstride_always_on_top.sv $SRC_DIR/xstride_sva.sv tb_xstride_top.sv && vvp sim_top

echo "=== 10. Real Accelerometer Dataset Replay & Clinical Accuracy ==="
iverilog -g2012 -I$INC_DIR -o sim_replay $INC_DIR/xstride_regs_pkg.sv $SRC_DIR/rst_sync.sv $SRC_DIR/sync_2ff.sv $SRC_DIR/mems_afe_adc.sv $SRC_DIR/accel_spi_intf.sv $SRC_DIR/accel_i2c_intf.sv $SRC_DIR/onchip_mems_sensor.sv $SRC_DIR/sensor_hub.sv $SRC_DIR/calib_stage.sv $SRC_DIR/dsp_frontend.sv $SRC_DIR/pedometer_classifier.sv $SRC_DIR/feature_stats.sv $SRC_DIR/mobile_telemetry_unit.sv $SRC_DIR/wake_fsm.sv $SRC_DIR/xstride_regs_obi.sv $SRC_DIR/xstride_always_on_top.sv $SRC_DIR/xstride_sva.sv tb_coverage.sv tb_real_dataset_replay.sv && vvp sim_replay

echo "=== 11. Constrained Random Verification & SVA Suite ==="
iverilog -g2012 -o sim_rand $SRC_DIR/pedometer_classifier.sv tb_pedometer_randomized.sv && vvp sim_rand

echo "=== 12. X-HEEP Host Platform Wrapper & Fast IRQ Vectors ==="
iverilog -g2012 -I$INC_DIR -o sim_heep $INC_DIR/xstride_regs_pkg.sv $SRC_DIR/rst_sync.sv $SRC_DIR/sync_2ff.sv $SRC_DIR/mems_afe_adc.sv $SRC_DIR/accel_spi_intf.sv $SRC_DIR/accel_i2c_intf.sv $SRC_DIR/onchip_mems_sensor.sv $SRC_DIR/sensor_hub.sv $SRC_DIR/calib_stage.sv $SRC_DIR/dsp_frontend.sv $SRC_DIR/pedometer_classifier.sv $SRC_DIR/feature_stats.sv $SRC_DIR/mobile_telemetry_unit.sv $SRC_DIR/wake_fsm.sv $SRC_DIR/xstride_regs_obi.sv $SRC_DIR/xstride_always_on_top.sv $SRC_DIR/x_heep_xstride_wrapper.sv tb_heep_wrapper.sv && vvp sim_heep

echo "=== 13. IEEE 1801 UPF 3.0 Linter ==="
python check_upf.py

echo "=== 14. 65nm LP ASIC Physical Synthesis & Power Measurement ==="
python synth_power_analysis.py

echo "ALL 14 TESTBENCHES PASSED WITH 100% SUCCESS!"
