# X-STRIDE: Ultra-Low-Power Pedometer & Physiological Classification SoC (v2.0)

## Overview
X-STRIDE is a tapeout-ready, ultra-low-power pedometer and physiological classification SoC IP core. It features autonomous always-on power gating, sub-15 µW operating power, IEEE 1801 UPF 3.0 power management intent, and full integration with the EPFL X-HEEP RISC-V platform (CV32E40P core).

## Standard Project Directory Hierarchy
```
my_design/
├── project.json                    # Project manifest & metadata
├── source/                         # Synthesizable RTL SystemVerilog modules
├── include/                        # SystemVerilog packages and header definitions
├── simulation/                     # Verification testbenches, datasets, and scripts
│   └── data/                       # Real clinical accelerometer datasets (.mem)
├── constraints/                    # Timing and electrical constraints (design.sdc)
│   └── design.sdc
├── configuration/                  # UPF 3.0, YAML register map, Yosys, DC, and OpenROAD scripts
├── technology/                     # 65nm LP technology node specification
├── firmware/                       # CV32E40P C driver, BSP, linker script, and test app
│   ├── src/
│   ├── include/
│   ├── linker/
│   ├── boards/
│   └── tests/
└── runs/                           # Parallel computation worker configuration (runs.txt)
```

## Quick Verification
To run the complete 14-test verification suite (unit tests, clinical dataset replay, SVA assertions, UPF linter, and 65nm LP ASIC power analysis):
```powershell
powershell simulation/run_all_tests.ps1
```
