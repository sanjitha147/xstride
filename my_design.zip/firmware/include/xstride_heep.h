/**
 * @file xstride_heep.h
 * @brief X-STRIDE Pedometer & Physiological Classification Coprocessor C Driver
 * @details Target Platform: EPFL X-HEEP (CV32E40P RISC-V 32-bit Core)
 *          Compliant with standard CMSIS / RISC-V Bare-metal & FreeRTOS HAL.
 */

#ifndef XSTRIDE_HEEP_H_
#define XSTRIDE_HEEP_H_

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

// =============================================================================
// Memory Map & Base Address
// =============================================================================
#ifndef XSTRIDE_DEFAULT_BASE_ADDR
#define XSTRIDE_DEFAULT_BASE_ADDR  (0x20000000U)
#endif

// =============================================================================
// Register Offsets
// =============================================================================
#define XSTRIDE_REG_CTRL            (0x00U)
#define XSTRIDE_REG_STATUS          (0x04U)
#define XSTRIDE_REG_FEAT_MAGNITUDE  (0x08U)
#define XSTRIDE_REG_FEAT_ZCR        (0x0CU)
#define XSTRIDE_REG_FEAT_CADENCE    (0x10U)
#define XSTRIDE_REG_TINYML_CLASS    (0x14U)
#define XSTRIDE_REG_IRQ_ACK         (0x18U)
#define XSTRIDE_REG_TOTAL_STEPS     (0x1CU)
#define XSTRIDE_REG_WALK_STEPS      (0x20U)
#define XSTRIDE_REG_RUN_STEPS       (0x24U)
#define XSTRIDE_REG_SHAKE_EVENTS    (0x28U)
#define XSTRIDE_REG_SHAKE_DURATION  (0x2CU)
#define XSTRIDE_REG_CADENCE_SPM     (0x30U)
#define XSTRIDE_REG_SENSOR_CTRL     (0x34U)
#define XSTRIDE_REG_RAW_ACCEL_XY    (0x38U)
#define XSTRIDE_REG_RAW_ACCEL_Z     (0x3CU)
#define XSTRIDE_REG_MOBILE_STATUS   (0x40U)
#define XSTRIDE_REG_MOBILE_FIFO     (0x44U)
#define XSTRIDE_REG_STEP_THRESH     (0x48U)

// =============================================================================
// Register Bitfield Definitions
// =============================================================================
// CTRL Register (0x00)
#define XSTRIDE_CTRL_SOFT_EN_MASK        (1U << 0)
#define XSTRIDE_CTRL_SHAKE_FILTER_MASK   (1U << 1)
#define XSTRIDE_CTRL_SENSOR_SEL_SHIFT    (2U)
#define XSTRIDE_CTRL_SENSOR_SEL_MASK     (3U << XSTRIDE_CTRL_SENSOR_SEL_SHIFT)

// STATUS Register (0x04)
#define XSTRIDE_STATUS_FSM_STATE_SHIFT   (0U)
#define XSTRIDE_STATUS_FSM_STATE_MASK    (3U << XSTRIDE_STATUS_FSM_STATE_SHIFT)
#define XSTRIDE_STATUS_MOTION_DET_MASK   (1U << 2)
#define XSTRIDE_STATUS_FEAT_RDY_MASK     (1U << 3)
#define XSTRIDE_STATUS_ACT_CLASS_SHIFT   (4U)
#define XSTRIDE_STATUS_ACT_CLASS_MASK    (7U << XSTRIDE_STATUS_ACT_CLASS_SHIFT)

// SENSOR_CTRL Register (0x34)
#define XSTRIDE_SCTRL_SENSOR_SEL_MASK    (3U << 0)
#define XSTRIDE_SCTRL_SELF_TEST_EN_MASK  (1U << 2)
#define XSTRIDE_SCTRL_RANGE_SEL_SHIFT    (3U)
#define XSTRIDE_SCTRL_RANGE_SEL_MASK     (3U << XSTRIDE_SCTRL_RANGE_SEL_SHIFT)

// MOBILE_STATUS Register (0x40)
#define XSTRIDE_MSTAT_FIFO_COUNT_SHIFT   (0U)
#define XSTRIDE_MSTAT_FIFO_COUNT_MASK    (0xFFU << XSTRIDE_MSTAT_FIFO_COUNT_SHIFT)
#define XSTRIDE_MSTAT_FIFO_EMPTY_MASK    (1U << 8)
#define XSTRIDE_MSTAT_FIFO_FULL_MASK     (1U << 9)

// CV32E40P Fast Interrupt Lines
#define XSTRIDE_FAST_IRQ_WAKE            (16U)
#define XSTRIDE_FAST_IRQ_SHAKE_ALERT     (17U)
#define XSTRIDE_FAST_IRQ_STRIDE_STEP     (18U)
#define XSTRIDE_FAST_IRQ_FIFO_WATERMARK  (19U)

// =============================================================================
// Enumerations & Typedefs
// =============================================================================
typedef enum {
    XSTRIDE_SENSOR_SPI    = 0,
    XSTRIDE_SENSOR_I2C    = 1,
    XSTRIDE_SENSOR_ONCHIP = 2
} xstride_sensor_t;

typedef enum {
    XSTRIDE_RANGE_2G  = 0,
    XSTRIDE_RANGE_4G  = 1,
    XSTRIDE_RANGE_8G  = 2,
    XSTRIDE_RANGE_16G = 3
} xstride_range_t;

typedef enum {
    XSTRIDE_ACT_REST      = 0,
    XSTRIDE_ACT_LEG_SHAKE = 1,
    XSTRIDE_ACT_WALK      = 2,
    XSTRIDE_ACT_RUN       = 3,
    XSTRIDE_ACT_EXERCISE  = 4
} xstride_activity_t;

typedef struct {
    uint32_t total_steps;
    uint32_t walk_steps;
    uint32_t run_steps;
    uint32_t shake_events;
    uint32_t shake_duration_sec;
    uint16_t cadence_spm;
    xstride_activity_t current_activity;
} xstride_metrics_t;

// Callback signature for fast interrupt events
typedef void (*xstride_event_cb_t)(uint32_t irq_id, void *context);

// =============================================================================
// Driver API Functions
// =============================================================================

/**
 * @brief Initialize X-STRIDE peripheral.
 * @param base_addr OBI base address assigned in X-HEEP address map.
 * @param sensor Physical sensor source (SPI, I2C, or On-chip MEMS).
 * @param step_threshold Step peak detection sensitivity threshold (e.g. 1000).
 */
void xstride_init(uint32_t base_addr, xstride_sensor_t sensor, uint16_t step_threshold);

/**
 * @brief Enable or disable X-STRIDE processing engine.
 * @param enable true to enable, false for low-power standby.
 */
void xstride_enable(bool enable);

/**
 * @brief Enable or disable physiological leg-shaking discrimination filter.
 * @param enable true: lock out leg-shaking from step counters; false: raw detection.
 */
void xstride_set_shake_filter(bool enable);

/**
 * @brief Configure on-chip MEMS full-scale acceleration range.
 * @param range Acceleration range (+/-2g to +/-16g).
 */
void xstride_set_range(xstride_range_t range);

/**
 * @brief Read all retained pedometer and physiological activity metrics.
 * @param metrics Pointer to destination metrics structure.
 */
void xstride_get_metrics(xstride_metrics_t *metrics);

/**
 * @brief Read instantaneous raw 3-axis acceleration vector.
 * @param x Output pointer for X acceleration (LSB = mg).
 * @param y Output pointer for Y acceleration (LSB = mg).
 * @param z Output pointer for Z acceleration (LSB = mg).
 */
void xstride_get_raw_accel(int16_t *x, int16_t *y, int16_t *z);

/**
 * @brief Acknowledge core wake interrupt to transition FSM to ACTIVE.
 */
void xstride_ack_irq(void);

/**
 * @brief Register application callback for X-STRIDE interrupt events.
 * @param cb Callback function pointer.
 * @param context User context pointer.
 */
void xstride_register_callback(xstride_event_cb_t cb, void *context);

/**
 * @brief CV32E40P Interrupt Service Routine (call from vector table).
 * @param irq_num Triggered IRQ line (16..19).
 */
void xstride_isr_handler(uint32_t irq_num);

/**
 * @brief Read packets from mobile app telemetry FIFO.
 * @param buffer Output buffer.
 * @param max_words Maximum 32-bit words to drain.
 * @return Number of words read.
 */
uint32_t xstride_drain_telemetry_fifo(uint32_t *buffer, uint32_t max_words);

/**
 * @brief Enter ultra-low-power mode: step counters retained in AON domain.
 */
void xstride_enter_retention_sleep(void);

#ifdef __cplusplus
}
#endif

#endif // XSTRIDE_HEEP_H_
