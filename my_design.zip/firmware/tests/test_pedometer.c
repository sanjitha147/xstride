/**
 * @file test_pedometer.c
 * @brief Bare-Metal Firmware Test Application for X-STRIDE Coprocessor on X-HEEP
 */

#include "x_heep_board.h"
#include "xstride_heep.h"
#include <stdio.h>

volatile int g_step_event_count = 0;
volatile int g_shake_event_count = 0;

void xstride_event_callback(uint32_t irq_id, void *context)
{
    (void)context;
    if (irq_id == XSTRIDE_IRQ_STRIDE_STEP) {
        g_step_event_count++;
    } else if (irq_id == XSTRIDE_IRQ_SHAKE_ALERT) {
        g_shake_event_count++;
    }
}

int main(void)
{
    printf("========================================================\n");
    printf(" X-STRIDE v2.0 CV32E40P FIRMWARE INTEGRATION TEST\n");
    printf("========================================================\n");

    // 1. Initialize X-STRIDE hardware coprocessor
    printf("[FW] Initializing X-STRIDE at base 0x%08X...\n", X_HEEP_XSTRIDE_BASE_ADDR);
    xstride_init(X_HEEP_XSTRIDE_BASE_ADDR, XSTRIDE_SENSOR_ONCHIP, 1000);
    xstride_set_shake_filter(true);
    xstride_set_range(XSTRIDE_RANGE_4G);
    xstride_register_callback(xstride_event_callback, NULL);

    // 2. Read initial retained metrics
    xstride_metrics_t metrics;
    xstride_get_metrics(&metrics);
    printf("[FW] Initial Retained Steps: %u, Activity: %d\n", 
           (unsigned int)metrics.total_steps, (int)metrics.current_activity);

    // 3. Test IRQ acknowledge and retention sleep
    printf("[FW] Acknowledging IRQ and arming wake event...\n");
    xstride_ack_irq();

    // 4. Enter retention sleep
    printf("[FW] Entering CPU deep sleep (WFI)... Metrics stay live in PD_AON.\n");
    xstride_enter_retention_sleep();

    printf("[FW] Test Completed Successfully.\n");
    return 0;
}
