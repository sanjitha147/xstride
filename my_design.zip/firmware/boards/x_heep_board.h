/**
 * @file x_heep_board.h
 * @brief Board Support Package (BSP) definitions for X-HEEP RISC-V SoC
 */

#ifndef X_HEEP_BOARD_H_
#define X_HEEP_BOARD_H_

#include <stdint.h>

// Clocks
#define SYSTEM_CLOCK_FREQ_HZ         50000000U // 50.0 MHz Primary Core Clock
#define AON_CLOCK_FREQ_HZ               32768U // 32.768 kHz Always-On Clock

// Base Memory Map
#define X_HEEP_ROM_BASE_ADDR        0x00000000U
#define X_HEEP_RAM_BASE_ADDR        0x00010000U
#define X_HEEP_XSTRIDE_BASE_ADDR    0x20000000U // X-STRIDE Coprocessor Window

// CV32E40P Fast Interrupt Vectors (mip.FIRQ[3:0] -> lines 16..19)
#define XSTRIDE_IRQ_CORE_WAKE       16U // Autonomous motion / BLE wakeup trigger
#define XSTRIDE_IRQ_SHAKE_ALERT     17U // Physiological leg-shaking detected
#define XSTRIDE_IRQ_STRIDE_STEP     18U // Verified human stride step incremented
#define XSTRIDE_IRQ_FIFO_WATERMARK  19U // Telemetry FIFO reached threshold

#endif // X_HEEP_BOARD_H_
