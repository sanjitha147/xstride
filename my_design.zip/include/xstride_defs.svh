// =============================================================================
// xstride_defs.svh
// Global SystemVerilog Definitions & Architecture Constants for X-STRIDE v2.0
// =============================================================================

`ifndef XSTRIDE_DEFS_SVH
`define XSTRIDE_DEFS_SVH

`timescale 1ns/1ps

// Clock Frequency Standards
`define XSTRIDE_CLK_FREQ_BURST_HZ    50_000_000 // 50.0 MHz Burst Processing Clock
`define XSTRIDE_CLK_FREQ_AON_HZ          32_768 // 32.768 kHz Always-On RTC Clock
`define XSTRIDE_SAMPLE_RATE_HZ               50 // 50 Hz Biomechanical Output Data Rate (ODR)

// OBI Bus Standard Widths
`define OBI_ADDR_WIDTH                       32
`define OBI_DATA_WIDTH                       32
`define OBI_BYTE_ENABLE_WIDTH                 4

// Sensor Source IDs (sensor_sel)
`define SENSOR_SEL_SPI                 2'b00 // External SPI Accelerometer
`define SENSOR_SEL_I2C                 2'b01 // External I2C Accelerometer
`define SENSOR_SEL_ONCHIP              2'b10 // On-Chip Capacitive MEMS Sensor + SAR ADC

// Activity Classification Codes (act_class)
`define ACT_CLASS_REST                 3'b000 // Motionless Rest / Sedentary Stance
`define ACT_CLASS_LEG_SHAKE            3'b001 // Seated Leg Shaking / Tremor (Rejected)
`define ACT_CLASS_WALK                 3'b010 // Regular Walking Gait
`define ACT_CLASS_RUN                  3'b011 // Jogging / Running Gait
`define ACT_CLASS_EXERCISE             3'b100 // High-Intensity Exercise

// FSM Power Management States
`define WAKE_FSM_STANDBY               2'b00 // Deep Sleep (<0.39 uW)
`define WAKE_FSM_SLEEP_SENSING         2'b01 // Low-power sampling (<1.2 uW)
`define WAKE_FSM_ACTIVE_TRACKING       2'b10 // Active DSP stride pipeline (5.16 uW)
`define WAKE_FSM_MOBILE_SYNC           2'b11 // BLE Telemetry sync burst

#endif // XSTRIDE_DEFS_SVH
