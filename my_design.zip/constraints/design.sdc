# ==============================================================================
# design.sdc - Synopsys Design Constraints (SDC 2.1)
# Project: X-STRIDE Ultra-Low-Power Pedometer & Physiological Classification SoC
# Release: v2.0 Tapeout Candidate
# Target Technology: TSMC / SkyWater 65nm LP (0.8 V Core / 0.6 V Retention)
# Top-Level Design: x_heep_xstride_wrapper / xstride_always_on_top
# ==============================================================================

# Operating Conditions & Wire Load Model
set_operating_conditions -analysis_type on_chip_variation
set_wire_load_mode segmented

# ------------------------------------------------------------------------------
# 1. Primary System Clocks
# ------------------------------------------------------------------------------
# Primary High-Frequency Burst Processing Clock (50 MHz, Period = 20.0 ns)
create_clock -name clk_50m -period 20.000 -waveform {0.000 10.000} [get_ports clk_i]
set_clock_uncertainty -setup 0.200 [get_clocks clk_50m]
set_clock_uncertainty -hold  0.080 [get_clocks clk_50m]
set_clock_transition 0.100 [get_clocks clk_50m]

# Continuous Always-On Real-Time Clock (32.768 kHz, Period = 30517.58 ns)
# (Used in PD_AON deep sleep comparator and RTC wake counters)
create_clock -name clk_32k -period 30517.580 -waveform {0.000 15258.790} [get_ports -quiet clk_aon_i]

# ------------------------------------------------------------------------------
# 2. Generated Sensor Clocks
# ------------------------------------------------------------------------------
# SPI Master SCLK: 50 MHz divided by 8 = 6.25 MHz (Period = 160.0 ns)
create_generated_clock -name spi_sclk -source [get_ports clk_i] \
  -divide_by 8 [get_ports spi_sclk_o]

# I2C Master SCL: 50 MHz divided by 16 = 3.125 MHz internal / 400 kHz bus
create_generated_clock -name i2c_scl -source [get_ports clk_i] \
  -divide_by 16 [get_ports i2c_scl_o]

# ------------------------------------------------------------------------------
# 3. Asynchronous Clock Domain Crossings
# ------------------------------------------------------------------------------
set_clock_groups -asynchronous \
  -group [get_clocks clk_50m] \
  -group [get_clocks -quiet clk_32k]

# ------------------------------------------------------------------------------
# 4. Asynchronous Inputs and CDC False Paths
# ------------------------------------------------------------------------------
# Asynchronous external inputs synchronized via dedicated sync_2ff modules
set_false_path -from [get_ports mobile_wake_i]
set_false_path -from [get_ports spi_miso_i]
set_false_path -from [get_ports i2c_sda_i]
set_false_path -from [get_ports uart_rx_i]
set_false_path -from [get_ports rst_ni]

# Timing false path through first flip-flop of 2-flop synchronizer cells
set_false_path -to [get_pins -hierarchical *u_sync*q1_reg*/D]
set_false_path -to [get_pins -hierarchical *u_rst_sync*q1_reg*/D]

# ------------------------------------------------------------------------------
# 5. Multicycle Paths
# ------------------------------------------------------------------------------
# DSP 50 Hz sample rate downsampling paths (1,000,000 cycles at 50 MHz)
# Enable multi-cycle paths for arithmetic DSP pipelines
set_multicycle_path -setup 2 -from [get_pins -hierarchical *u_calib*stage_reg*/Q] -to [get_pins -hierarchical *u_dsp*mag_reg*/D]
set_multicycle_path -hold  1 -from [get_pins -hierarchical *u_calib*stage_reg*/Q] -to [get_pins -hierarchical *u_dsp*mag_reg*/D]

# ------------------------------------------------------------------------------
# 6. Input / Output Delays (OBI Bus, Platform & Peripherals)
# ------------------------------------------------------------------------------
# OBI synchronous bus interface constraints (referenced to clk_50m)
set_input_delay  -clock clk_50m -max 4.000 [get_ports {obi_req_i obi_we_i obi_be_i* obi_addr_i* obi_wdata_i*}]
set_input_delay  -clock clk_50m -min 1.000 [get_ports {obi_req_i obi_we_i obi_be_i* obi_addr_i* obi_wdata_i*}]

set_output_delay -clock clk_50m -max 4.000 [get_ports {obi_gnt_o obi_rvalid_o obi_rdata_o*}]
set_output_delay -clock clk_50m -min 0.500 [get_ports {obi_gnt_o obi_rvalid_o obi_rdata_o*}]

# CV32E40P Fast Interrupt lines
set_output_delay -clock clk_50m -max 3.500 [get_ports {intr_vector_o*}]
set_output_delay -clock clk_50m -min 0.500 [get_ports {intr_vector_o*}]

# Power Manager Handshake lines
set_input_delay  -clock clk_50m -max 3.000 [get_ports cpu_powergate_req_i]
set_output_delay -clock clk_50m -max 3.000 [get_ports {cpu_powergate_ack_o cpu_wakeup_req_o}]

# Peripheral IOs
set_output_delay -clock clk_50m -max 5.000 [get_ports {uart_tx_o mobile_wake_o}]
set_output_delay -clock spi_sclk -max 10.000 [get_ports {spi_mosi_o spi_cs_no}]

# ------------------------------------------------------------------------------
# 7. Drive Strengths and Output Loads
# ------------------------------------------------------------------------------
set_driving_cell -lib_cell INV_X4 [all_inputs]
set_load -pin_load 0.030 [all_outputs]
set_load -pin_load 0.050 [get_ports {spi_sclk_o spi_mosi_o i2c_scl_o uart_tx_o}]
