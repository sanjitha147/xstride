# ==============================================================================
# synth_dc.tcl - Synopsys Design Compiler Synthesis Script for X-STRIDE SoC
# Target Library: TSMC 65nm LP (tcbn65lphvt / tcbn65lpsvt)
# ==============================================================================

set search_path [list . ../source ../include ../constraints]
set target_library [list tcbn65lphvt.db tcbn65lpsvt.db]
set synthetic_library [list dw_foundation.sldb]
set link_library [concat * $target_library $synthetic_library]

# Analyze and elaborate SystemVerilog source files
analyze -format sverilog {
    ../include/xstride_regs_pkg.sv
    ../source/rst_sync.sv
    ../source/sync_2ff.sv
    ../source/mems_afe_adc.sv
    ../source/accel_spi_intf.sv
    ../source/accel_i2c_intf.sv
    ../source/onchip_mems_sensor.sv
    ../source/sensor_hub.sv
    ../source/calib_stage.sv
    ../source/dsp_frontend.sv
    ../source/pedometer_classifier.sv
    ../source/feature_stats.sv
    ../source/mobile_telemetry_unit.sv
    ../source/wake_fsm.sv
    ../source/xstride_regs_obi.sv
    ../source/xstride_always_on_top.sv
    ../source/x_heep_xstride_wrapper.sv
}

elaborate x_heep_xstride_wrapper
link
check_design

# Source timing and power constraints
read_sdc ../constraints/design.sdc
load_upf ../configuration/xstride.upf

# Compile ultra with power optimization
compile_ultra -gate_clock

# Generate verification reports
report_timing -delay_type max > timing_max.rpt
report_timing -delay_type min > timing_min.rpt
report_area -hierarchy > area.rpt
report_power -hierarchy > power.rpt

# Export netlist
write -format verilog -hierarchy -output ../source/xstride_synth_netlist.v
