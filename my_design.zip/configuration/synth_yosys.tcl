# ==============================================================================
# synth_yosys.tcl - Yosys Open-Source Synthesis Flow for X-STRIDE SoC
# ==============================================================================

# Read design packages and include paths
verilog_defines -DASSERT_ON
read_verilog -sv ../include/xstride_regs_pkg.sv
read_verilog -sv ../source/rst_sync.sv
read_verilog -sv ../source/sync_2ff.sv
read_verilog -sv ../source/mems_afe_adc.sv
read_verilog -sv ../source/accel_spi_intf.sv
read_verilog -sv ../source/accel_i2c_intf.sv
read_verilog -sv ../source/onchip_mems_sensor.sv
read_verilog -sv ../source/sensor_hub.sv
read_verilog -sv ../source/calib_stage.sv
read_verilog -sv ../source/dsp_frontend.sv
read_verilog -sv ../source/pedometer_classifier.sv
read_verilog -sv ../source/feature_stats.sv
read_verilog -sv ../source/mobile_telemetry_unit.sv
read_verilog -sv ../source/wake_fsm.sv
read_verilog -sv ../source/xstride_regs_obi.sv
read_verilog -sv ../source/xstride_always_on_top.sv
read_verilog -sv ../source/x_heep_xstride_wrapper.sv

# Elaborate hierarchy
hierarchy -top x_heep_xstride_wrapper

# High-level synthesis optimizations
proc; opt; fsm; opt; memory; opt

# Technology mapping & gate-level netlist generation
techmap; opt
clean

# Print area and cell utilization report
stat
