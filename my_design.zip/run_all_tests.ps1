# ==============================================================================
# run_all_tests.ps1 - Full Regression Runner for X-STRIDE SoC (my_design)
# Runs all 14 unit, integration, dataset replay, SVA, UPF, and power checks.
# ==============================================================================

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if (Test-Path "$ScriptDir/../source") {
    $ProjRoot = Resolve-Path "$ScriptDir/.."
} else {
    $ProjRoot = Resolve-Path "$ScriptDir"
}

$SrcDir  = "$ProjRoot/source"
$IncDir  = "$ProjRoot/include"
$SimDir  = "$ProjRoot/simulation"
$CfgDir  = "$ProjRoot/configuration"

if (-not (Get-Command iverilog -ErrorAction SilentlyContinue)) {
    if (Test-Path "E:\iverilog\app\bin") {
        $env:PATH = "E:\iverilog\app\bin;" + $env:PATH
    }
}

function Run-Step([string]$name, [string]$cmd) {
    Write-Host "`n========================================================" -ForegroundColor Cyan
    Write-Host " RUNNING: $name" -ForegroundColor Yellow
    Write-Host "========================================================" -ForegroundColor Cyan
    Invoke-Expression $cmd
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[-] $name FAILED" -ForegroundColor Red
        exit 1
    }
}

Set-Location $SimDir

Run-Step "1. Wake FSM" "iverilog -g2012 -o sim_wake_fsm $SrcDir/wake_fsm.sv tb_wake_fsm.sv; vvp sim_wake_fsm"
Run-Step "2. DSP Front-End" "iverilog -g2012 -o sim_dsp $SrcDir/dsp_frontend.sv tb_dsp_frontend.sv; vvp sim_dsp"
Run-Step "3. Accelerometer SPI Master" "iverilog -g2012 -o sim_accel $SrcDir/accel_spi_intf.sv tb_accel_spi_intf.sv; vvp sim_accel"
Run-Step "4. Integrated On-Chip MEMS Sensor & ADC" "iverilog -g2012 -o sim_onchip $SrcDir/mems_afe_adc.sv $SrcDir/onchip_mems_sensor.sv tb_onchip_mems_sensor.sv; vvp sim_onchip"
Run-Step "5. Unified Sensor Hub" "iverilog -g2012 -o sim_hub $SrcDir/sensor_hub.sv tb_sensor_hub.sv; vvp sim_hub"
Run-Step "6. Headless Mobile App Telemetry Unit" "iverilog -g2012 -o sim_telemetry $SrcDir/mobile_telemetry_unit.sv tb_mobile_telemetry.sv; vvp sim_telemetry"
Run-Step "7. Pedometer Classifier (Leg Shaking vs Walking)" "iverilog -g2012 -o sim_classifier $SrcDir/pedometer_classifier.sv tb_pedometer_classifier.sv; vvp sim_classifier"
Run-Step "8. OBI Register File" "iverilog -g2012 -I$IncDir -o sim_regs $IncDir/xstride_regs_pkg.sv $SrcDir/xstride_regs_obi.sv tb_xstride_regs_obi.sv; vvp sim_regs"
Run-Step "9. Full Top-Level SoC Integration & SVA" "iverilog -g2012 -I$IncDir -o sim_top $IncDir/xstride_regs_pkg.sv $SrcDir/rst_sync.sv $SrcDir/sync_2ff.sv $SrcDir/mems_afe_adc.sv $SrcDir/accel_spi_intf.sv $SrcDir/accel_i2c_intf.sv $SrcDir/onchip_mems_sensor.sv $SrcDir/sensor_hub.sv $SrcDir/calib_stage.sv $SrcDir/dsp_frontend.sv $SrcDir/pedometer_classifier.sv $SrcDir/feature_stats.sv $SrcDir/mobile_telemetry_unit.sv $SrcDir/wake_fsm.sv $SrcDir/xstride_regs_obi.sv $SrcDir/xstride_always_on_top.sv $SrcDir/xstride_sva.sv tb_xstride_top.sv; vvp sim_top"
Run-Step "10. Real Accelerometer Dataset Replay & Clinical Accuracy" "iverilog -g2012 -I$IncDir -o sim_replay $IncDir/xstride_regs_pkg.sv $SrcDir/rst_sync.sv $SrcDir/sync_2ff.sv $SrcDir/mems_afe_adc.sv $SrcDir/accel_spi_intf.sv $SrcDir/accel_i2c_intf.sv $SrcDir/onchip_mems_sensor.sv $SrcDir/sensor_hub.sv $SrcDir/calib_stage.sv $SrcDir/dsp_frontend.sv $SrcDir/pedometer_classifier.sv $SrcDir/feature_stats.sv $SrcDir/mobile_telemetry_unit.sv $SrcDir/wake_fsm.sv $SrcDir/xstride_regs_obi.sv $SrcDir/xstride_always_on_top.sv $SrcDir/xstride_sva.sv tb_coverage.sv tb_real_dataset_replay.sv; vvp sim_replay"
Run-Step "11. Constrained Random Verification & SVA Suite" "iverilog -g2012 -o sim_rand $SrcDir/pedometer_classifier.sv tb_pedometer_randomized.sv; vvp sim_rand"
Run-Step "12. X-HEEP Host Platform Wrapper & Fast IRQ Vectors" "iverilog -g2012 -I$IncDir -o sim_heep $IncDir/xstride_regs_pkg.sv $SrcDir/rst_sync.sv $SrcDir/sync_2ff.sv $SrcDir/mems_afe_adc.sv $SrcDir/accel_spi_intf.sv $SrcDir/accel_i2c_intf.sv $SrcDir/onchip_mems_sensor.sv $SrcDir/sensor_hub.sv $SrcDir/calib_stage.sv $SrcDir/dsp_frontend.sv $SrcDir/pedometer_classifier.sv $SrcDir/feature_stats.sv $SrcDir/mobile_telemetry_unit.sv $SrcDir/wake_fsm.sv $SrcDir/xstride_regs_obi.sv $SrcDir/xstride_always_on_top.sv $SrcDir/x_heep_xstride_wrapper.sv tb_heep_wrapper.sv; vvp sim_heep"
Run-Step "13. IEEE 1801 UPF 3.0 Linter & Static Rule Checker" "python check_upf.py"
Run-Step "14. 65nm LP ASIC Physical Synthesis & Power Measurement" "python synth_power_analysis.py"

Write-Host "`n========================================================" -ForegroundColor Green
Write-Host " ALL 14 TESTBENCHES & ANALYSIS CHECKS PASSED WITH 100% SUCCESS!" -ForegroundColor Green
Write-Host "========================================================`n" -ForegroundColor Green
