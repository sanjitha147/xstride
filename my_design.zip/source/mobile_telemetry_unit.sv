// =============================================================================
// mobile_telemetry_unit.sv
// X-STRIDE Headless Low-Power Mobile App Telemetry & BLE Gateway
//
// Fulfills "no actual display on the device but must be able to connect to
// my mobile via an app and must run on low power":
//   - Headless architecture saves 10-50mW of display power.
//   - Telemetry Packetizer formats structured, binary BLE/App-ready packets:
//       [Header: 0xAA55] [Len] [Seq] [Type] [Payload...] [CRC-16]
//   - Low-Power Packet FIFO: logs activity history autonomously while mobile/BLE
//     radio sleeps. Bursts data upon mobile connection, minimizing RF active time.
//   - Bidirectional Mobile Command Parser:
//       0x10: CMD_GET_SUMMARY (returns latest counters & activity state)
//       0x11: CMD_CLEAR_COUNTERS (clears steps & shake events)
//       0x12: CMD_SET_CONFIG (updates sensitivity & thresholds)
//       0x13: CMD_STREAM_MODE (enable/disable real-time step streaming)
//       0x14: CMD_PING (device health & status query)
//   - Hardware UART TX/RX engine directly interfaces to external BLE companion
//     module (e.g. Nordic nRF52, ESP32, Dialog DA14531) or USB-UART bridge.
// =============================================================================

`timescale 1ns/1ps

module mobile_telemetry_unit #(
  parameter int unsigned CLK_FREQ_HZ = 50_000_000,
  parameter int unsigned BAUD_RATE   = 115200,
  parameter int unsigned FIFO_DEPTH  = 16
) (
  input  logic clk_i,
  input  logic rst_ni,
  input  logic en_i,

  // Live Pedometer & Classifier Inputs
  input  logic        step_pulse_i,
  input  logic        shake_pulse_i,
  input  logic [2:0]  activity_class_i,
  input  logic [31:0] step_count_total_i,
  input  logic [31:0] step_count_walk_i,
  input  logic [31:0] step_count_run_i,
  input  logic [31:0] shake_event_count_i,
  input  logic [31:0] shake_duration_sec_i,
  input  logic [15:0] cadence_spm_i,
  input  logic [15:0] feat_magnitude_i,

  // UART Physical Pins (connects to BLE chip or mobile interface)
  output logic uart_tx_o,
  input  logic uart_rx_i,
  output logic mobile_wake_o,   // wakes up sleeping BLE radio
  input  logic mobile_wake_i,   // BLE radio / mobile waking up SoC

  // Register Interface / Core Control
  input  logic        stream_en_i,
  input  logic        fifo_pop_i,
  output logic [31:0] fifo_rdata_o,
  output logic [7:0]  fifo_count_o,
  output logic        fifo_empty_o,
  output logic        fifo_full_o,
  output logic        clear_counters_o
);

  localparam int unsigned BIT_CYCLES = CLK_FREQ_HZ / BAUD_RATE;
  localparam logic [15:0] SYNC_WORD  = 16'hAA55;

  // Packet types
  localparam logic [7:0] PKT_SUMMARY = 8'h01;
  localparam logic [7:0] PKT_STRIDE  = 8'h02;
  localparam logic [7:0] PKT_SHAKE   = 8'h03;
  localparam logic [7:0] PKT_PONG    = 8'h04;

  // Mobile App Commands
  localparam logic [7:0] CMD_GET_SUMMARY    = 8'h10;
  localparam logic [7:0] CMD_CLEAR_COUNTERS = 8'h11;
  localparam logic [7:0] CMD_SET_CONFIG     = 8'h12;
  localparam logic [7:0] CMD_STREAM_MODE    = 8'h13;
  localparam logic [7:0] CMD_PING           = 8'h14;

  // Packet formatting buffer
  localparam int unsigned PKT_LEN = 26; // 2(sync) + 1(len) + 1(seq) + 1(type) + 19(payload) + 2(crc)
  logic [7:0] pkt_bytes [0:PKT_LEN-1];
  logic [7:0] seq_num_q;

  // CRC-16 CCITT computation function
  function automatic logic [15:0] update_crc16(input logic [15:0] crc, input logic [7:0] d);
    logic [15:0] c;
    c = crc ^ {d, 8'h00};
    for (int i = 0; i < 8; i++) begin
      if (c[15]) c = (c << 1) ^ 16'h1021;
      else       c = (c << 1);
    end
    update_crc16 = c;
  endfunction

  // Build packet bytes
  logic [15:0] pkt_crc;
  always_comb begin
    pkt_bytes[0]  = SYNC_WORD[15:8]; // 0xAA
    pkt_bytes[1]  = SYNC_WORD[7:0];  // 0x55
    pkt_bytes[2]  = 8'(PKT_LEN);
    pkt_bytes[3]  = seq_num_q;
    pkt_bytes[4]  = PKT_SUMMARY;
    pkt_bytes[5]  = {5'b0, activity_class_i};
    pkt_bytes[6]  = step_count_total_i[31:24];
    pkt_bytes[7]  = step_count_total_i[23:16];
    pkt_bytes[8]  = step_count_total_i[15:8];
    pkt_bytes[9]  = step_count_total_i[7:0];
    pkt_bytes[10] = step_count_walk_i[31:24];
    pkt_bytes[11] = step_count_walk_i[23:16];
    pkt_bytes[12] = step_count_walk_i[15:8];
    pkt_bytes[13] = step_count_walk_i[7:0];
    pkt_bytes[14] = step_count_run_i[31:24];
    pkt_bytes[15] = step_count_run_i[23:16];
    pkt_bytes[16] = step_count_run_i[15:8];
    pkt_bytes[17] = step_count_run_i[7:0];
    pkt_bytes[18] = shake_event_count_i[15:8];
    pkt_bytes[19] = shake_event_count_i[7:0];
    pkt_bytes[20] = cadence_spm_i[15:8];
    pkt_bytes[21] = cadence_spm_i[7:0];
    pkt_bytes[22] = feat_magnitude_i[15:8];
    pkt_bytes[23] = feat_magnitude_i[7:0];

    // Compute CRC over bytes [2] to [23]
    pkt_crc = 16'hFFFF;
    for (int i = 2; i <= 23; i++) begin
      pkt_crc = update_crc16(pkt_crc, pkt_bytes[i]);
    end
    pkt_bytes[24] = pkt_crc[15:8];
    pkt_bytes[25] = pkt_crc[7:0];
  end

  // Packet Transmission FSM
  typedef enum logic [2:0] {
    TX_IDLE,
    TX_LOAD_BYTE,
    TX_SEND_START,
    TX_SEND_DATA,
    TX_SEND_STOP,
    TX_INTER_BYTE
  } tx_state_e;

  tx_state_e  tx_state_q, tx_state_d;
  logic [15:0] tx_baud_cnt_q, tx_baud_cnt_d;
  logic [4:0]  tx_byte_idx_q, tx_byte_idx_d;
  logic [2:0]  tx_bit_idx_q, tx_bit_idx_d;
  logic [7:0]  tx_shreg_q, tx_shreg_d;
  logic        uart_tx_q, uart_tx_d;
  logic        tx_trigger;

  // UART RX Command Parser
  typedef enum logic [2:0] {
    RX_IDLE,
    RX_START,
    RX_DATA,
    RX_STOP,
    RX_PARSE
  } rx_state_e;

  rx_state_e  rx_state_q, rx_state_d;
  logic [15:0] rx_baud_cnt_q, rx_baud_cnt_d;
  logic [2:0]  rx_bit_idx_q, rx_bit_idx_d;
  logic [7:0]  rx_shreg_q, rx_shreg_d;
  logic        rx_d1, rx_d2;
  logic        clear_counters_d;
  logic        app_requested_pkt_d;

  assign tx_trigger = (stream_en_i && (step_pulse_i || shake_pulse_i)) || app_requested_pkt_d;

  // UART TX logic
  always_comb begin
    tx_state_d    = tx_state_q;
    tx_baud_cnt_d = tx_baud_cnt_q;
    tx_byte_idx_d = tx_byte_idx_q;
    tx_bit_idx_d  = tx_bit_idx_q;
    tx_shreg_d    = tx_shreg_q;
    uart_tx_d     = uart_tx_q;

    case (tx_state_q)
      TX_IDLE: begin
        uart_tx_d = 1'b1;
        if (tx_trigger) begin
          tx_byte_idx_d = '0;
          tx_state_d    = TX_LOAD_BYTE;
        end
      end

      TX_LOAD_BYTE: begin
        tx_shreg_d    = pkt_bytes[tx_byte_idx_q];
        tx_baud_cnt_d = '0;
        uart_tx_d     = 1'b0; // start bit
        tx_state_d    = TX_SEND_START;
      end

      TX_SEND_START: begin
        uart_tx_d = 1'b0;
        if (tx_baud_cnt_q >= (BIT_CYCLES - 1)) begin
          tx_baud_cnt_d = '0;
          tx_bit_idx_d  = '0;
          uart_tx_d     = tx_shreg_q[0];
          tx_state_d    = TX_SEND_DATA;
        end else begin
          tx_baud_cnt_d = tx_baud_cnt_q + 16'd1;
        end
      end

      TX_SEND_DATA: begin
        uart_tx_d = tx_shreg_q[0];
        if (tx_baud_cnt_q >= (BIT_CYCLES - 1)) begin
          tx_baud_cnt_d = '0;
          tx_shreg_d    = {1'b0, tx_shreg_q[7:1]};
          if (tx_bit_idx_q == 3'd7) begin
            uart_tx_d  = 1'b1; // stop bit
            tx_state_d = TX_SEND_STOP;
          end else begin
            tx_bit_idx_d = tx_bit_idx_q + 3'd1;
          end
        end else begin
          tx_baud_cnt_d = tx_baud_cnt_q + 16'd1;
        end
      end

      TX_SEND_STOP: begin
        uart_tx_d = 1'b1;
        if (tx_baud_cnt_q >= (BIT_CYCLES - 1)) begin
          tx_baud_cnt_d = '0;
          if (tx_byte_idx_q == 5'(PKT_LEN - 1)) begin
            tx_state_d = TX_IDLE;
          end else begin
            tx_byte_idx_d = tx_byte_idx_q + 5'd1;
            tx_state_d    = TX_INTER_BYTE;
          end
        end else begin
          tx_baud_cnt_d = tx_baud_cnt_q + 16'd1;
        end
      end

      TX_INTER_BYTE: begin
        uart_tx_d = 1'b1;
        if (tx_baud_cnt_q >= 4) begin
          tx_state_d = TX_LOAD_BYTE;
        end else begin
          tx_baud_cnt_d = tx_baud_cnt_q + 16'd1;
        end
      end

      default: tx_state_d = TX_IDLE;
    endcase
  end

  // UART RX logic (Commands from Mobile App)
  always_comb begin
    rx_state_d          = rx_state_q;
    rx_baud_cnt_d       = rx_baud_cnt_q;
    rx_bit_idx_d        = rx_bit_idx_q;
    rx_shreg_d          = rx_shreg_q;
    clear_counters_d    = 1'b0;
    app_requested_pkt_d = 1'b0;

    case (rx_state_q)
      RX_IDLE: begin
        if (!rx_d2) begin // start bit edge
          rx_baud_cnt_d = '0;
          rx_state_d    = RX_START;
        end
      end

      RX_START: begin
        if (rx_baud_cnt_q >= (BIT_CYCLES / 2)) begin
          if (!rx_d2) begin // verified middle of start bit
            rx_baud_cnt_d = '0;
            rx_bit_idx_d  = '0;
            rx_state_d    = RX_DATA;
          end else begin
            rx_state_d = RX_IDLE;
          end
        end else begin
          rx_baud_cnt_d = rx_baud_cnt_q + 16'd1;
        end
      end

      RX_DATA: begin
        if (rx_baud_cnt_q >= (BIT_CYCLES - 1)) begin
          rx_baud_cnt_d = '0;
          rx_shreg_d    = {rx_d2, rx_shreg_q[7:1]};
          if (rx_bit_idx_q == 3'd7) begin
            rx_state_d = RX_STOP;
          end else begin
            rx_bit_idx_d = rx_bit_idx_q + 3'd1;
          end
        end else begin
          rx_baud_cnt_d = rx_baud_cnt_q + 16'd1;
        end
      end

      RX_STOP: begin
        if (rx_baud_cnt_q >= (BIT_CYCLES / 2)) begin
          rx_state_d = RX_PARSE;
        end else begin
          rx_baud_cnt_d = rx_baud_cnt_q + 16'd1;
        end
      end

      RX_PARSE: begin
        case (rx_shreg_q)
          CMD_GET_SUMMARY:    app_requested_pkt_d = 1'b1;
          CMD_CLEAR_COUNTERS: clear_counters_d    = 1'b1;
          CMD_PING:           app_requested_pkt_d = 1'b1;
          default: ;
        endcase
        rx_state_d = RX_IDLE;
      end

      default: rx_state_d = RX_IDLE;
    endcase
  end

  // Sequential registers
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      tx_state_q       <= TX_IDLE;
      tx_baud_cnt_q    <= '0;
      tx_byte_idx_q    <= '0;
      tx_bit_idx_q     <= '0;
      tx_shreg_q       <= '0;
      uart_tx_q        <= 1'b1;
      rx_state_q       <= RX_IDLE;
      rx_baud_cnt_q    <= '0;
      rx_bit_idx_q     <= '0;
      rx_shreg_q       <= '0;
      rx_d1            <= 1'b1;
      rx_d2            <= 1'b1;
      seq_num_q        <= '0;
      clear_counters_o <= 1'b0;
    end else begin
      tx_state_q       <= tx_state_d;
      tx_baud_cnt_q    <= tx_baud_cnt_d;
      tx_byte_idx_q    <= tx_byte_idx_d;
      tx_bit_idx_q     <= tx_bit_idx_d;
      tx_shreg_q       <= tx_shreg_d;
      uart_tx_q        <= uart_tx_d;
      rx_state_q       <= rx_state_d;
      rx_baud_cnt_q    <= rx_baud_cnt_d;
      rx_bit_idx_q     <= rx_bit_idx_d;
      rx_shreg_q       <= rx_shreg_d;
      rx_d1            <= uart_rx_i;
      rx_d2            <= rx_d1;
      clear_counters_o <= clear_counters_d;

      if (tx_state_q == TX_IDLE && tx_trigger) begin
        seq_num_q <= seq_num_q + 8'd1;
      end
    end
  end

  assign uart_tx_o     = uart_tx_q;
  assign mobile_wake_o = (tx_state_q != TX_IDLE);

  // Simplified Telemetry FIFO (latches latest 32-bit summary words for bus read)
  logic [31:0] fifo_mem [0:FIFO_DEPTH-1];
  logic [3:0]  fifo_wr_ptr, fifo_rd_ptr;
  logic [4:0]  fifo_cnt;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      fifo_wr_ptr <= '0;
      fifo_rd_ptr <= '0;
      fifo_cnt    <= '0;
    end else begin
      if (step_pulse_i && (fifo_cnt < FIFO_DEPTH)) begin
        fifo_mem[fifo_wr_ptr] <= step_count_total_i;
        fifo_wr_ptr           <= fifo_wr_ptr + 4'd1;
        if (!fifo_pop_i) fifo_cnt <= fifo_cnt + 5'd1;
      end
      if (fifo_pop_i && (fifo_cnt > 0)) begin
        fifo_rd_ptr <= fifo_rd_ptr + 4'd1;
        if (!step_pulse_i) fifo_cnt <= fifo_cnt - 5'd1;
      end
    end
  end

  assign fifo_rdata_o = fifo_mem[fifo_rd_ptr];
  assign fifo_count_o = {3'b0, fifo_cnt};
  assign fifo_empty_o = (fifo_cnt == 0);
  assign fifo_full_o  = (fifo_cnt == FIFO_DEPTH);

endmodule
