// =============================================================================
// accel_i2c_intf.sv
// X-STRIDE External Accelerometer I2C Master Interface
//
// Provides standard 2-wire I2C sensor integration for external digital IMUs:
//   - Open-drain SCL and SDA control
//   - Fast-Mode (400 kHz) bus timing generator
//   - Periodic burst read of X, Y, Z axis registers (6 data bytes)
//   - Power-gated via en_i from Wake FSM
// =============================================================================

`timescale 1ns/1ps

module accel_i2c_intf #(
  parameter int unsigned CLK_DIV              = 32,       // scl_clk = clk_i / (4 * CLK_DIV)
  parameter int unsigned SAMPLE_PERIOD_CYCLES = 32'd500_000,
  parameter logic [6:0]  DEVICE_ADDR          = 7'h68,    // standard 7-bit IMU I2C address
  parameter logic [7:0]  DATA_REG_START       = 8'h3B     // starting X-axis data register
) (
  input  logic clk_i,
  input  logic rst_ni,
  input  logic en_i,

  // I2C Open-drain bus signals
  output logic scl_o,
  output logic scl_oe,
  output logic sda_o,
  output logic sda_oe,
  input  logic sda_i,

  // Decoded sampled data
  output logic               sample_valid_o,
  output logic signed [15:0] accel_x_o,
  output logic signed [15:0] accel_y_o,
  output logic signed [15:0] accel_z_o
);

  typedef enum logic [3:0] {
    ST_IDLE,
    ST_WAIT,
    ST_START,
    ST_DEV_ADDR_W,
    ST_ACK_DEV_W,
    ST_REG_ADDR,
    ST_ACK_REG,
    ST_RESTART,
    ST_DEV_ADDR_R,
    ST_ACK_DEV_R,
    ST_READ_BYTES,
    ST_SEND_ACK_NACK,
    ST_STOP
  } state_e;

  state_e      state_q, state_d;
  logic [31:0] period_cnt_q, period_cnt_d;
  logic [15:0] div_cnt_q, div_cnt_d;
  logic [1:0]  phase_q, phase_d;
  logic [3:0]  bit_cnt_q, bit_cnt_d;
  logic [2:0]  byte_cnt_q, byte_cnt_d;
  logic [7:0]  shreg_q, shreg_d;
  logic [47:0] rx_data_q, rx_data_d;

  logic        scl_q, scl_d;
  logic        sda_q, sda_d;
  logic        sample_valid_d;

  always_comb begin
    state_d        = state_q;
    period_cnt_d   = period_cnt_q;
    div_cnt_d      = div_cnt_q;
    phase_d        = phase_q;
    bit_cnt_d      = bit_cnt_q;
    byte_cnt_d     = byte_cnt_q;
    shreg_d        = shreg_q;
    rx_data_d      = rx_data_q;
    scl_d          = scl_q;
    sda_d          = sda_q;
    sample_valid_d = 1'b0;

    if (!en_i) begin
      state_d      = ST_IDLE;
      period_cnt_d = '0;
      scl_d        = 1'b1;
      sda_d        = 1'b1;
    end else begin
      case (state_q)
        ST_IDLE: begin
          scl_d        = 1'b1;
          sda_d        = 1'b1;
          period_cnt_d = '0;
          state_d      = ST_WAIT;
        end

        ST_WAIT: begin
          scl_d = 1'b1;
          sda_d = 1'b1;
          if (period_cnt_q >= SAMPLE_PERIOD_CYCLES) begin
            period_cnt_d = '0;
            state_d      = ST_START;
            div_cnt_d    = '0;
            phase_d      = '0;
          end else begin
            period_cnt_d = period_cnt_q + 32'd1;
          end
        end

        ST_START: begin
          // Generate START condition: SDA goes low while SCL is high
          if (div_cnt_q >= CLK_DIV) begin
            div_cnt_d = '0;
            sda_d     = 1'b0;
            scl_d     = 1'b1;
            state_d   = ST_DEV_ADDR_W;
            shreg_d   = {DEVICE_ADDR, 1'b0}; // write
            bit_cnt_d = 4'd7;
            phase_d   = '0;
          end else begin
            div_cnt_d = div_cnt_q + 16'd1;
          end
        end

        ST_DEV_ADDR_W, ST_REG_ADDR, ST_DEV_ADDR_R: begin
          if (div_cnt_q >= CLK_DIV) begin
            div_cnt_d = '0;
            phase_d   = phase_q + 2'd1;
            case (phase_q)
              2'b00: begin scl_d = 1'b0; sda_d = shreg_q[bit_cnt_q]; end
              2'b01: begin scl_d = 1'b1; end
              2'b10: begin scl_d = 1'b1; end
              2'b11: begin
                scl_d = 1'b0;
                if (bit_cnt_q == 0) begin
                  if (state_q == ST_DEV_ADDR_W) state_d = ST_ACK_DEV_W;
                  else if (state_q == ST_REG_ADDR) state_d = ST_ACK_REG;
                  else state_d = ST_ACK_DEV_R;
                end else begin
                  bit_cnt_d = bit_cnt_q - 4'd1;
                end
              end
            endcase
          end else begin
            div_cnt_d = div_cnt_q + 16'd1;
          end
        end

        ST_ACK_DEV_W, ST_ACK_REG, ST_ACK_DEV_R: begin
          if (div_cnt_q >= CLK_DIV) begin
            div_cnt_d = '0;
            phase_d   = phase_q + 2'd1;
            case (phase_q)
              2'b00: begin scl_d = 1'b0; sda_d = 1'b1; end // release SDA for slave ACK
              2'b01: begin scl_d = 1'b1; end
              2'b10: begin scl_d = 1'b1; end
              2'b11: begin
                scl_d = 1'b0;
                if (state_q == ST_ACK_DEV_W) begin
                  state_d   = ST_REG_ADDR;
                  shreg_d   = DATA_REG_START;
                  bit_cnt_d = 4'd7;
                end else if (state_q == ST_ACK_REG) begin
                  state_d = ST_RESTART;
                end else begin
                  state_d    = ST_READ_BYTES;
                  byte_cnt_d = 3'd0;
                  bit_cnt_d  = 4'd7;
                end
              end
            endcase
          end else begin
            div_cnt_d = div_cnt_q + 16'd1;
          end
        end

        ST_RESTART: begin
          if (div_cnt_q >= CLK_DIV) begin
            div_cnt_d = '0;
            phase_d   = phase_q + 2'd1;
            case (phase_q)
              2'b00: begin scl_d = 1'b0; sda_d = 1'b1; end
              2'b01: begin scl_d = 1'b1; sda_d = 1'b1; end
              2'b10: begin scl_d = 1'b1; sda_d = 1'b0; end // repeated start
              2'b11: begin
                scl_d     = 1'b0;
                state_d   = ST_DEV_ADDR_R;
                shreg_d   = {DEVICE_ADDR, 1'b1}; // read
                bit_cnt_d = 4'd7;
              end
            endcase
          end else begin
            div_cnt_d = div_cnt_q + 16'd1;
          end
        end

        ST_READ_BYTES: begin
          if (div_cnt_q >= CLK_DIV) begin
            div_cnt_d = '0;
            phase_d   = phase_q + 2'd1;
            case (phase_q)
              2'b00: begin scl_d = 1'b0; sda_d = 1'b1; end
              2'b01: begin scl_d = 1'b1; end
              2'b10: begin
                scl_d = 1'b1;
                rx_data_d = {rx_data_q[46:0], sda_i};
              end
              2'b11: begin
                scl_d = 1'b0;
                if (bit_cnt_q == 0) begin
                  state_d = ST_SEND_ACK_NACK;
                end else begin
                  bit_cnt_d = bit_cnt_q - 4'd1;
                end
              end
            endcase
          end else begin
            div_cnt_d = div_cnt_q + 16'd1;
          end
        end

        ST_SEND_ACK_NACK: begin
          if (div_cnt_q >= CLK_DIV) begin
            div_cnt_d = '0;
            phase_d   = phase_q + 2'd1;
            case (phase_q)
              2'b00: begin
                scl_d = 1'b0;
                sda_d = (byte_cnt_q == 3'd5) ? 1'b1 : 1'b0; // NACK on last byte (byte 5 of 6), ACK otherwise
              end
              2'b01: begin scl_d = 1'b1; end
              2'b10: begin scl_d = 1'b1; end
              2'b11: begin
                scl_d = 1'b0;
                if (byte_cnt_q == 3'd5) begin
                  state_d = ST_STOP;
                end else begin
                  byte_cnt_d = byte_cnt_q + 3'd1;
                  bit_cnt_d  = 4'd7;
                  state_d    = ST_READ_BYTES;
                end
              end
            endcase
          end else begin
            div_cnt_d = div_cnt_q + 16'd1;
          end
        end

        ST_STOP: begin
          if (div_cnt_q >= CLK_DIV) begin
            div_cnt_d = '0;
            phase_d   = phase_q + 2'd1;
            case (phase_q)
              2'b00: begin scl_d = 1'b0; sda_d = 1'b0; end
              2'b01: begin scl_d = 1'b1; sda_d = 1'b0; end
              2'b10: begin scl_d = 1'b1; sda_d = 1'b1; end // STOP condition: SDA rises while SCL high
              2'b11: begin
                sample_valid_d = 1'b1;
                state_d        = ST_WAIT;
                period_cnt_d   = '0;
              end
            endcase
          end else begin
            div_cnt_d = div_cnt_q + 16'd1;
          end
        end

        default: state_d = ST_IDLE;
      endcase
    end
  end

  // Sequential registers
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q        <= ST_IDLE;
      period_cnt_q   <= '0;
      div_cnt_q      <= '0;
      phase_q        <= '0;
      bit_cnt_q      <= '0;
      byte_cnt_q     <= '0;
      shreg_q        <= '0;
      rx_data_q      <= '0;
      scl_q          <= 1'b1;
      sda_q          <= 1'b1;
      sample_valid_o <= 1'b0;
      accel_x_o      <= '0;
      accel_y_o      <= '0;
      accel_z_o      <= '0;
    end else begin
      state_q        <= state_d;
      period_cnt_q   <= period_cnt_d;
      div_cnt_q      <= div_cnt_d;
      phase_q        <= phase_d;
      bit_cnt_q      <= bit_cnt_d;
      byte_cnt_q     <= byte_cnt_d;
      shreg_q        <= shreg_d;
      rx_data_q      <= rx_data_d;
      scl_q          <= scl_d;
      sda_q          <= sda_d;
      sample_valid_o <= sample_valid_d;

      if (sample_valid_d) begin
        accel_x_o <= rx_data_q[47:32];
        accel_y_o <= rx_data_q[31:16];
        accel_z_o <= rx_data_q[15:0];
      end
    end
  end

  // I2C Open-drain drive logic
  assign scl_o  = 1'b0;
  assign scl_oe = ~scl_q; // drive low when scl_q is 0, float high (pull-up) when 1
  assign sda_o  = 1'b0;
  assign sda_oe = ~sda_q; // drive low when sda_q is 0, float high (pull-up) when 1

endmodule
