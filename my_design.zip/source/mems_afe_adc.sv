// =============================================================================
// mems_afe_adc.sv
// X-STRIDE Integrated Mixed-Signal MEMS Analog Front-End & 14-bit SAR ADC Macro
//
// Models the physical mixed-signal boundary for a 2-die SiP / CMOS-MEMS IC:
//   1. Differential Capacitive Sensing Bridge:
//      - Senses proof-mass deflection: Delta_C = C_p - C_n proportional to acceleration.
//      - Electrostatic self-test actuation plates (deflection force via V_ST).
//   2. Low-Noise Switched-Capacitor Charge Amplifier:
//      - Converts Delta_C into differential analog voltage V_diff.
//      - Variable gain amplifier (VGA) for programmable full-scale range (+/-2g to +/-16g).
//      - 8-bit Trim DAC for Zero-g offset cancellation.
//   3. 14-bit Successive Approximation Register (SAR) ADC:
//      - Sample-and-hold phase (Track) followed by 14 successive approximation clock cycles.
//      - Generates clean 16-bit sign-extended two's complement acceleration codes.
// =============================================================================

`timescale 1ns/1ps

module mems_afe_adc #(
  parameter int unsigned SAR_CYCLES = 14 // 14-bit SAR ADC conversion cycles
) (
  input  logic clk_i,
  input  logic rst_ni,
  input  logic pwr_en_i,        // analog AFE supply enable

  // Conversion trigger / sample request
  input  logic sample_trig_i,

  // Physical capacitive sense inputs (differential capacitance in fF / behavioral scale)
  input  logic signed [15:0] cap_diff_x_i, // Delta C_x (fF)
  input  logic signed [15:0] cap_diff_y_i, // Delta C_y (fF)
  input  logic signed [15:0] cap_diff_z_i, // Delta C_z (fF)

  // Analog Configuration & Trim
  input  logic               self_test_en_i,
  input  logic [1:0]         gain_range_i,   // 00: 2g (highest gain), 01: 4g, 10: 8g, 11: 16g
  input  logic signed [15:0] trim_x_i,       // Zero-g offset trim DAC (16-bit resolution)
  input  logic signed [15:0] trim_y_i,
  input  logic signed [15:0] trim_z_i,

  // ADC Digital Outputs
  output logic               adc_eoc_o,      // end-of-conversion pulse (1 cycle)
  output logic signed [15:0] adc_data_x_o,
  output logic signed [15:0] adc_data_y_o,
  output logic signed [15:0] adc_data_z_o
);

  // Electrostatic self-test deflection equivalent (+0.5g deflection in fF)
  localparam logic signed [15:0] C_ST_DEFLECTION = 16'sd4096;

  typedef enum logic [1:0] {
    ADC_IDLE,
    ADC_SAMPLE_HOLD,
    ADC_CONVERT,
    ADC_DONE
  } adc_fsm_e;

  adc_fsm_e   fsm_q, fsm_d;
  logic [4:0] sar_cnt_q, sar_cnt_d;

  // Charge Amplifier differential voltage simulation
  logic signed [15:0] amp_x_q, amp_y_q, amp_z_q;
  logic signed [15:0] amp_x_d, amp_y_d, amp_z_d;
  logic signed [15:0] raw_cx, raw_cy, raw_cz;

  always_comb begin
    // 1. Differential Capacitive Bridge Summation
    if (self_test_en_i) begin
      raw_cx = cap_diff_x_i + C_ST_DEFLECTION;
      raw_cy = cap_diff_y_i + C_ST_DEFLECTION;
      raw_cz = cap_diff_z_i + C_ST_DEFLECTION;
    end else begin
      raw_cx = cap_diff_x_i;
      raw_cy = cap_diff_y_i;
      raw_cz = cap_diff_z_i;
    end

    // 2. Charge Amplifier + Zero-g Trim DAC Injection
    amp_x_d = raw_cx + trim_x_i;
    amp_y_d = raw_cy + trim_y_i;
    amp_z_d = raw_cz + trim_z_i;

    // 3. Variable Gain Amplifier (Full Scale Scaling)
    case (gain_range_i)
      2'b00: begin // +/- 2g mode (unity / highest gain)
        amp_x_d = amp_x_d;
        amp_y_d = amp_y_d;
        amp_z_d = amp_z_d;
      end
      2'b01: begin // +/- 4g mode
        amp_x_d = amp_x_d >>> 1;
        amp_y_d = amp_y_d >>> 1;
        amp_z_d = amp_z_d >>> 1;
      end
      2'b10: begin // +/- 8g mode
        amp_x_d = amp_x_d >>> 2;
        amp_y_d = amp_y_d >>> 2;
        amp_z_d = amp_z_d >>> 2;
      end
      2'b11: begin // +/- 16g mode
        amp_x_d = amp_x_d >>> 3;
        amp_y_d = amp_y_d >>> 3;
        amp_z_d = amp_z_d >>> 3;
      end
    endcase
  end

  // 14-bit SAR ADC State Machine
  logic signed [15:0] sampled_x_q, sampled_x_d;
  logic signed [15:0] sampled_y_q, sampled_y_d;
  logic signed [15:0] sampled_z_q, sampled_z_d;
  logic               eoc_d;

  always_comb begin
    fsm_d       = fsm_q;
    sar_cnt_d   = sar_cnt_q;
    sampled_x_d = sampled_x_q;
    sampled_y_d = sampled_y_q;
    sampled_z_d = sampled_z_q;
    eoc_d       = 1'b0;

    if (!pwr_en_i) begin
      fsm_d     = ADC_IDLE;
      sar_cnt_d = '0;
    end else begin
      case (fsm_q)
        ADC_IDLE: begin
          if (sample_trig_i) begin
            fsm_d = ADC_SAMPLE_HOLD;
          end
        end

        ADC_SAMPLE_HOLD: begin
          // Track & Hold: capture analog differential voltage on capacitor DAC
          sampled_x_d = amp_x_d;
          sampled_y_d = amp_y_d;
          sampled_z_d = amp_z_d;
          sar_cnt_d   = 5'd0;
          fsm_d       = ADC_CONVERT;
        end

        ADC_CONVERT: begin
          // Emulate SAR bit trial cycles (14 conversion clocks)
          if (sar_cnt_q >= 5'(SAR_CYCLES - 1)) begin
            fsm_d     = ADC_DONE;
            eoc_d     = 1'b1; // pulse EOC
          end else begin
            sar_cnt_d = sar_cnt_q + 5'd1;
          end
        end

        ADC_DONE: begin
          fsm_d = ADC_IDLE;
        end

        default: fsm_d = ADC_IDLE;
      endcase
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      fsm_q         <= ADC_IDLE;
      sar_cnt_q     <= '0;
      sampled_x_q   <= '0;
      sampled_y_q   <= '0;
      sampled_z_q   <= '0;
      adc_eoc_o     <= 1'b0;
      adc_data_x_o  <= '0;
      adc_data_y_o  <= '0;
      adc_data_z_o  <= '0;
    end else begin
      fsm_q       <= fsm_d;
      sar_cnt_q   <= sar_cnt_d;
      sampled_x_q <= sampled_x_d;
      sampled_y_q <= sampled_y_d;
      sampled_z_q <= sampled_z_d;
      adc_eoc_o   <= eoc_d;

      if (eoc_d) begin
        adc_data_x_o <= sampled_x_d;
        adc_data_y_o <= sampled_y_d;
        adc_data_z_o <= sampled_z_d;
      end
    end
  end

endmodule
