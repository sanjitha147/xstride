// =============================================================================
// sensor_hub.sv
// X-STRIDE Unified Sensor Hub & Multiplexer
//
// Fulfills "add places for sensors integration if possible add the sensor in the chip itself":
//   - Glueless multiplexing between:
//       2'b00: External SPI Accelerometer / IMU (accel_spi_intf)
//       2'b01: External I2C Accelerometer / IMU (accel_i2c_intf)
//       2'b10: Internal Monolithic On-Chip MEMS Accelerometer (onchip_mems_sensor)
//       2'b11: Test Injection / Direct Software Emulation
//   - Programmable axis remapping & orientation compensation (swapping X, Y, Z or polarity)
//   - Synchronized sample valid output to DSP front-end and Pedometer Classifier
// =============================================================================

`timescale 1ns/1ps

module sensor_hub #(
  parameter int unsigned DATA_W = 16
) (
  input  logic clk_i,
  input  logic rst_ni,

  // Configuration
  input  logic [1:0] sensor_sel_i,      // 00: SPI, 01: I2C, 10: On-Chip MEMS, 11: Direct Injection
  input  logic [2:0] axis_remap_i,      // axis swap configuration
  input  logic [2:0] axis_invert_i,     // negate X, Y, or Z

  // Source 0: External SPI Accelerometer
  input  logic                      spi_sample_valid_i,
  input  logic signed [DATA_W-1:0]  spi_accel_x_i,
  input  logic signed [DATA_W-1:0]  spi_accel_y_i,
  input  logic signed [DATA_W-1:0]  spi_accel_z_i,

  // Source 1: External I2C Accelerometer
  input  logic                      i2c_sample_valid_i,
  input  logic signed [DATA_W-1:0]  i2c_accel_x_i,
  input  logic signed [DATA_W-1:0]  i2c_accel_y_i,
  input  logic signed [DATA_W-1:0]  i2c_accel_z_i,

  // Source 2: Integrated On-Chip MEMS Accelerometer
  input  logic                      onchip_sample_valid_i,
  input  logic signed [DATA_W-1:0]  onchip_accel_x_i,
  input  logic signed [DATA_W-1:0]  onchip_accel_y_i,
  input  logic signed [DATA_W-1:0]  onchip_accel_z_i,

  // Source 3: Direct Software / Testbench Injection
  input  logic                      direct_sample_valid_i,
  input  logic signed [DATA_W-1:0]  direct_accel_x_i,
  input  logic signed [DATA_W-1:0]  direct_accel_y_i,
  input  logic signed [DATA_W-1:0]  direct_accel_z_i,

  // Unified Output to DSP Front-End & Classifier
  output logic                      sample_valid_o,
  output logic signed [DATA_W-1:0]  accel_x_o,
  output logic signed [DATA_W-1:0]  accel_y_o,
  output logic signed [DATA_W-1:0]  accel_z_o
);

  logic                      mux_valid;
  logic signed [DATA_W-1:0]  mux_x, mux_y, mux_z;
  logic signed [DATA_W-1:0]  remap_x, remap_y, remap_z;
  logic signed [DATA_W-1:0]  final_x, final_y, final_z;

  // Source selection multiplexer
  always_comb begin
    case (sensor_sel_i)
      2'b00: begin // External SPI
        mux_valid = spi_sample_valid_i;
        mux_x     = spi_accel_x_i;
        mux_y     = spi_accel_y_i;
        mux_z     = spi_accel_z_i;
      end
      2'b01: begin // External I2C
        mux_valid = i2c_sample_valid_i;
        mux_x     = i2c_accel_x_i;
        mux_y     = i2c_accel_y_i;
        mux_z     = i2c_accel_z_i;
      end
      2'b10: begin // Integrated On-Chip MEMS
        mux_valid = onchip_sample_valid_i;
        mux_x     = onchip_accel_x_i;
        mux_y     = onchip_accel_y_i;
        mux_z     = onchip_accel_z_i;
      end
      2'b11: begin // Direct test injection
        mux_valid = direct_sample_valid_i;
        mux_x     = direct_accel_x_i;
        mux_y     = direct_accel_y_i;
        mux_z     = direct_accel_z_i;
      end
    endcase
  end

  // Axis remapping (supports wearable orientation variations)
  always_comb begin
    case (axis_remap_i)
      3'b000: begin remap_x = mux_x; remap_y = mux_y; remap_z = mux_z; end // X, Y, Z
      3'b001: begin remap_x = mux_y; remap_y = mux_x; remap_z = mux_z; end // Y, X, Z
      3'b010: begin remap_x = mux_x; remap_y = mux_z; remap_z = mux_y; end // X, Z, Y
      3'b011: begin remap_x = mux_z; remap_y = mux_y; remap_z = mux_x; end // Z, Y, X
      default: begin remap_x = mux_x; remap_y = mux_y; remap_z = mux_z; end
    endcase

    final_x = axis_invert_i[0] ? -remap_x : remap_x;
    final_y = axis_invert_i[1] ? -remap_y : remap_y;
    final_z = axis_invert_i[2] ? -remap_z : remap_z;
  end

  // Clean registered outputs
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      sample_valid_o <= 1'b0;
      accel_x_o      <= '0;
      accel_y_o      <= '0;
      accel_z_o      <= '0;
    end else begin
      sample_valid_o <= mux_valid;
      if (mux_valid) begin
        accel_x_o <= final_x;
        accel_y_o <= final_y;
        accel_z_o <= final_z;
      end
    end
  end

endmodule
