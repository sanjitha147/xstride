// =============================================================================
// feature_stats.sv
// X-STRIDE Hardware Statistics & Feature Distribution Tracker
//
// Collects biomechanical signal statistics for software-driven per-person calibration:
//   - Minimum and Maximum acceleration magnitude
//   - Exponential moving average of gait peak heights
//   - Exponential moving average of peak-to-peak stride periods
//   - Maximum zero-crossing rate (ZCR)
//
// Power Optimization:
//   - Fully clock-gated / inactive when stat_enable_i == 0.
//   - Cleared synchronously on stat_clear_i pulse.
// =============================================================================

`timescale 1ns/1ps

module feature_stats #(
  parameter int unsigned DATA_W = 16
) (
  input  logic clk_i,
  input  logic rst_ni,
  input  logic en_i,

  // Control from Register File
  input  logic               stat_enable_i,
  input  logic               stat_clear_i,

  // Stream inputs from DSP & Classifier
  input  logic               sample_valid_i,
  input  logic [DATA_W-1:0]  feat_magnitude_i,
  input  logic [15:0]        feat_zcr_i,
  input  logic               step_detected_i,
  input  logic [DATA_W-1:0]  peak_mag_i,
  input  logic [15:0]        step_period_i,

  // Statistics Outputs to OBI Register File
  output logic [15:0]        stat_mag_min_o,
  output logic [15:0]        stat_mag_max_o,
  output logic [15:0]        stat_peak_avg_o,
  output logic [15:0]        stat_period_avg_o,
  output logic [15:0]        stat_zcr_max_o
);

  logic [15:0] mag_min_q, mag_min_d;
  logic [15:0] mag_max_q, mag_max_d;
  logic [15:0] peak_avg_q, peak_avg_d;
  logic [15:0] period_avg_q, period_avg_d;
  logic [15:0] zcr_max_q, zcr_max_d;

  logic signed [16:0] diff_peak;
  logic signed [16:0] diff_per;

  always_comb begin
    mag_min_d    = mag_min_q;
    mag_max_d    = mag_max_q;
    peak_avg_d   = peak_avg_q;
    period_avg_d = period_avg_q;
    zcr_max_d    = zcr_max_q;
    diff_peak    = '0;
    diff_per     = '0;

    if (stat_clear_i) begin
      mag_min_d    = 16'hFFFF;
      mag_max_d    = 16'h0000;
      peak_avg_d   = 16'h0000;
      period_avg_d = 16'h0000;
      zcr_max_d    = 16'h0000;
    end else if (en_i && stat_enable_i) begin
      // Magnitude envelope tracking on every valid sample
      if (sample_valid_i) begin
        if (feat_magnitude_i < mag_min_q) begin
          mag_min_d = feat_magnitude_i;
        end
        if (feat_magnitude_i > mag_max_q) begin
          mag_max_d = feat_magnitude_i;
        end
        if (feat_zcr_i > zcr_max_q) begin
          zcr_max_d = feat_zcr_i;
        end
      end

      // Exponential moving average updates on valid stride detection
      // avg += (new_val - avg) >>> 3
      if (step_detected_i) begin
        if (peak_avg_q == 16'h0000) begin
          peak_avg_d = peak_mag_i;
        end else begin
          diff_peak  = $signed({1'b0, peak_mag_i}) - $signed({1'b0, peak_avg_q});
          peak_avg_d = peak_avg_q + 16'(diff_peak >>> 3);
        end

        if (period_avg_q == 16'h0000) begin
          period_avg_d = step_period_i;
        end else begin
          diff_per     = $signed({1'b0, step_period_i}) - $signed({1'b0, period_avg_q});
          period_avg_d = period_avg_q + 16'(diff_per >>> 3);
        end
      end
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      mag_min_q    <= 16'hFFFF;
      mag_max_q    <= 16'h0000;
      peak_avg_q   <= 16'h0000;
      period_avg_q <= 16'h0000;
      zcr_max_q    <= 16'h0000;
    end else begin
      mag_min_q    <= mag_min_d;
      mag_max_q    <= mag_max_d;
      peak_avg_q   <= peak_avg_d;
      period_avg_q <= period_avg_d;
      zcr_max_q    <= zcr_max_d;
    end
  end

  assign stat_mag_min_o    = mag_min_q;
  assign stat_mag_max_o    = mag_max_q;
  assign stat_peak_avg_o   = peak_avg_q;
  assign stat_period_avg_o = period_avg_q;
  assign stat_zcr_max_o    = zcr_max_q;

endmodule
