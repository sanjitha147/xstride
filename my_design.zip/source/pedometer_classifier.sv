// =============================================================================
// pedometer_classifier.sv
// X-STRIDE Advanced Pedometer & Activity Classifier Engine
//
// Accurately discriminates between:
//   - ACT_REST      (0): Stationary / idle
//   - ACT_LEG_SHAKE (1): Leg shaking / seated fidgeting / tremor
//   - ACT_WALK      (2): Normal walking cadence
//   - ACT_RUN       (3): Jogging / Running
//   - ACT_EXERCISE  (4): Aerobic exercise
//
// Hardware Tunability:
//   - All biomechanical limits and thresholds are runtime configurable:
//       * step_threshold_i: sensitivity threshold
//       * run_threshold_i:  running vs walking threshold
//       * min_step_period_i / max_step_period_i: cadence boundaries
//       * shake_zcr_th_i:   tremor zero-crossing threshold
//       * dom_ratio_q4_i:   single-axis dominance ratio in Q4 (24 = 1.5x)
//       * dom_floor_i:      single-axis dominance delta floor
//       * lock_cnt_i:       rhythm commitment threshold count
//       * cad_num_i:        cadence conversion numerator (= 60 * ODR)
//   - Exposes detected peak height & period for hardware statistics tracking
// =============================================================================

`timescale 1ns/1ps

module pedometer_classifier #(
  parameter int unsigned DATA_W               = 16,
  parameter int unsigned DEFAULT_STEP_THRESH   = 16'd1200,
  parameter int unsigned DEFAULT_RUN_THRESH    = 16'd3200,
  parameter int unsigned DEFAULT_MIN_STEP_PER  = 12,
  parameter int unsigned DEFAULT_MAX_STEP_PER  = 65,
  parameter int unsigned DEFAULT_SHAKE_ZCR_TH  = 26
) (
  input  logic clk_i,
  input  logic rst_ni,
  input  logic en_i,

  input  logic                      sample_valid_i,
  input  logic signed [DATA_W-1:0]  accel_x_i,
  input  logic signed [DATA_W-1:0]  accel_y_i,
  input  logic signed [DATA_W-1:0]  accel_z_i,
  input  logic [DATA_W-1:0]         feat_magnitude_i,
  input  logic [15:0]               feat_zcr_i,

  input  logic                      shake_filter_en_i,
  input  logic [DATA_W-1:0]         step_threshold_i,
  input  logic [DATA_W-1:0]         run_threshold_i,
  input  logic [15:0]               min_step_period_i,
  input  logic [15:0]               max_step_period_i,
  input  logic [7:0]                shake_zcr_th_i,
  input  logic [7:0]                dom_ratio_q4_i,
  input  logic [15:0]               dom_floor_i,
  input  logic [3:0]                lock_cnt_i,
  input  logic [15:0]               cad_num_i,
  input  logic                      clear_counters_i,

  output logic [2:0]                activity_class_o,
  output logic                      step_detected_o,
  output logic                      shake_detected_o,
  output logic [31:0]               step_count_total_o,
  output logic [31:0]               step_count_walk_o,
  output logic [31:0]               step_count_run_o,
  output logic [31:0]               shake_event_count_o,
  output logic [31:0]               shake_duration_sec_o,
  output logic [31:0]               active_time_sec_o,
  output logic [15:0]               cadence_spm_o,

  // Peak statistics signals for feature_stats module
  output logic [DATA_W-1:0]         peak_mag_o,
  output logic [15:0]               step_period_o
);

  localparam logic [2:0] ACT_REST      = 3'b000;
  localparam logic [2:0] ACT_LEG_SHAKE = 3'b001;
  localparam logic [2:0] ACT_WALK      = 3'b010;
  localparam logic [2:0] ACT_RUN       = 3'b011;
  localparam logic [2:0] ACT_EXERCISE  = 3'b100;

  function automatic logic signed [DATA_W-1:0] abs_s(input logic signed [DATA_W-1:0] v);
    abs_s = v[DATA_W-1] ? -v : v;
  endfunction

  // Effective Runtime Configuration
  logic [DATA_W-1:0] cfg_step_thresh;
  logic [DATA_W-1:0] cfg_run_thresh;
  logic [15:0]        cfg_min_period;
  logic [15:0]        cfg_max_period;
  logic [7:0]         cfg_shake_zcr_th;
  logic [7:0]         cfg_dom_ratio_q4;
  logic [15:0]        cfg_dom_floor;
  logic [3:0]         cfg_lock_cnt;
  logic [15:0]        cfg_cad_num;

  assign cfg_step_thresh  = (step_threshold_i  == '0 || step_threshold_i  === 16'bz || step_threshold_i  === 16'bx) ? DEFAULT_STEP_THRESH       : step_threshold_i;
  assign cfg_run_thresh   = (run_threshold_i   == '0 || run_threshold_i   === 16'bz || run_threshold_i   === 16'bx) ? DEFAULT_RUN_THRESH        : run_threshold_i;
  assign cfg_min_period   = (min_step_period_i == '0 || min_step_period_i === 16'bz || min_step_period_i === 16'bx) ? 16'(DEFAULT_MIN_STEP_PER) : min_step_period_i;
  assign cfg_max_period   = (max_step_period_i == '0 || max_step_period_i === 16'bz || max_step_period_i === 16'bx) ? 16'(DEFAULT_MAX_STEP_PER) : max_step_period_i;
  assign cfg_shake_zcr_th = (shake_zcr_th_i    == '0 || shake_zcr_th_i    === 8'bz  || shake_zcr_th_i    === 8'bx)  ? 8'(DEFAULT_SHAKE_ZCR_TH)  : shake_zcr_th_i;
  assign cfg_dom_ratio_q4 = (dom_ratio_q4_i    == '0 || dom_ratio_q4_i    === 8'bz  || dom_ratio_q4_i    === 8'bx)  ? 8'd24                     : dom_ratio_q4_i;
  assign cfg_dom_floor    = (dom_floor_i       == '0 || dom_floor_i       === 16'bz || dom_floor_i       === 16'bx) ? 16'd300                   : dom_floor_i;
  assign cfg_lock_cnt     = (lock_cnt_i        == '0 || lock_cnt_i        === 4'bz  || lock_cnt_i        === 4'bx)  ? 4'd3                      : lock_cnt_i;
  assign cfg_cad_num      = (cad_num_i         == '0 || cad_num_i         === 16'bz || cad_num_i         === 16'bx) ? 16'd3000                  : cad_num_i;

  // Single-axis dominance detection
  logic signed [DATA_W-1:0] ax_prev_q, ay_prev_q, az_prev_q;
  logic [DATA_W-1:0] diff_x, diff_y, diff_z, max_diff, other_diff_sum;
  logic single_axis_dominant;

  always_comb begin
    diff_x = abs_s(accel_x_i - ax_prev_q);
    diff_y = abs_s(accel_y_i - ay_prev_q);
    diff_z = abs_s(accel_z_i - az_prev_q);

    if (diff_x >= diff_y && diff_x >= diff_z) begin
      max_diff       = diff_x;
      other_diff_sum = diff_y + diff_z;
    end else if (diff_y >= diff_x && diff_y >= diff_z) begin
      max_diff       = diff_y;
      other_diff_sum = diff_x + diff_z;
    end else begin
      max_diff       = diff_z;
      other_diff_sum = diff_x + diff_y;
    end

    // Scaled comparison using 32-bit math: max_diff * 16 > other_diff_sum * ratio
    single_axis_dominant = (((32'(max_diff)) << 4) > (32'(other_diff_sum) * 32'(cfg_dom_ratio_q4))) &&
                           (max_diff > cfg_dom_floor);
  end

  // Peak detection state
  typedef enum logic [1:0] {
    PEAK_RISE,
    PEAK_FALL
  } peak_st_e;

  peak_st_e    peak_st_q, peak_st_d;
  logic [15:0] mag_prev_q;
  logic [15:0] sample_timer_q, sample_timer_d;
  logic [15:0] inactivity_timer_q, inactivity_timer_d;

  // Cadence and rhythm tracking
  logic [3:0]  tentative_steps_q, tentative_steps_d;
  logic        rhythm_locked_q, rhythm_locked_d;
  logic [2:0]  act_class_q, act_class_d;
  logic        step_pulse_d, shake_pulse_d;

  logic [31:0] tot_steps_q, tot_steps_d;
  logic [31:0] walk_steps_q, walk_steps_d;
  logic [31:0] run_steps_q, run_steps_d;
  logic [31:0] shake_events_q, shake_events_d;
  logic [31:0] shake_dur_q, shake_dur_d;
  logic [31:0] active_time_q, active_time_d;
  logic [15:0] cadence_spm_q, cadence_spm_d;
  logic [7:0]  shake_streak_q, shake_streak_d;

  logic [DATA_W-1:0] peak_mag_q, peak_mag_d;
  logic [15:0]        step_period_q, step_period_d;

  always_comb begin
    peak_st_d          = peak_st_q;
    sample_timer_d     = sample_timer_q;
    inactivity_timer_d = inactivity_timer_q;
    tentative_steps_d  = tentative_steps_q;
    rhythm_locked_d    = rhythm_locked_q;
    act_class_d        = act_class_q;
    step_pulse_d       = 1'b0;
    shake_pulse_d      = 1'b0;
    tot_steps_d        = tot_steps_q;
    walk_steps_d       = walk_steps_q;
    run_steps_d        = run_steps_q;
    shake_events_d     = shake_events_q;
    shake_dur_d        = shake_dur_q;
    active_time_d      = active_time_q;
    cadence_spm_d      = cadence_spm_q;
    shake_streak_d     = shake_streak_q;
    peak_mag_d         = peak_mag_q;
    step_period_d      = step_period_q;

    if (clear_counters_i) begin
      tot_steps_d       = '0;
      walk_steps_d      = '0;
      run_steps_d       = '0;
      shake_events_d    = '0;
      shake_dur_d       = '0;
      active_time_d     = '0;
      tentative_steps_d = '0;
      rhythm_locked_d   = 1'b0;
      act_class_d       = ACT_REST;
      cadence_spm_d     = '0;
      peak_mag_d        = '0;
      step_period_d     = '0;
    end else if (en_i && sample_valid_i) begin

      // Advance sample timers
      if (sample_timer_q < 16'hFFFF) begin
        sample_timer_d = sample_timer_q + 16'd1;
      end

      if (inactivity_timer_q < 16'hFFFF) begin
        inactivity_timer_d = inactivity_timer_q + 16'd1;
      end

      // Inactivity timeout: if no steps or shakes for > (max_period + 30), return to REST
      if (inactivity_timer_q >= (cfg_max_period + 16'd30)) begin
        act_class_d       = ACT_REST;
        rhythm_locked_d   = 1'b0;
        tentative_steps_d = '0;
        cadence_spm_d     = '0;
        shake_streak_d    = '0;
      end

      // Peak detection state machine
      case (peak_st_q)
        PEAK_RISE: begin
          if ((feat_magnitude_i >= cfg_step_thresh || mag_prev_q >= cfg_step_thresh) && (feat_magnitude_i < mag_prev_q)) begin
            // Peak detected!
            peak_st_d          = PEAK_FALL;
            inactivity_timer_d = '0;
            peak_mag_d         = mag_prev_q;
            step_period_d      = sample_timer_q;

            // -----------------------------------------------------------------
            // DISCRIMINATOR: Leg Shaking vs. Walking
            // -----------------------------------------------------------------
            if (shake_filter_en_i &&
                (sample_timer_q < cfg_min_period || feat_zcr_i >= cfg_shake_zcr_th ||
                 (single_axis_dominant && sample_timer_q < (cfg_min_period + 16'd4)))) begin

              // LEG SHAKING / FIDGETING IDENTIFIED
              act_class_d   = ACT_LEG_SHAKE;
              shake_pulse_d = 1'b1;
              shake_dur_d   = shake_dur_q + 32'd1;

              if (shake_streak_q == 0) begin
                shake_events_d = shake_events_q + 32'd1;
              end
              if (shake_streak_q < 8'hFF) begin
                shake_streak_d = shake_streak_q + 8'd1;
              end

              // Invalidate walking buffer: DO NOT count steps!
              tentative_steps_d = '0;
              rhythm_locked_d   = 1'b0;
              sample_timer_d    = '0;

            end else if (sample_timer_q >= cfg_min_period && sample_timer_q <= cfg_max_period) begin

              // VALID PHYSIOLOGICAL WALKING / RUNNING CADENCE
              shake_streak_d = '0;

              if (sample_timer_q > 0) begin
                cadence_spm_d = 16'(cfg_cad_num / sample_timer_q);
              end

              // Rhythmic Confirmation Buffer
              if (!rhythm_locked_q) begin
                if (tentative_steps_q >= cfg_lock_cnt) begin
                  // Rhythmic steps confirmed and locked!
                  rhythm_locked_d   = 1'b1;
                  tentative_steps_d = cfg_lock_cnt + 4'd1;
                  tot_steps_d       = tot_steps_q + 32'(cfg_lock_cnt + 1);
                  step_pulse_d      = 1'b1;
                  active_time_d     = active_time_q + 32'(cfg_lock_cnt + 1);

                  if (mag_prev_q >= cfg_run_thresh || sample_timer_q < (cfg_min_period + 16'd4)) begin
                    act_class_d = ACT_RUN;
                    run_steps_d = run_steps_q + 32'(cfg_lock_cnt + 1);
                  end else begin
                    act_class_d  = ACT_WALK;
                    walk_steps_d = walk_steps_q + 32'(cfg_lock_cnt + 1);
                  end
                end else begin
                  tentative_steps_d = tentative_steps_q + 4'd1;
                  if (mag_prev_q >= cfg_run_thresh) act_class_d = ACT_RUN;
                  else                              act_class_d = ACT_WALK;
                end
              end else begin
                // Rhythm locked: increment step on every valid footfall
                tot_steps_d   = tot_steps_q + 32'd1;
                step_pulse_d  = 1'b1;
                active_time_d = active_time_q + 32'd1;

                if (mag_prev_q >= cfg_run_thresh || sample_timer_q < (cfg_min_period + 16'd4)) begin
                  act_class_d = ACT_RUN;
                  run_steps_d = run_steps_q + 32'd1;
                end else begin
                  act_class_d  = ACT_WALK;
                  walk_steps_d = walk_steps_q + 32'd1;
                end
              end

              sample_timer_d = '0;
            end else begin
              // Period > max_period (interval too long to be continuous walking)
              sample_timer_d    = '0;
              tentative_steps_d = '0;
              rhythm_locked_d   = 1'b0;
            end
          end
        end

        PEAK_FALL: begin
          // Wait for magnitude to fall below step threshold before searching for next peak
          if (feat_magnitude_i < cfg_step_thresh) begin
            peak_st_d = PEAK_RISE;
          end
        end

        default: peak_st_d = PEAK_RISE;
      endcase
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      peak_st_q          <= PEAK_RISE;
      mag_prev_q         <= '0;
      ax_prev_q          <= '0;
      ay_prev_q          <= '0;
      az_prev_q          <= '0;
      sample_timer_q     <= '0;
      inactivity_timer_q <= '0;
      tentative_steps_q  <= '0;
      rhythm_locked_q    <= 1'b0;
      act_class_q        <= ACT_REST;
      tot_steps_q        <= '0;
      walk_steps_q       <= '0;
      run_steps_q        <= '0;
      shake_events_q     <= '0;
      shake_dur_q        <= '0;
      active_time_q      <= '0;
      cadence_spm_q      <= '0;
      shake_streak_q     <= '0;
      peak_mag_q         <= '0;
      step_period_q      <= '0;
    end else if (!en_i) begin
      peak_st_q          <= peak_st_q;
      mag_prev_q         <= mag_prev_q;
      ax_prev_q          <= ax_prev_q;
      ay_prev_q          <= ay_prev_q;
      az_prev_q          <= az_prev_q;
      sample_timer_q     <= sample_timer_q;
      inactivity_timer_q <= inactivity_timer_q;
      tentative_steps_q  <= tentative_steps_q;
      rhythm_locked_q    <= rhythm_locked_q;
      act_class_q        <= act_class_q;
      tot_steps_q        <= tot_steps_q;
      walk_steps_q       <= walk_steps_q;
      run_steps_q        <= run_steps_q;
      shake_events_q     <= shake_events_q;
      shake_dur_q        <= shake_dur_q;
      active_time_q      <= active_time_q;
      cadence_spm_q      <= cadence_spm_q;
      shake_streak_q     <= shake_streak_q;
      peak_mag_q         <= peak_mag_q;
      step_period_q      <= step_period_q;
    end else begin
      peak_st_q          <= peak_st_d;
      sample_timer_q     <= sample_timer_d;
      inactivity_timer_q <= inactivity_timer_d;
      tentative_steps_q  <= tentative_steps_d;
      rhythm_locked_q    <= rhythm_locked_d;
      act_class_q        <= act_class_d;
      tot_steps_q        <= tot_steps_d;
      walk_steps_q       <= walk_steps_d;
      run_steps_q        <= run_steps_d;
      shake_events_q     <= shake_events_d;
      shake_dur_q        <= shake_dur_d;
      active_time_q      <= active_time_d;
      cadence_spm_q      <= cadence_spm_d;
      shake_streak_q     <= shake_streak_d;
      peak_mag_q         <= peak_mag_d;
      step_period_q      <= step_period_d;

      if (sample_valid_i) begin
        mag_prev_q <= feat_magnitude_i;
        ax_prev_q  <= accel_x_i;
        ay_prev_q  <= accel_y_i;
        az_prev_q  <= accel_z_i;
      end
    end
  end

  assign activity_class_o     = act_class_q;
  assign step_detected_o      = step_pulse_d;
  assign shake_detected_o     = shake_pulse_d;
  assign step_count_total_o   = tot_steps_q;
  assign step_count_walk_o    = walk_steps_q;
  assign step_count_run_o     = run_steps_q;
  assign shake_event_count_o  = shake_events_q;
  assign shake_duration_sec_o = shake_dur_q;
  assign active_time_sec_o    = active_time_q;
  assign cadence_spm_o        = cadence_spm_q;

  assign peak_mag_o           = peak_mag_q;
  assign step_period_o        = step_period_q;

endmodule
