// =============================================================================
// rst_sync.sv
// X-STRIDE Asynchronous Assert, Synchronous Deassert Reset Synchronizer
//
// Prevents metastability and recovery/removal timing violations when reset
// is deasserted. Two cascaded flip-flops reset asynchronously by rst_ni,
// with D tied to 1'b1 clocked by clk_i.
// =============================================================================

`timescale 1ns/1ps

module rst_sync (
  input  logic clk_i,
  input  logic rst_ni,     // asynchronous raw reset (active low)
  output logic rst_n_sync_o // synchronously released reset (active low)
);

  (* async_reg = "true" *) logic rst_meta_q;
  (* async_reg = "true" *) logic rst_sync_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      rst_meta_q <= 1'b0;
      rst_sync_q <= 1'b0;
    end else begin
      rst_meta_q <= 1'b1;
      rst_sync_q <= rst_meta_q;
    end
  end

  assign rst_n_sync_o = rst_sync_q;

endmodule
