#!/usr/bin/env bash
# =============================================================================
# run_all_tests.sh
# Linux / CI regression script for X-STRIDE
# =============================================================================
set -e

run_tb() {
    name="$1"
    cmd="$2"
    echo -e "\n========================================================"
    echo -e " RUNNING: $name"
    echo -e "========================================================"
    eval "$cmd"
    if [ $? -ne 0 ]; then
        echo -e "[-] $name FAILED"
        exit 1
    fi
}

run_tb "1. Wake FSM" "iverilog -g2012 -o sim_wake_fsm rtl/wake_fsm.sv tb/tb_wake_fsm.sv && vvp sim_wake_fsm"
run_tb "2. DSP Front-End" "iverilog -g2012 -o sim_dsp rtl/dsp_frontend.sv tb/tb_dsp_frontend.sv && vvp sim_dsp"
run_tb "3. External SPI Master" "iverilog -g2012 -o sim_accel rtl/accel_spi_intf.sv tb/tb_accel_spi_intf.sv && vvp sim_accel"
run_tb "4. Integrated On-Chip MEMS & SAR ADC" "iverilog -g2012 -o sim_onchip rtl/mems_afe_adc.sv rtl/onchip_mems_sensor.sv tb/tb_onchip_mems_sensor.sv && vvp sim_onchip"
run_tb "5. Unified Sensor Hub" "iverilog -g2012 -o sim_hub rtl/sensor_hub.sv tb/tb_sensor_hub.sv && vvp sim_hub"
run_tb "6. Mobile BLE Telemetry Unit" "iverilog -g2012 -o sim_telemetry rtl/mobile_telemetry_unit.sv tb/tb_mobile_telemetry.sv && vvp sim_telemetry"
run_tb "7. Pedometer Classifier" "iverilog -g2012 -o sim_classifier rtl/pedometer_classifier.sv tb/tb_pedometer_classifier.sv && vvp sim_classifier"
run_tb "8. OBI Register File" "iverilog -g2012 -o sim_regs rtl/xstride_regs_pkg.sv rtl/xstride_regs_obi.sv tb/tb_xstride_regs_obi.sv && vvp sim_regs"
run_tb "9. Top Integration & SVA Suite" "iverilog -g2012 -o sim_top rtl/xstride_regs_pkg.sv rtl/rst_sync.sv rtl/sync_2ff.sv rtl/mems_afe_adc.sv rtl/accel_spi_intf.sv rtl/accel_i2c_intf.sv rtl/onchip_mems_sensor.sv rtl/sensor_hub.sv rtl/calib_stage.sv rtl/dsp_frontend.sv rtl/pedometer_classifier.sv rtl/feature_stats.sv rtl/mobile_telemetry_unit.sv rtl/wake_fsm.sv rtl/xstride_regs_obi.sv rtl/xstride_always_on_top.sv rtl/xstride_sva.sv tb/tb_xstride_top.sv && vvp sim_top"
run_tb "10. Clinical Benchmark Dataset Replay" "iverilog -g2012 -o sim_replay rtl/xstride_regs_pkg.sv rtl/rst_sync.sv rtl/sync_2ff.sv rtl/mems_afe_adc.sv rtl/accel_spi_intf.sv rtl/accel_i2c_intf.sv rtl/onchip_mems_sensor.sv rtl/sensor_hub.sv rtl/calib_stage.sv rtl/dsp_frontend.sv rtl/pedometer_classifier.sv rtl/feature_stats.sv rtl/mobile_telemetry_unit.sv rtl/wake_fsm.sv rtl/xstride_regs_obi.sv rtl/xstride_always_on_top.sv rtl/xstride_sva.sv tb/tb_coverage.sv tb/tb_real_dataset_replay.sv && vvp sim_replay"
run_tb "11. Constrained-Random Verification" "iverilog -g2012 -o sim_rand rtl/pedometer_classifier.sv tb/tb_pedometer_randomized.sv && vvp sim_rand"
run_tb "12. EPFL X-HEEP Platform Wrapper" "iverilog -g2012 -o sim_heep rtl/xstride_regs_pkg.sv rtl/rst_sync.sv rtl/sync_2ff.sv rtl/mems_afe_adc.sv rtl/accel_spi_intf.sv rtl/accel_i2c_intf.sv rtl/onchip_mems_sensor.sv rtl/sensor_hub.sv rtl/calib_stage.sv rtl/dsp_frontend.sv rtl/pedometer_classifier.sv rtl/feature_stats.sv rtl/mobile_telemetry_unit.sv rtl/wake_fsm.sv rtl/xstride_regs_obi.sv rtl/xstride_always_on_top.sv rtl/x_heep_xstride_wrapper.sv tb/tb_heep_wrapper.sv && vvp sim_heep"
run_tb "13. IEEE 1801 UPF 3.0 Linter" "python3 scripts/check_upf.py"
run_tb "14. 65nm LP ASIC Synthesis & Power" "python3 scripts/synth_power_analysis.py"

echo -e "\n========================================================"
echo -e " ALL 14 TESTBENCHES & ANALYSIS CHECKS PASSED WITH 100% SUCCESS!"
echo -e "========================================================\n"
