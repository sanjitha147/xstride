`timescale 1ns/1ps
import xstride_regs_pkg::*;

module tb_xstride_regs_obi;

  logic clk = 0;
  logic rst_n = 0;

  logic        req = 0, we = 0;
  logic [3:0]  be = 4'hF;
  logic [31:0] addr = 0, wdata = 0;
  logic        gnt, rvalid;
  logic [31:0] rdata;

  logic        sample_valid = 0;
  xstride_cfg_t cfg_act;

  logic [1:0]  fsm_state = 2'd2;
  logic        motion_detected = 1'b1;
  logic        feature_ready = 1'b0;
  logic [15:0] feat_mag = 16'd1111;
  logic [15:0] feat_zcr = 16'd22;
  logic [15:0] feat_cad = 16'd22;
  logic [7:0]  tinyml_class = 8'd0;
  logic        core_ack;

  int errors = 0;

  xstride_regs_obi #(
    .BASE_ADDR(32'h0000_0000)
  ) dut (
    .clk_i(clk), .rst_ni(rst_n),
    .req_i(req), .gnt_o(gnt),
    .addr_i(addr), .we_i(we), .be_i(be), .wdata_i(wdata),
    .rvalid_o(rvalid), .rdata_o(rdata),
    .sample_valid_i(sample_valid),
    .cfg_act_o(cfg_act),
    .fsm_state_i(fsm_state),
    .motion_detected_i(motion_detected),
    .feature_ready_i(feature_ready),
    .feat_magnitude_i(feat_mag),
    .feat_zcr_i(feat_zcr),
    .feat_cadence_i(feat_cad),
    .tinyml_class_i(tinyml_class),
    .core_ack_o(core_ack)
  );

  always #5 clk = ~clk;

  task automatic check(string name, logic cond);
    if (!cond) begin
      $display("[FAIL] %s @ t=%0t", name, $time);
      errors++;
    end else begin
      $display("[PASS] %s", name);
    end
  endtask

  task automatic obi_read(input logic [31:0] a, output logic [31:0] d);
    @(posedge clk);
    addr = a; we = 0; req = 1;
    @(posedge clk); // gnt observed here
    req = 0;
    @(posedge clk); // rvalid observed here (1-cycle latency)
    d = rdata;
  endtask

  task automatic obi_write(input logic [31:0] a, input logic [31:0] d);
    @(posedge clk);
    addr = a; we = 1; wdata = d; req = 1;
    @(posedge clk);
    req = 0; we = 0;
  endtask

  logic [31:0] rd;

  initial begin
    rst_n = 0;
    repeat (3) @(posedge clk);
    rst_n = 1;

    // STATUS readback reflects live fsm_state / motion_detected
    obi_read(32'h04, rd);
    check("STATUS reflects fsm_state=2", rd[1:0] == 2'd2);
    check("STATUS reflects motion_detected", rd[2] == 1'b1);

    // FEAT_MAGNITUDE / ZCR / CADENCE readback
    obi_read(32'h08, rd);
    check("FEAT_MAGNITUDE readback", rd == 32'd1111);
    obi_read(32'h0C, rd);
    check("FEAT_ZCR readback", rd == 32'd22);
    obi_read(32'h10, rd);
    check("FEAT_CADENCE readback", rd == 32'd22);

    // TINYML_CLASS stub reads back 0 (block not integrated yet)
    obi_read(32'h14, rd);
    check("TINYML_CLASS stub reads 0", rd == 32'd0);

    // CTRL default is soft_en=1 out of reset
    obi_read(32'h00, rd);
    check("CTRL default soft_en=1", rd[0] == 1'b1);

    // Write CTRL to 0, read back
    obi_write(32'h00, 32'h0);
    obi_read(32'h00, rd);
    check("CTRL write/readback", rd[0] == 1'b0);

    // feature_ready sticky bit: pulse it, then confirm STATUS shows it once,
    // clears on read
    feature_ready = 1'b1;
    @(posedge clk);
    feature_ready = 1'b0;
    obi_read(32'h04, rd);
    check("STATUS feature_ready_sticky set after pulse", rd[3] == 1'b1);
    obi_read(32'h04, rd);
    check("STATUS feature_ready_sticky clears on read", rd[3] == 1'b0);

    // IRQ_ACK write pulses core_ack_o for one cycle
    fork
      begin
        obi_write(32'h18, 32'hFFFF_FFFF);
      end
      begin
        @(posedge core_ack);
        check("core_ack_o pulses on IRQ_ACK write", 1'b1);
      end
    join_any
    disable fork;

    // -------------------------------------------------------------------------
    // Phase 6: Dual-Bank Personalization, Atomic Commit & Locking Tests
    // -------------------------------------------------------------------------
    // 1. Check default active config out of reset
    check("Default active step threshold is 1200", cfg_act.step_thresh == 16'd1200);

    // 2. Write pending STEP_THRESHOLD = 1500
    obi_write(32'h48, 32'd1500);
    obi_read(32'h48, rd);
    check("Pending STEP_THRESHOLD readback is 1500", rd == 32'd1500);
    check("Active config unchanged before commit", cfg_act.step_thresh == 16'd1200);

    // 3. Issue Commit Request (bit 0 of PROFILE_CTRL at 0x74)
    obi_write(32'h74, 32'h0000_0001);
    obi_read(32'h78, rd); // PROFILE_STATUS
    check("Commit request pending in PROFILE_STATUS", rd[0] == 1'b1);
    check("Active config still unchanged before sample_valid", cfg_act.step_thresh == 16'd1200);

    // 4. Pulse sample_valid boundary
    @(posedge clk);
    sample_valid = 1'b1;
    @(posedge clk);
    sample_valid = 1'b0;
    @(posedge clk);

    check("Active STEP_THRESHOLD updated to 1500 after commit", cfg_act.step_thresh == 16'd1500);
    obi_read(32'h78, rd);
    check("Commit request cleared in PROFILE_STATUS", rd[0] == 1'b0);
    check("Profile applied flag set in PROFILE_STATUS", rd[1] == 1'b1);
    check("Range error flag is 0", rd[2] == 1'b0);

    // 5. Test Range Error Rejection: min_period (30) > max_period (20)
    // PERIOD_CFG at 0x50: [31:16] max_period, [15:0] min_period
    obi_write(32'h50, {16'd20, 16'd30});
    obi_write(32'h74, 32'h0000_0001); // commit
    @(posedge clk);
    sample_valid = 1'b1;
    @(posedge clk);
    sample_valid = 1'b0;
    @(posedge clk);

    obi_read(32'h78, rd);
    check("Range error flagged on invalid min > max period", rd[2] == 1'b1);
    check("Active config rejected invalid period and kept previous", cfg_act.min_period == 16'd12);

    // 6. Test Config LOCK: Set lock bit (bit 2 of PROFILE_CTRL)
    obi_write(32'h74, 32'h0000_0004);
    obi_read(32'h74, rd);
    check("Config lock flag set in PROFILE_CTRL", rd[2] == 1'b1);

    // Attempt to write STEP_THRESHOLD while locked
    obi_write(32'h48, 32'd2500);
    obi_read(32'h48, rd);
    check("Write ignored when config locked", rd == 32'd1500);

    // Unmapped address returns sentinel (debug aid)
    obi_read(32'hFC, rd);
    check("unmapped address returns 0xDEADBEEF sentinel", rd == 32'hDEAD_BEEF);

    if (errors == 0) $display("\n=== ALL TESTS PASSED ===");
    else $display("\n=== %0d TEST(S) FAILED ===", errors);

    $finish;
  end

  initial begin
    #20000;
    $display("[FAIL] TIMEOUT -- simulation ran too long");
    $finish;
  end

endmodule
