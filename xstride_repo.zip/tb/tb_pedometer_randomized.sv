// =============================================================================
// tb_pedometer_randomized.sv
// Constrained Random Verification Testbench for X-STRIDE Pedometer Subsystem
//
// Injects randomized noise, random baseline zero-g drift, random jitter, and
// constrained random transitions between:
//   - Random Seated Leg Shaking (3.8 - 4.8 Hz, fast periods, Z-dominant)
//   - Random Rest / Motionless Stance
//   - Random Human Walking (1.5 - 2.0 Hz, 3-axis energy)
//   - Random Jogging / Running (2.5 - 3.2 Hz, magnitude > 3500)
//
// Monitors SystemVerilog Assertions (SVA) and functional coverage.
// =============================================================================

`timescale 1ns/1ps

module tb_pedometer_randomized;

  logic clk = 0;
  logic rst_n = 0;
  logic en = 1;

  always #10 clk = ~clk; // 50 MHz clock

  logic signed [15:0] ax, ay, az;
  logic [15:0] feat_mag, feat_zcr;
  logic        sample_valid = 0;

  logic [2:0]  activity_class;
  logic        step_detected, shake_detected;
  logic [31:0] total_steps, walk_steps, run_steps;
  logic [31:0] shake_events, shake_duration, active_time;
  logic [15:0] cadence_spm;

  int rand_errors = 0;

  // Instantiate DUT
  pedometer_classifier #(
    .DATA_W (16)
  ) dut (
    .clk_i                (clk),
    .rst_ni               (rst_n),
    .en_i                 (en),
    .sample_valid_i       (sample_valid),
    .accel_x_i            (ax),
    .accel_y_i            (ay),
    .accel_z_i            (az),
    .feat_magnitude_i     (feat_mag),
    .feat_zcr_i           (feat_zcr),
    .shake_filter_en_i    (1'b1),
    .step_threshold_i     (16'd1200),
    .run_threshold_i      (16'd3200),
    .min_step_period_i    (16'd12),
    .max_step_period_i    (16'd65),
    .clear_counters_i     (1'b0),
    .activity_class_o     (activity_class),
    .step_detected_o      (step_detected),
    .shake_detected_o     (shake_detected),
    .step_count_total_o   (total_steps),
    .step_count_walk_o    (walk_steps),
    .step_count_run_o     (run_steps),
    .shake_event_count_o  (shake_events),
    .shake_duration_sec_o (shake_duration),
    .active_time_sec_o    (active_time),
    .cadence_spm_o        (cadence_spm)
  );

  // SystemVerilog Assertions checking
  always @(posedge clk) begin
    if (rst_n) begin
      // SVA Golden Rule 1: No steps during Leg Shaking
      if (activity_class == 3'd1 && step_detected) begin
        $display("[SVA ERROR] False step asserted during ACT_LEG_SHAKE at t=%0t!", $time);
        rand_errors++;
      end
    end
  end

  task automatic feed_sample(input int x, input int y, input int z, input int mag, input int zcr);
    @(posedge clk);
    #1;
    ax = 16'(x); ay = 16'(y); az = 16'(z);
    feat_mag = 16'(mag); feat_zcr = 16'(zcr);
    sample_valid = 1'b1;
    @(posedge clk);
    #1;
    sample_valid = 1'b0;
  endtask

  // Constrained Random Leg Shake Generator (with random amplitude and noise)
  task automatic inject_random_leg_shake(input int cycles);
    for (int c = 0; c < cycles; c++) begin
      int period = $urandom_range(5, 8); // Fast period 5..8 samples (faster than min_period=12)
      int peak   = $urandom_range(1800, 2600);
      for (int s = 0; s < period; s++) begin
        int z_val, noise_x, noise_y;
        noise_x = $urandom_range(0, 40) - 20;
        noise_y = $urandom_range(0, 40) - 20;
        if (s < period / 2) z_val = (peak * (s + 1)) / (period / 2);
        else                z_val = peak - (peak * (s - (period / 2) + 1)) / (period / 2);
        if (z_val < 0)      z_val = 0;
        feed_sample(noise_x, noise_y, z_val, z_val, $urandom_range(28, 40));
      end
    end
  endtask

  // Constrained Random Walking Generator (with random cadence and multi-axis variance)
  task automatic inject_random_walking(input int strides);
    for (int st = 0; st < strides; st++) begin
      int period = $urandom_range(22, 32); // Valid walking period 22..32 samples
      int peak   = $urandom_range(1600, 2200);
      for (int s = 0; s < period; s++) begin
        int mag_val;
        if (s < period / 2) mag_val = (peak * (s + 1)) / (period / 2);
        else                mag_val = peak - (peak * (s - (period / 2) + 1)) / (period / 2);
        if (mag_val < 300)  mag_val = 300; // valley
        feed_sample(mag_val / 2, -mag_val / 3, mag_val, mag_val, $urandom_range(6, 12));
      end
    end
  endtask

  // Constrained Random Rest / Quiet Interval
  task automatic inject_random_rest(input int samples);
    for (int s = 0; s < samples; s++) begin
      int nx = $urandom_range(0, 20) - 10;
      int ny = $urandom_range(0, 20) - 10;
      int nz = $urandom_range(0, 20) - 10 + 400; // quiet 1g stance
      feed_sample(nx, ny, nz, 400, 0);
    end
  endtask

  initial begin
    $display("\n========================================================");
    $display(" CONSTRAINED RANDOM VERIFICATION & SVA ASSERTION SUITE");
    $display("========================================================");

    rst_n = 0;
    repeat (5) @(posedge clk);
    rst_n = 1;
    repeat (5) @(posedge clk);

    // Iteration 1: Random Leg Shaking Bursts
    $display("--- Phase 1: Ingesting 20 Randomized Leg-Shaking Bursts with Noise ---");
    inject_random_leg_shake(20);
    repeat (5) @(posedge clk);

    if (total_steps != 0) begin
      $display("[FAIL] Total steps corrupted during random leg shaking! total_steps=%0d", total_steps);
      rand_errors++;
    end else begin
      $display("[PASS] Zero false steps during 20 randomized leg shaking bursts!");
    end

    // Iteration 2: Rest interval
    inject_random_rest(70);

    // Iteration 3: Random Walking Gait
    $display("--- Phase 2: Ingesting 12 Randomized Multi-Axis Walking Strides ---");
    inject_random_walking(12);
    repeat (5) @(posedge clk);

    if (total_steps < 8) begin
      $display("[FAIL] Expected >= 8 steps locked from walking, got %0d", total_steps);
      rand_errors++;
    end else begin
      $display("[PASS] Successfully confirmed and locked %0d steps from random walking!", total_steps);
    end

    // Iteration 4: Alternating Leg-Shake and Walk Sequences
    $display("--- Phase 3: Alternating Random Leg-Shake and Walking Interleaved ---");
    begin
      int steps_before;
      for (int iter = 0; iter < 5; iter++) begin
        steps_before = total_steps;
        inject_random_leg_shake(5);
        if (total_steps != steps_before) begin
          $display("[FAIL] Steps incremented during interleaved leg shake in iteration %0d! (before=%0d, after=%0d)",
                   iter, steps_before, total_steps);
          rand_errors++;
        end else begin
          $display("[PASS] Interleaved leg shake %0d correctly rejected all false steps (steps=%0d)", iter, total_steps);
        end
        inject_random_walking(4);
      end
    end

    $display("\n========================================================");
    if (rand_errors == 0) begin
      $display(" ALL CONSTRAINED RANDOM & SVA ASSERTION TESTS PASSED (100%% SUCCESS)!");
    end else begin
      $display(" %0d CONSTRAINED RANDOM TESTS FAILED!", rand_errors);
    end
    $display("========================================================\n");

    $finish;
  end

  initial begin
    #2000000;
    $display("[FAIL] TIMEOUT in tb_pedometer_randomized");
    $finish;
  end

endmodule
