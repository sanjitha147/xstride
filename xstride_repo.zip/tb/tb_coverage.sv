// =============================================================================
// tb_coverage.sv
// Functional Coverage Monitor for X-STRIDE Pedometer SoC Subsystem
//
// Dual-mode coverage architecture:
//   1. IEEE-1800 SystemVerilog covergroups for commercial ASIC simulators
//      (Synopsys VCS, Cadence Xcelium, Siemens Questa).
//   2. Explicit functional bin monitors for open-source simulators
//      (Icarus Verilog, Verilator) where `covergroup` construct is unsupported.
//
// Monitors and measures comprehensive verification coverage:
//   - Activity classification coverage (REST, LEG_SHAKE, WALKING, RUNNING)
//   - Cadence distribution coverage (Steps Per Minute bins)
//   - Sensor Hub selection coverage (SPI, I2C, On-Chip MEMS)
//   - Wake FSM states and transitions
//   - Mobile Telemetry events and FIFO utilization
// =============================================================================

`timescale 1ns/1ps

module tb_coverage (
  input logic        clk_i,
  input logic        rst_ni,

  input logic [2:0]  activity_class_i,
  input logic [15:0] cadence_spm_i,
  input logic [1:0]  sensor_sel_i,
  input logic [1:0]  fsm_state_i,
  input logic        step_pulse_i,
  input logic        shake_pulse_i,
  input logic [7:0]  fifo_count_i,
  input logic        core_irq_i
);

`ifndef __ICARUS__
  // ---------------------------------------------------------------------------
  // Covergroup 1: Activity Classification & Cadence (Commercial Tool Mode)
  // ---------------------------------------------------------------------------
  covergroup cg_pedometer @(posedge clk_i);
    cp_activity: coverpoint activity_class_i {
      bins rest      = {3'd0};
      bins leg_shake = {3'd1};
      bins walk      = {3'd2};
      bins run       = {3'd3};
    }

    cp_cadence: coverpoint cadence_spm_i {
      bins zero        = {0};
      bins slow_walk   = {[60:89]};
      bins normal_walk = {[90:119]};
      bins brisk_walk  = {[120:149]};
      bins running     = {[150:220]};
    }

    cross_act_cad: cross cp_activity, cp_cadence;
  endgroup

  // Covergroup 2: Sensor Selection & Hub Routing
  covergroup cg_sensor_hub @(posedge clk_i);
    cp_sensor: coverpoint sensor_sel_i {
      bins spi_external = {2'b00};
      bins i2c_external = {2'b01};
      bins onchip_mems  = {2'b10};
    }
  endgroup

  // Covergroup 3: Wake FSM Multi-Tier Power States & Transitions
  covergroup cg_power_fsm @(posedge clk_i);
    cp_state: coverpoint fsm_state_i {
      bins sleep     = {2'd0};
      bins idle      = {2'd1};
      bins active    = {2'd2};
      bins core_sync = {2'd3};
    }
  endgroup

  // Covergroup 4: Mobile Telemetry & FIFO
  covergroup cg_telemetry @(posedge clk_i);
    cp_fifo: coverpoint fifo_count_i {
      bins empty   = {0};
      bins low     = {[1:4]};
      bins medium  = {[5:16]};
      bins full    = {[17:32]};
    }

    cp_irq: coverpoint core_irq_i {
      bins deasserted = {1'b0};
      bins asserted   = {1'b1};
    }
  endgroup

  cg_pedometer   cov_pedometer   = new();
  cg_sensor_hub  cov_sensor_hub  = new();
  cg_power_fsm   cov_power_fsm   = new();
  cg_telemetry   cov_telemetry   = new();

  task automatic display_coverage_summary();
    $display("\n========================================================");
    $display(" FUNCTIONAL COVERAGE SUMMARY (IEEE-1800 COVERGROUPS)");
    $display("========================================================");
    $display("  * Pedometer Activity & Cadence Coverage: %0.2f%%", cov_pedometer.get_coverage());
    $display("  * Sensor Hub Selection Coverage:         %0.2f%%", cov_sensor_hub.get_coverage());
    $display("  * Power FSM States & Transitions:        %0.2f%%", cov_power_fsm.get_coverage());
    $display("  * Mobile Telemetry & FIFO Coverage:      %0.2f%%", cov_telemetry.get_coverage());
    $display("========================================================\n");
  endtask

`else
  // ---------------------------------------------------------------------------
  // Functional Coverage Tracking for Icarus Verilog
  // ---------------------------------------------------------------------------
  bit bin_act_rest, bin_act_shake, bin_act_walk, bin_act_run;
  bit bin_cad_zero, bin_cad_slow, bin_cad_norm, bin_cad_brisk, bin_cad_run;
  bit bin_sens_spi, bin_sens_i2c, bin_sens_mems;
  bit bin_fsm_sleep, bin_fsm_idle, bin_fsm_active, bin_fsm_sync;
  bit bin_fifo_empty, bin_fifo_active, bin_irq_pulse;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      // Preserve coverage accumulators across reset
    end else begin
      // Activity classification
      case (activity_class_i)
        3'd0: bin_act_rest  <= 1'b1;
        3'd1: bin_act_shake <= 1'b1;
        3'd2: bin_act_walk  <= 1'b1;
        3'd3: bin_act_run   <= 1'b1;
        default: ;
      endcase

      // Cadence bins
      if (cadence_spm_i == 0)                     bin_cad_zero  <= 1'b1;
      else if (cadence_spm_i >= 60  && cadence_spm_i < 90)   bin_cad_slow  <= 1'b1;
      else if (cadence_spm_i >= 90  && cadence_spm_i < 120)  bin_cad_norm  <= 1'b1;
      else if (cadence_spm_i >= 120 && cadence_spm_i < 150)  bin_cad_brisk <= 1'b1;
      else if (cadence_spm_i >= 150)                         bin_cad_run   <= 1'b1;

      // Sensor Hub
      case (sensor_sel_i)
        2'b00: bin_sens_spi  <= 1'b1;
        2'b01: bin_sens_i2c  <= 1'b1;
        2'b10: bin_sens_mems <= 1'b1;
        default: ;
      endcase

      // FSM States
      case (fsm_state_i)
        2'd0: bin_fsm_sleep  <= 1'b1;
        2'd1: bin_fsm_idle   <= 1'b1;
        2'd2: bin_fsm_active <= 1'b1;
        2'd3: bin_fsm_sync   <= 1'b1;
        default: ;
      endcase

      // Telemetry
      if (fifo_count_i == 0) bin_fifo_empty  <= 1'b1;
      else                   bin_fifo_active <= 1'b1;
      if (core_irq_i)        bin_irq_pulse   <= 1'b1;
    end
  end

  task automatic display_coverage_summary();
    real act_cov, cad_cov, sens_cov, fsm_cov;
    int act_hits, cad_hits, sens_hits, fsm_hits;

    act_hits  = bin_act_rest + bin_act_shake + bin_act_walk + bin_act_run;
    act_cov   = (act_hits * 100.0) / 4.0;

    cad_hits  = bin_cad_zero + bin_cad_slow + bin_cad_norm + bin_cad_brisk + bin_cad_run;
    cad_cov   = (cad_hits * 100.0) / 5.0;

    sens_hits = bin_sens_spi + bin_sens_i2c + bin_sens_mems;
    sens_cov  = (sens_hits * 100.0) / 3.0;

    fsm_hits  = bin_fsm_sleep + bin_fsm_idle + bin_fsm_active + bin_fsm_sync;
    fsm_cov   = (fsm_hits * 100.0) / 4.0;

    $display("\n========================================================");
    $display(" FUNCTIONAL COVERAGE SUMMARY (BIN ANALYSIS)");
    $display("========================================================");
    $display("  * Pedometer Activity Classes:  %0.1f%% (%0d/4 bins covered)", act_cov, act_hits);
    $display("    - REST:       [%s]", bin_act_rest  ? "COVERED" : "UNCOVERED");
    $display("    - LEG_SHAKE:  [%s]", bin_act_shake ? "COVERED" : "UNCOVERED");
    $display("    - WALK:       [%s]", bin_act_walk  ? "COVERED" : "UNCOVERED");
    $display("    - RUN:        [%s]", bin_act_run   ? "COVERED" : "UNCOVERED");
    $display("  * Cadence Distribution Bins:   %0.1f%% (%0d/5 bins covered)", cad_cov, cad_hits);
    $display("    - ZERO:       [%s]", bin_cad_zero  ? "HIT" : "MISS");
    $display("    - SLOW:       [%s]", bin_cad_slow  ? "HIT" : "MISS");
    $display("    - NORM:       [%s]", bin_cad_norm  ? "HIT" : "MISS");
    $display("    - BRISK:      [%s]", bin_cad_brisk ? "HIT" : "MISS");
    $display("    - RUN:        [%s]", bin_cad_run   ? "HIT" : "MISS");
    $display("  * Sensor Hub Selection:        %0.1f%% (%0d/3 sensors exercised)", sens_cov, sens_hits);
    $display("    - SPI Master: [%s]", bin_sens_spi  ? "EXERCISED" : "UNUSED");
    $display("    - I2C Master: [%s]", bin_sens_i2c  ? "EXERCISED" : "UNUSED");
    $display("    - On-Chip:    [%s]", bin_sens_mems ? "EXERCISED" : "UNUSED");
    $display("  * Power FSM States:            %0.1f%% (%0d/4 states reached)", fsm_cov, fsm_hits);
    $display("========================================================\n");
  endtask
`endif

endmodule
