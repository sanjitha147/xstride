// =============================================================================
// tb_sensor_hub.sv
// Testbench for Unified Sensor Hub & Multiplexer
// =============================================================================

`timescale 1ns/1ps

module tb_sensor_hub;

  logic clk = 0;
  logic rst_n = 0;

  logic [1:0] sensor_sel = 2'b00;
  logic [2:0] axis_remap = 3'b000;
  logic [2:0] axis_invert = 3'b000;

  logic        spi_valid = 0;
  logic signed [15:0] spi_x = 16'sd100, spi_y = 16'sd200, spi_z = 16'sd300;

  logic        i2c_valid = 0;
  logic signed [15:0] i2c_x = 16'sd400, i2c_y = 16'sd500, i2c_z = 16'sd600;

  logic        onchip_valid = 0;
  logic signed [15:0] onchip_x = 16'sd700, onchip_y = 16'sd800, onchip_z = 16'sd900;

  logic        sample_valid;
  logic signed [15:0] ax, ay, az;

  int errors = 0;

  sensor_hub #(
    .DATA_W(16)
  ) dut (
    .clk_i                 (clk),
    .rst_ni                (rst_n),
    .sensor_sel_i          (sensor_sel),
    .axis_remap_i          (axis_remap),
    .axis_invert_i         (axis_invert),
    .spi_sample_valid_i    (spi_valid),
    .spi_accel_x_i         (spi_x),
    .spi_accel_y_i         (spi_y),
    .spi_accel_z_i         (spi_z),
    .i2c_sample_valid_i    (i2c_valid),
    .i2c_accel_x_i         (i2c_x),
    .i2c_accel_y_i         (i2c_y),
    .i2c_accel_z_i         (i2c_z),
    .onchip_sample_valid_i (onchip_valid),
    .onchip_accel_x_i      (onchip_x),
    .onchip_accel_y_i      (onchip_y),
    .onchip_accel_z_i      (onchip_z),
    .direct_sample_valid_i (1'b0),
    .direct_accel_x_i      (16'sd0),
    .direct_accel_y_i      (16'sd0),
    .direct_accel_z_i      (16'sd0),
    .sample_valid_o        (sample_valid),
    .accel_x_o             (ax),
    .accel_y_o             (ay),
    .accel_z_o             (az)
  );

  always #5 clk = ~clk;

  task automatic check(string name, logic cond);
    if (!cond) begin
      $display("[FAIL] %s @ t=%0t", name, $time);
      errors++;
    end else begin
      $display("[PASS] %s", name);
    end
  endtask

  initial begin
    rst_n = 0;
    repeat (3) @(posedge clk);
    rst_n = 1;
    repeat (2) @(posedge clk);

    // Test 1: SPI Source Select (sensor_sel = 0)
    sensor_sel = 2'b00;
    @(posedge clk); #1;
    spi_valid = 1;
    @(posedge clk); #1;
    spi_valid = 0;
    @(posedge clk); #1;
    check("Sensor Hub routes SPI data", ax == 16'sd100 && ay == 16'sd200 && az == 16'sd300);

    // Test 2: I2C Source Select (sensor_sel = 1)
    sensor_sel = 2'b01;
    @(posedge clk); #1;
    i2c_valid = 1;
    @(posedge clk); #1;
    i2c_valid = 0;
    @(posedge clk); #1;
    check("Sensor Hub routes I2C data", ax == 16'sd400 && ay == 16'sd500 && az == 16'sd600);

    // Test 3: Integrated On-Chip MEMS Sensor Select (sensor_sel = 2)
    sensor_sel = 2'b10;
    @(posedge clk); #1;
    onchip_valid = 1;
    @(posedge clk); #1;
    onchip_valid = 0;
    @(posedge clk); #1;
    check("Sensor Hub routes On-Chip MEMS sensor data", ax == 16'sd700 && ay == 16'sd800 && az == 16'sd900);

    // Test 4: Axis Inversion (invert Z axis)
    axis_invert = 3'b100; // invert Z
    @(posedge clk); #1;
    onchip_valid = 1;
    @(posedge clk); #1;
    onchip_valid = 0;
    @(posedge clk); #1;
    check("Sensor Hub applies axis inversion (Z inverted)", az == -16'sd900);

    if (errors == 0) $display("\n=== ALL SENSOR HUB TESTS PASSED ===");
    else $display("\n=== %0d TEST(S) FAILED ===", errors);

    $finish;
  end

  initial begin
    #20000;
    $display("[FAIL] TIMEOUT");
    $finish;
  end

endmodule
