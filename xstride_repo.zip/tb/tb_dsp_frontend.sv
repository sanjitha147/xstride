`timescale 1ns/1ps
module tb_dsp_frontend;

  logic clk = 0;
  logic rst_n = 0;
  logic en = 1;
  logic sample_valid = 0;
  logic signed [15:0] ax = 0, ay = 0, az = 0;

  logic motion_detected, feature_ready;
  logic [15:0] feat_mag, feat_zcr, feat_cad;

  int errors = 0;

  dsp_frontend #(
    .WINDOW_SAMPLES(16),
    .IIR_SHIFT(2),
    .MOTION_THRESHOLD(16'd1000)
  ) dut (
    .clk_i(clk), .rst_ni(rst_n), .en_i(en),
    .sample_valid_i(sample_valid),
    .accel_x_i(ax), .accel_y_i(ay), .accel_z_i(az),
    .motion_detected_o(motion_detected),
    .feature_ready_o(feature_ready),
    .feat_magnitude_o(feat_mag),
    .feat_zcr_o(feat_zcr),
    .feat_cadence_o(feat_cad)
  );

  always #5 clk = ~clk;

  task automatic check(string name, logic cond);
    if (!cond) begin
      $display("[FAIL] %s @ t=%0t", name, $time);
      errors++;
    end else begin
      $display("[PASS] %s", name);
    end
  endtask

  logic motion_during_last_sample;

  task automatic push_sample(input logic signed [15:0] x, y, z);
    @(posedge clk);
    ax = x; ay = y; az = z; sample_valid = 1;
    #1; motion_during_last_sample = motion_detected; // sample while still valid
    @(posedge clk);
    sample_valid = 0;
  endtask

  int feature_ready_count;

  initial begin
    rst_n = 0;
    repeat (3) @(posedge clk);
    rst_n = 1;
    @(posedge clk);

    // Below threshold: no motion detected
    push_sample(16'sd10, 16'sd10, 16'sd10);
    #1;
    check("small accel -> no motion detected", !motion_detected);

    // Above threshold: |x|+|y|+|z| = 500+500+500 = 1500 > 1000
    push_sample(16'sd500, 16'sd500, 16'sd500);
    check("large accel -> motion detected", motion_during_last_sample);

    // Negative values should still contribute via abs()
    push_sample(-16'sd500, -16'sd500, -16'sd500);
    check("negative large accel -> motion detected (abs works)", motion_during_last_sample);

    // Feed WINDOW_SAMPLES=16 total samples (3 pushed so far) and watch for
    // exactly one feature_ready pulse at sample #16, then counter resets.
    feature_ready_count = 0;
    fork
      begin : monitor
        forever begin
          @(posedge clk);
          if (feature_ready) feature_ready_count++;
        end
      end
    join_none

    for (int i = 0; i < 13; i++) begin
      push_sample(16'sd100 + i[15:0], -(16'sd50), 16'sd20);
    end
    #1;
    check("feature_ready pulses exactly once per 16-sample window", feature_ready_count == 1);

    // Push another full window, expect a second pulse
    for (int i = 0; i < 16; i++) begin
      push_sample(16'sd200, 16'sd50, 16'sd10);
    end
    #1;
    check("second window -> second feature_ready pulse", feature_ready_count == 2);

    // en_i gates the filtering/feature-extraction pipeline (the "DSP proper"),
    // but NOT raw motion detection -- that has to stay live even with en_i=0,
    // otherwise the wake FSM could never see motion to assert en_i in the
    // first place (see comment in dsp_frontend.sv). Verify both halves:
    begin
      logic [15:0] mag_before;
      mag_before = feat_mag;
      en = 0;
      push_sample(16'sd900, 16'sd900, 16'sd900);
      check("power-gated (en=0): raw motion detection still live", motion_during_last_sample);
      push_sample(16'sd900, 16'sd900, 16'sd900);
      #1;
      check("power-gated (en=0): filter output frozen (dsp proper stays off)", feat_mag == mag_before);
      en = 1;
    end

    if (errors == 0) $display("\n=== ALL TESTS PASSED ===");
    else $display("\n=== %0d TEST(S) FAILED ===", errors);

    $finish;
  end

  initial begin
    #20000;
    $display("[FAIL] TIMEOUT -- simulation ran too long");
    $finish;
  end

endmodule
