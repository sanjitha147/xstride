# =============================================================================
# run_all_tests.ps1
# Runs all 14 X-STRIDE unit, integration, constrained-random, dataset replay,
# X-HEEP platform wrapper, UPF 3.0 linter, and ASIC power/area synthesis measurements
# =============================================================================

if (-not (Get-Command iverilog -ErrorAction SilentlyContinue)) {
    if (Test-Path "E:\iverilog\app\bin") {
        $env:PATH = "E:\iverilog\app\bin;" + $env:PATH
    }
}

function Run-TB([string]$name, [string]$cmd) {
    Write-Host "`n========================================================" -ForegroundColor Cyan
    Write-Host " RUNNING: $name" -ForegroundColor Yellow
    Write-Host "========================================================" -ForegroundColor Cyan
    Invoke-Expression $cmd
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[-] $name FAILED" -ForegroundColor Red
        exit 1
    }
}

Run-TB "1. Wake FSM" "iverilog -g2012 -o sim_wake_fsm rtl/wake_fsm.sv tb/tb_wake_fsm.sv; vvp sim_wake_fsm"
Run-TB "2. DSP Front-End" "iverilog -g2012 -o sim_dsp rtl/dsp_frontend.sv tb/tb_dsp_frontend.sv; vvp sim_dsp"
Run-TB "3. Accelerometer SPI Master" "iverilog -g2012 -o sim_accel rtl/accel_spi_intf.sv tb/tb_accel_spi_intf.sv; vvp sim_accel"
Run-TB "4. Integrated On-Chip MEMS Sensor & ADC" "iverilog -g2012 -o sim_onchip rtl/mems_afe_adc.sv rtl/onchip_mems_sensor.sv tb/tb_onchip_mems_sensor.sv; vvp sim_onchip"
Run-TB "5. Unified Sensor Hub" "iverilog -g2012 -o sim_hub rtl/sensor_hub.sv tb/tb_sensor_hub.sv; vvp sim_hub"
Run-TB "6. Headless Mobile App Telemetry Unit" "iverilog -g2012 -o sim_telemetry rtl/mobile_telemetry_unit.sv tb/tb_mobile_telemetry.sv; vvp sim_telemetry"
Run-TB "7. Pedometer Classifier (Leg Shaking vs Walking)" "iverilog -g2012 -o sim_classifier rtl/pedometer_classifier.sv tb/tb_pedometer_classifier.sv; vvp sim_classifier"
Run-TB "8. OBI Register File" "iverilog -g2012 -o sim_regs rtl/xstride_regs_pkg.sv rtl/xstride_regs_obi.sv tb/tb_xstride_regs_obi.sv; vvp sim_regs"
Run-TB "9. Full Top-Level SoC Integration & SVA" "iverilog -g2012 -o sim_top rtl/xstride_regs_pkg.sv rtl/rst_sync.sv rtl/sync_2ff.sv rtl/mems_afe_adc.sv rtl/accel_spi_intf.sv rtl/accel_i2c_intf.sv rtl/onchip_mems_sensor.sv rtl/sensor_hub.sv rtl/calib_stage.sv rtl/dsp_frontend.sv rtl/pedometer_classifier.sv rtl/feature_stats.sv rtl/mobile_telemetry_unit.sv rtl/wake_fsm.sv rtl/xstride_regs_obi.sv rtl/xstride_always_on_top.sv rtl/xstride_sva.sv tb/tb_xstride_top.sv; vvp sim_top"
Run-TB "10. Real Accelerometer Dataset Replay & Clinical Accuracy" "iverilog -g2012 -o sim_replay rtl/xstride_regs_pkg.sv rtl/rst_sync.sv rtl/sync_2ff.sv rtl/mems_afe_adc.sv rtl/accel_spi_intf.sv rtl/accel_i2c_intf.sv rtl/onchip_mems_sensor.sv rtl/sensor_hub.sv rtl/calib_stage.sv rtl/dsp_frontend.sv rtl/pedometer_classifier.sv rtl/feature_stats.sv rtl/mobile_telemetry_unit.sv rtl/wake_fsm.sv rtl/xstride_regs_obi.sv rtl/xstride_always_on_top.sv rtl/xstride_sva.sv tb/tb_coverage.sv tb/tb_real_dataset_replay.sv; vvp sim_replay"
Run-TB "11. Constrained Random Verification & SVA Suite" "iverilog -g2012 -o sim_rand rtl/pedometer_classifier.sv tb/tb_pedometer_randomized.sv; vvp sim_rand"
Run-TB "12. X-HEEP Host Platform Wrapper & Fast IRQ Vectors" "iverilog -g2012 -o sim_heep rtl/xstride_regs_pkg.sv rtl/rst_sync.sv rtl/sync_2ff.sv rtl/mems_afe_adc.sv rtl/accel_spi_intf.sv rtl/accel_i2c_intf.sv rtl/onchip_mems_sensor.sv rtl/sensor_hub.sv rtl/calib_stage.sv rtl/dsp_frontend.sv rtl/pedometer_classifier.sv rtl/feature_stats.sv rtl/mobile_telemetry_unit.sv rtl/wake_fsm.sv rtl/xstride_regs_obi.sv rtl/xstride_always_on_top.sv rtl/x_heep_xstride_wrapper.sv tb/tb_heep_wrapper.sv; vvp sim_heep"
Run-TB "13. IEEE 1801 UPF 3.0 Linter & Static Rule Checker" "python scripts/check_upf.py"
Run-TB "14. 65nm LP ASIC Physical Synthesis & Power Measurement" "python scripts/synth_power_analysis.py"

Write-Host "`n========================================================" -ForegroundColor Green
Write-Host " ALL 14 TESTBENCHES & ANALYSIS CHECKS PASSED WITH 100% SUCCESS!" -ForegroundColor Green
Write-Host "========================================================`n" -ForegroundColor Green
