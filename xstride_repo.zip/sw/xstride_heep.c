/**
 * @file xstride_heep.c
 * @brief X-STRIDE Pedometer & Physiological Coprocessor Driver Implementation
 * @details Implements low-power configuration, metric acquisition, interrupt handling,
 *          and AON retention management for EPFL X-HEEP (CV32E40P RISC-V platform).
 */

#include "xstride_heep.h"

// Hardware register access macros
#define XSTRIDE_REG(base, offset)  (*(volatile uint32_t *)((base) + (offset)))

static uint32_t s_base_addr = XSTRIDE_DEFAULT_BASE_ADDR;
static xstride_event_cb_t s_user_cb = 0;
static void *s_user_context = 0;

void xstride_init(uint32_t base_addr, xstride_sensor_t sensor, uint16_t step_threshold)
{
    s_base_addr = base_addr;

    // 1. Configure step peak detection sensitivity threshold
    XSTRIDE_REG(s_base_addr, XSTRIDE_REG_STEP_THRESH) = (uint32_t)step_threshold;

    // 2. Configure sensor interface selection (SPI=0, I2C=1, On-chip MEMS=2)
    uint32_t ctrl_val = (1U << 0) |                   // soft_en = 1
                        (1U << 1) |                   // shake_filter_en = 1
                        (((uint32_t)sensor & 0x3U) << XSTRIDE_CTRL_SENSOR_SEL_SHIFT);
    XSTRIDE_REG(s_base_addr, XSTRIDE_REG_CTRL) = ctrl_val;

    // 3. Clear sticky interrupt / acknowledge initial core wake
    XSTRIDE_REG(s_base_addr, XSTRIDE_REG_IRQ_ACK) = 1U;
}

void xstride_enable(bool enable)
{
    uint32_t ctrl = XSTRIDE_REG(s_base_addr, XSTRIDE_REG_CTRL);
    if (enable) {
        ctrl |= XSTRIDE_CTRL_SOFT_EN_MASK;
    } else {
        ctrl &= ~XSTRIDE_CTRL_SOFT_EN_MASK;
    }
    XSTRIDE_REG(s_base_addr, XSTRIDE_REG_CTRL) = ctrl;
}

void xstride_set_shake_filter(bool enable)
{
    uint32_t ctrl = XSTRIDE_REG(s_base_addr, XSTRIDE_REG_CTRL);
    if (enable) {
        ctrl |= XSTRIDE_CTRL_SHAKE_FILTER_MASK;
    } else {
        ctrl &= ~XSTRIDE_CTRL_SHAKE_FILTER_MASK;
    }
    XSTRIDE_REG(s_base_addr, XSTRIDE_REG_CTRL) = ctrl;
}

void xstride_set_range(xstride_range_t range)
{
    uint32_t sctrl = XSTRIDE_REG(s_base_addr, XSTRIDE_REG_SENSOR_CTRL);
    sctrl &= ~XSTRIDE_SCTRL_RANGE_SEL_MASK;
    sctrl |= (((uint32_t)range & 0x3U) << XSTRIDE_SCTRL_RANGE_SEL_SHIFT);
    XSTRIDE_REG(s_base_addr, XSTRIDE_REG_SENSOR_CTRL) = sctrl;
}

void xstride_get_metrics(xstride_metrics_t *metrics)
{
    if (!metrics) return;

    // Atomic read of retained accumulators in PD_AON
    metrics->total_steps         = XSTRIDE_REG(s_base_addr, XSTRIDE_REG_TOTAL_STEPS);
    metrics->walk_steps          = XSTRIDE_REG(s_base_addr, XSTRIDE_REG_WALK_STEPS);
    metrics->run_steps           = XSTRIDE_REG(s_base_addr, XSTRIDE_REG_RUN_STEPS);
    metrics->shake_events        = XSTRIDE_REG(s_base_addr, XSTRIDE_REG_SHAKE_EVENTS);
    metrics->shake_duration_sec  = XSTRIDE_REG(s_base_addr, XSTRIDE_REG_SHAKE_DURATION);
    metrics->cadence_spm         = (uint16_t)(XSTRIDE_REG(s_base_addr, XSTRIDE_REG_CADENCE_SPM) & 0xFFFFU);

    uint32_t status = XSTRIDE_REG(s_base_addr, XSTRIDE_REG_STATUS);
    metrics->current_activity    = (xstride_activity_t)((status >> XSTRIDE_STATUS_ACT_CLASS_SHIFT) & 0x7U);
}

void xstride_get_raw_accel(int16_t *x, int16_t *y, int16_t *z)
{
    uint32_t xy = XSTRIDE_REG(s_base_addr, XSTRIDE_REG_RAW_ACCEL_XY);
    uint32_t z_reg = XSTRIDE_REG(s_base_addr, XSTRIDE_REG_RAW_ACCEL_Z);

    if (x) *x = (int16_t)((xy >> 16) & 0xFFFFU);
    if (y) *y = (int16_t)(xy & 0xFFFFU);
    if (z) *z = (int16_t)(z_reg & 0xFFFFU);
}

void xstride_ack_irq(void)
{
    XSTRIDE_REG(s_base_addr, XSTRIDE_REG_IRQ_ACK) = 1U;
}

void xstride_register_callback(xstride_event_cb_t cb, void *context)
{
    s_user_cb = cb;
    s_user_context = context;
}

void xstride_isr_handler(uint32_t irq_num)
{
    // Acknowledge wake interrupt to complete power manager handshake
    if (irq_num == XSTRIDE_FAST_IRQ_WAKE) {
        xstride_ack_irq();
    }

    if (s_user_cb) {
        s_user_cb(irq_num, s_user_context);
    }
}

uint32_t xstride_drain_telemetry_fifo(uint32_t *buffer, uint32_t max_words)
{
    if (!buffer || max_words == 0) return 0;

    uint32_t count = 0;
    while (count < max_words) {
        uint32_t status = XSTRIDE_REG(s_base_addr, XSTRIDE_REG_MOBILE_STATUS);
        if (status & XSTRIDE_MSTAT_FIFO_EMPTY_MASK) {
            break; // FIFO empty
        }
        buffer[count++] = XSTRIDE_REG(s_base_addr, XSTRIDE_REG_MOBILE_FIFO);
    }
    return count;
}

void xstride_enter_retention_sleep(void)
{
    // Ensure IRQ is acknowledged so wake FSM is prepared to detect next wake event
    xstride_ack_irq();
    // In X-HEEP, the core executes WFI (Wait-For-Interrupt) and the power manager
    // cuts power to the CPU core domain. All X-STRIDE metrics remain live in PD_AON.
}
