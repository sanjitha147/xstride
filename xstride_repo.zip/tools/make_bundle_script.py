import os
import sys
import zlib
import base64
import json
import subprocess

def main():
    files = subprocess.check_output(['git', 'ls-files'], text=True).splitlines()
    bundle = {}
    for f in files:
        if f.endswith('.bundle') or f.endswith('.zip') or f.endswith('.pyc'):
            continue
        with open(f, 'rb') as fp:
            bundle[f] = base64.b64encode(fp.read()).decode('ascii')

    json_data = json.dumps(bundle)
    compressed = zlib.compress(json_data.encode('utf-8'), 9)
    b64_payload = base64.b64encode(compressed).decode('ascii')

    template = f'''#!/usr/bin/env python3
"""
================================================================================
 X-STRIDE Ultra-Low-Power Pedometer SoC - Self-Extracting Repository Generator
================================================================================
 This single script extracts the complete, production-ready X-STRIDE codebase
 and initializes a local Git repository automatically.

 Usage:
     python setup_repo.py [target_directory]

 Example:
     python setup_repo.py my_xstride_repo
     cd my_xstride_repo
     git remote add origin https://github.com/USERNAME/xstride-soc.git
     git push -u origin main
================================================================================
"""

import os
import sys
import zlib
import json
import base64
import subprocess

PAYLOAD = """{b64_payload}"""

def extract_and_init():
    target_dir = sys.argv[1] if len(sys.argv) > 1 else "xstride_rtl"
    abs_target = os.path.abspath(target_dir)
    print(f"[*] Extracting complete X-STRIDE repository into: {{abs_target}}...")
    os.makedirs(abs_target, exist_ok=True)

    raw_json = zlib.decompress(base64.b64decode(PAYLOAD.strip())).decode("utf-8")
    files = json.loads(raw_json)

    for rel_path, b64_content in files.items():
        dest_path = os.path.join(abs_target, rel_path)
        os.makedirs(os.path.dirname(dest_path), exist_ok=True)
        content = base64.b64decode(b64_content)
        with open(dest_path, "wb") as fp:
            fp.write(content)
        print(f"  [+] Unpacked: {{rel_path}}")

    print(f"[OK] Successfully extracted {{len(files)}} files.")

    # Initialize Git repository
    print("[*] Initializing local Git repository...")
    try:
        subprocess.run(["git", "init"], cwd=abs_target, check=True)
        subprocess.run(["git", "config", "user.name", "X-STRIDE Team"], cwd=abs_target, check=True)
        subprocess.run(["git", "config", "user.email", "team@xstride.io"], cwd=abs_target, check=True)
        subprocess.run(["git", "add", "."], cwd=abs_target, check=True)
        subprocess.run(["git", "commit", "-m", "feat: complete tapeout-ready X-STRIDE pedometer SoC with 14-test verification"], cwd=abs_target, check=True)
        print("[OK] Git repository initialized and all files committed on master branch!")
    except Exception as e:
        print(f"[!] Git initialization note: {{e}}")

    print("""
================================================================================
 X-STRIDE SOC REPOSITORY SETUP COMPLETE!
================================================================================
 To push this repository to GitHub or GitLab:
     cd {{target_dir}}
     git branch -M main
     git remote add origin https://github.com/<YOUR_USERNAME>/<YOUR_REPO_NAME>.git
     git push -u origin main

 To execute the complete 14-test verification regression suite:
     powershell -ExecutionPolicy Bypass -File .\\\\run_all_tests.ps1   # Windows
     ./run_all_tests.sh                                              # Linux / macOS
================================================================================
""")

if __name__ == "__main__":
    extract_and_init()
'''

    with open('setup_repo.py', 'w', encoding='utf-8') as out:
        out.write(template)
    print(f"[OK] Generated setup_repo.py ({len(files)} files, {len(template)} bytes)")

if __name__ == '__main__':
    main()
