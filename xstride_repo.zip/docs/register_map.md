# X-STRIDE Register Map Reference

Auto-generated from `regs/xstride_regs.yaml`.

| Offset | Name | Type | Reset Value | Description |
|---|---|---|---|---|
| `0x00` | `CTRL` | RW | `0x00000003` | System enable, leg-shaking filter enable, and physical sensor selection |
| `0x04` | `STATUS` | RO | `0x00000000` | Wake FSM state, motion detection flag, and real-time activity class |
| `0x08` | `FEAT_MAGNITUDE` | RO | `0x00000000` | Filtered dynamic acceleration magnitude (L1 norm proxy) |
| `0x0C` | `FEAT_ZCR` | RO | `0x00000000` | Zero-crossing rate across feature window |
| `0x10` | `FEAT_CADENCE` | RO | `0x00000000` | Cadence metric derived from zero crossings |
| `0x14` | `TINYML_CLASS` | RO | `0x00000000` | Activity classification / TinyML output class |
| `0x18` | `IRQ_ACK` | WO | `0x00000000` | Host interrupt acknowledge strobe |
| `0x1C` | `TOTAL_STEPS` | RO | `0x00000000` | Confirmed total human ambulatory steps (AON retained) |
| `0x20` | `WALK_STEPS` | RO | `0x00000000` | Walking strides count (AON retained) |
| `0x24` | `RUN_STEPS` | RO | `0x00000000` | Running / jogging strides count (AON retained) |
| `0x28` | `SHAKE_EVENTS` | RO | `0x00000000` | Seated leg shaking / tremor episodes count (AON retained) |
| `0x2C` | `SHAKE_DURATION` | RO | `0x00000000` | Cumulative time in leg shaking in seconds (AON retained) |
| `0x30` | `CADENCE_SPM` | RO | `0x00000000` | Instantaneous ambulatory cadence in steps per minute |
| `0x34` | `SENSOR_CTRL` | RW | `0x00000000` | On-chip sensor range and self-test actuation |
| `0x38` | `RAW_ACCEL_XY` | RO | `0x00000000` | Raw calibrated accelerometer X and Y axes |
| `0x3C` | `RAW_ACCEL_Z` | RO | `0x00000000` | Raw calibrated accelerometer Z axis |
| `0x40` | `MOBILE_STATUS` | RO | `0x00000100` | Telemetry unit FIFO status flags |
| `0x44` | `MOBILE_FIFO_DATA` | RO | `0x00000000` | Pop word from telemetry FIFO |
| `0x48` | `STEP_THRESHOLD` | RW | `0x000004B0` | Step peak detection sensitivity threshold (default 1200) |
| `0x4C` | `RUN_THRESHOLD` | RW | `0x00000C80` | Running / jogging magnitude threshold (default 3200) |
| `0x50` | `PERIOD_CFG` | RW | `0x0041000C` | Biomechanical step cadence bounds (min/max periods in samples) |
| `0x54` | `SHAKE_CFG` | RW | `0x012C181A` | Physiological tremor / leg-shaking discrimination parameters |
| `0x58` | `LOCK_CFG` | RW | `0x00000203` | Rhythm lock count and IIR filter response |
| `0x5C` | `WAKE_CFG` | RW | `0x008003E8` | Motion wake threshold and feature window length |
| `0x60` | `ODR_CFG` | RW | `0x0BB80032` | Sensor Output Data Rate and cadence conversion numerator |
| `0x64` | `GAIN_XY` | RW | `0x40004000` | X and Y axis sensitivity calibration gain (Q2.14, 0x4000 = 1.0) |
| `0x68` | `GAIN_Z` | RW | `0x00004000` | Z axis sensitivity calibration gain (Q2.14, 0x4000 = 1.0) |
| `0x6C` | `OFFSET_XY` | RW | `0x00000000` | X and Y axis zero-g bias offset calibration (signed 16-bit) |
| `0x70` | `OFFSET_Z` | RW | `0x00000000` | Z axis zero-g bias offset calibration (signed 16-bit) |
| `0x74` | `PROFILE_CTRL` | RW | `0x00000000` | Profile atomic commit, defaults load, and register lock control |
| `0x78` | `PROFILE_STATUS` | RO | `0x00000002` | Profile commit status and active version |
| `0x7C` | `STAT_CTRL` | RW | `0x00000000` | Hardware statistics collection control |
| `0x80` | `STAT_MAG_MIN` | RO | `0x0000FFFF` | Minimum filtered acceleration magnitude observed |
| `0x84` | `STAT_MAG_MAX` | RO | `0x00000000` | Maximum filtered acceleration magnitude observed |
| `0x88` | `STAT_PEAK_AVG` | RO | `0x00000000` | Exponential moving average of detected stride peak heights |
| `0x8C` | `STAT_PERIOD_AVG` | RO | `0x00000000` | Exponential moving average of stride peak-to-peak periods (samples) |
| `0x90` | `STAT_ZCR_MAX` | RO | `0x00000000` | Maximum zero-crossing rate seen in any feature window |

## Detailed Field Descriptions

### CTRL (`0x00` - RW)
*System enable, leg-shaking filter enable, and physical sensor selection* (Reset: `0x00000003`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[0]` | `SOFT_EN` | `1` | Software enable (1: active processing, 0: low-power standby) |
| `[1]` | `SHAKE_FILTER_EN` | `1` | Leg shaking filter enable (1: lock out fidgeting from step counters) |
| `[3]` | `SENSOR_SEL` | `0` | Sensor selection (00: SPI Master, 01: I2C Master, 10: On-Chip MEMS) |

### STATUS (`0x04` - RO)
*Wake FSM state, motion detection flag, and real-time activity class* (Reset: `0x00000000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[1]` | `FSM_STATE` | `0` | Power FSM state (00: SLEEP, 01: IDLE, 10: ACTIVE, 11: CORE_SYNC) |
| `[2]` | `MOTION_DETECTED` | `0` | Motion detected sticky/live flag |
| `[3]` | `FEAT_READY_STICKY` | `0` | Feature window ready sticky flag (cleared on read) |
| `[6]` | `ACTIVITY_CLASS` | `0` | Activity classification (0: REST, 1: LEG_SHAKE, 2: WALK, 3: RUN, 4: EXERCISE) |

### FEAT_MAGNITUDE (`0x08` - RO)
*Filtered dynamic acceleration magnitude (L1 norm proxy)* (Reset: `0x00000000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[15]` | `MAGNITUDE` | `0` | Smoothed acceleration magnitude |

### FEAT_ZCR (`0x0C` - RO)
*Zero-crossing rate across feature window* (Reset: `0x00000000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[15]` | `ZCR` | `0` | Zero-crossing count per window |

### FEAT_CADENCE (`0x10` - RO)
*Cadence metric derived from zero crossings* (Reset: `0x00000000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[15]` | `CADENCE` | `0` | Window cadence metric |

### TINYML_CLASS (`0x14` - RO)
*Activity classification / TinyML output class* (Reset: `0x00000000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[7]` | `CLASS` | `0` | Class identifier |

### IRQ_ACK (`0x18` - WO)
*Host interrupt acknowledge strobe* (Reset: `0x00000000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[0]` | `ACK` | `0` | Write 1 to clear host wake IRQ |

### TOTAL_STEPS (`0x1C` - RO)
*Confirmed total human ambulatory steps (AON retained)* (Reset: `0x00000000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[31]` | `COUNT` | `0` | 32-bit confirmed step counter |

### WALK_STEPS (`0x20` - RO)
*Walking strides count (AON retained)* (Reset: `0x00000000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[31]` | `COUNT` | `0` | 32-bit walking steps |

### RUN_STEPS (`0x24` - RO)
*Running / jogging strides count (AON retained)* (Reset: `0x00000000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[31]` | `COUNT` | `0` | 32-bit running strides |

### SHAKE_EVENTS (`0x28` - RO)
*Seated leg shaking / tremor episodes count (AON retained)* (Reset: `0x00000000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[31]` | `COUNT` | `0` | 32-bit shake episodes |

### SHAKE_DURATION (`0x2C` - RO)
*Cumulative time in leg shaking in seconds (AON retained)* (Reset: `0x00000000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[31]` | `SECONDS` | `0` | 32-bit duration counter |

### CADENCE_SPM (`0x30` - RO)
*Instantaneous ambulatory cadence in steps per minute* (Reset: `0x00000000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[15]` | `SPM` | `0` | Cadence in steps per minute |

### SENSOR_CTRL (`0x34` - RW)
*On-chip sensor range and self-test actuation* (Reset: `0x00000000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[1]` | `SENSOR_SEL` | `0` | Sensor selection |
| `[2]` | `SELF_TEST_EN` | `0` | Actuate electrostatic MEMS self-test |
| `[4]` | `RANGE_SEL` | `0` | Full scale range (00: 2g, 01: 4g, 10: 8g, 11: 16g) |

### RAW_ACCEL_XY (`0x38` - RO)
*Raw calibrated accelerometer X and Y axes* (Reset: `0x00000000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[15]` | `ACCEL_Y` | `0` | Signed 16-bit Y acceleration |
| `[31]` | `ACCEL_X` | `0` | Signed 16-bit X acceleration |

### RAW_ACCEL_Z (`0x3C` - RO)
*Raw calibrated accelerometer Z axis* (Reset: `0x00000000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[15]` | `ACCEL_Z` | `0` | Signed 16-bit Z acceleration |

### MOBILE_STATUS (`0x40` - RO)
*Telemetry unit FIFO status flags* (Reset: `0x00000100`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[7]` | `FIFO_COUNT` | `0` | FIFO depth in words (0..32) |
| `[8]` | `FIFO_EMPTY` | `1` | FIFO empty flag |
| `[9]` | `FIFO_FULL` | `0` | FIFO full flag |

### MOBILE_FIFO_DATA (`0x44` - RO)
*Pop word from telemetry FIFO* (Reset: `0x00000000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[31]` | `DATA` | `0` | Popped 32-bit packet word |

### STEP_THRESHOLD (`0x48` - RW)
*Step peak detection sensitivity threshold (default 1200)* (Reset: `0x000004B0`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[15]` | `THRESHOLD` | `1200` | Step detection magnitude threshold |

### RUN_THRESHOLD (`0x4C` - RW)
*Running / jogging magnitude threshold (default 3200)* (Reset: `0x00000C80`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[15]` | `THRESHOLD` | `3200` | Running classification threshold |

### PERIOD_CFG (`0x50` - RW)
*Biomechanical step cadence bounds (min/max periods in samples)* (Reset: `0x0041000C`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[15]` | `MIN_PERIOD` | `12` | Min step period in samples (default 12 = 240 ms at 50 Hz) |
| `[31]` | `MAX_PERIOD` | `65` | Max step period in samples (default 65 = 1.30 s at 50 Hz) |

### SHAKE_CFG (`0x54` - RW)
*Physiological tremor / leg-shaking discrimination parameters* (Reset: `0x012C181A`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[7]` | `ZCR_THRESH` | `26` | Shake ZCR threshold (crossings per window, default 26) |
| `[15]` | `DOM_RATIO_Q4` | `24` | Single-axis dominance ratio in Q4 (24 = 1.5x, default 24) |
| `[31]` | `DOM_FLOOR` | `300` | Single-axis dominance diff floor in LSBs (default 300) |

### LOCK_CFG (`0x58` - RW)
*Rhythm lock count and IIR filter response* (Reset: `0x00000203`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[3]` | `LOCK_COUNT` | `3` | Consecutive rhythmic steps required before commitment (default 3 = 4th step) |
| `[15]` | `IIR_SHIFT` | `2` | Dynamic magnitude filter pole shift (alpha = 1/(2^shift), default 2 = 1/4) |

### WAKE_CFG (`0x5C` - RW)
*Motion wake threshold and feature window length* (Reset: `0x008003E8`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[15]` | `WAKE_THRESH` | `1000` | Motion wake threshold in LSBs (default 1000) |
| `[31]` | `WINDOW_LEN` | `128` | Feature window length in samples (default 128) |

### ODR_CFG (`0x60` - RW)
*Sensor Output Data Rate and cadence conversion numerator* (Reset: `0x0BB80032`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[15]` | `ODR_HZ` | `50` | Sensor ODR in Hz (default 50 Hz) |
| `[31]` | `CADENCE_NUM` | `3000` | Cadence numerator = 60 * ODR (default 3000) |

### GAIN_XY (`0x64` - RW)
*X and Y axis sensitivity calibration gain (Q2.14, 0x4000 = 1.0)* (Reset: `0x40004000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[15]` | `GAIN_X` | `16384` | X axis gain in Q2.14 |
| `[31]` | `GAIN_Y` | `16384` | Y axis gain in Q2.14 |

### GAIN_Z (`0x68` - RW)
*Z axis sensitivity calibration gain (Q2.14, 0x4000 = 1.0)* (Reset: `0x00004000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[15]` | `GAIN_Z` | `16384` | Z axis gain in Q2.14 |

### OFFSET_XY (`0x6C` - RW)
*X and Y axis zero-g bias offset calibration (signed 16-bit)* (Reset: `0x00000000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[15]` | `OFFSET_X` | `0` | Signed 16-bit X offset |
| `[31]` | `OFFSET_Y` | `0` | Signed 16-bit Y offset |

### OFFSET_Z (`0x70` - RW)
*Z axis zero-g bias offset calibration (signed 16-bit)* (Reset: `0x00000000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[15]` | `OFFSET_Z` | `0` | Signed 16-bit Z offset |

### PROFILE_CTRL (`0x74` - RW)
*Profile atomic commit, defaults load, and register lock control* (Reset: `0x00000000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[0]` | `COMMIT` | `0` | Write 1 to commit pending bank to active bank at sample boundary (self-clearing) |
| `[1]` | `LOAD_DEFAULTS` | `0` | Write 1 to reload factory default parameters into pending bank (self-clearing) |
| `[2]` | `LOCK` | `0` | Write 1 to lock configuration registers against further writes until reset |
| `[31]` | `VERSION` | `0` | Profile version tag (retained) |

### PROFILE_STATUS (`0x78` - RO)
*Profile commit status and active version* (Reset: `0x00000002`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[0]` | `PENDING` | `0` | Commit request pending sample boundary |
| `[1]` | `APPLIED` | `1` | Active bank successfully loaded |
| `[2]` | `RANGE_ERROR` | `0` | Range error detected during commit validation |
| `[31]` | `ACTIVE_VERSION` | `0` | Active profile version tag |

### STAT_CTRL (`0x7C` - RW)
*Hardware statistics collection control* (Reset: `0x00000000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[0]` | `ENABLE` | `0` | Enable feature statistics tracking |
| `[1]` | `CLEAR` | `0` | Write 1 to clear statistics accumulators (self-clearing) |

### STAT_MAG_MIN (`0x80` - RO)
*Minimum filtered acceleration magnitude observed* (Reset: `0x0000FFFF`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[15]` | `VALUE` | `65535` | Minimum magnitude value |

### STAT_MAG_MAX (`0x84` - RO)
*Maximum filtered acceleration magnitude observed* (Reset: `0x00000000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[15]` | `VALUE` | `0` | Maximum magnitude value |

### STAT_PEAK_AVG (`0x88` - RO)
*Exponential moving average of detected stride peak heights* (Reset: `0x00000000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[15]` | `VALUE` | `0` | Peak height average |

### STAT_PERIOD_AVG (`0x8C` - RO)
*Exponential moving average of stride peak-to-peak periods (samples)* (Reset: `0x00000000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[15]` | `VALUE` | `0` | Period average in samples |

### STAT_ZCR_MAX (`0x90` - RO)
*Maximum zero-crossing rate seen in any feature window* (Reset: `0x00000000`)

| Bits | Field Name | Reset | Description |
|---|---|---|---|
| `[15]` | `VALUE` | `0` | Maximum ZCR value |
