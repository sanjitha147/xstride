// =============================================================================
// dsp_frontend.sv
// X-STRIDE DSP Front-End: Filtering, Dynamic Magnitude & Feature Extraction
//
// Key Enhancements:
//   - Runtime configurable motion wake threshold (motion_th_i)
//   - Runtime configurable IIR filter pole shift (iir_shift_i, 1..5)
//   - Runtime configurable feature window length (win_len_i)
//   - Fallback to DEFAULT parameters if input is 0 (blank chip bring-up)
// =============================================================================

`timescale 1ns/1ps

module dsp_frontend #(
  parameter int unsigned DATA_W           = 16,
  parameter int unsigned WINDOW_SAMPLES   = 128,     // maximum window length
  parameter int unsigned IIR_SHIFT        = 2,       // default dynamic filter shift (alpha = 1/4)
  parameter int unsigned MOTION_THRESHOLD = 16'd1000 // default wake threshold
) (
  input  logic clk_i,
  input  logic rst_ni,
  input  logic en_i,

  input  logic                      sample_valid_i,
  input  logic signed [DATA_W-1:0]  accel_x_i,
  input  logic signed [DATA_W-1:0]  accel_y_i,
  input  logic signed [DATA_W-1:0]  accel_z_i,

  // Runtime Tunability Inputs (from Active Config Bank in PD_AON)
  input  logic [15:0]               motion_th_i,
  input  logic [7:0]                iir_shift_i,
  input  logic [15:0]               win_len_i,

  output logic                      motion_detected_o,

  output logic                      feature_ready_o,   // pulse on window completion
  output logic [DATA_W-1:0]         feat_magnitude_o,  // smoothed acceleration magnitude
  output logic [15:0]               feat_zcr_o,
  output logic [15:0]               feat_cadence_o
);

  function automatic logic signed [DATA_W-1:0] abs_s(input logic signed [DATA_W-1:0] v);
    abs_s = v[DATA_W-1] ? -v : v;
  endfunction

  // Effective Runtime Parameters
  logic [15:0] cfg_motion_th;
  logic [3:0]  cfg_iir_shift;
  logic [15:0] cfg_win_len;

  assign cfg_motion_th = (motion_th_i == '0 || motion_th_i === 16'bz || motion_th_i === 16'bx) ? 16'(MOTION_THRESHOLD) : motion_th_i;
  assign cfg_iir_shift = (iir_shift_i == '0 || iir_shift_i === 8'bz  || iir_shift_i === 8'bx)  ? 4'(IIR_SHIFT)         : iir_shift_i[3:0];
  assign cfg_win_len   = (win_len_i == '0   || win_len_i === 16'bz  || win_len_i === 16'bx)   ? 16'(WINDOW_SAMPLES)   : win_len_i;

  logic signed [DATA_W-1:0] mag_raw;
  logic signed [DATA_W-1:0] filt_q, filt_d;
  logic signed [DATA_W-1:0] delta;
  logic                     sign_q, sign_d;
  logic [15:0]              zcr_cnt_q, zcr_cnt_d;
  logic [15:0]              latched_zcr_q;
  logic [15:0]              win_cnt_q, win_cnt_d;

  // Combinational magnitude (L1-norm proxy), saturated to DATA_W
  logic [DATA_W+1:0] mag_sum_ext;
  assign mag_sum_ext = {2'b00, abs_s(accel_x_i)} + {2'b00, abs_s(accel_y_i)} + {2'b00, abs_s(accel_z_i)};
  assign mag_raw     = (mag_sum_ext > ((1 << DATA_W) - 1)) ? {1'b0, {(DATA_W-1){1'b1}}}
                                                           : mag_sum_ext[DATA_W-1:0];

  assign motion_detected_o = sample_valid_i && (mag_raw > cfg_motion_th);

  always @(*) begin
    filt_d          = filt_q;
    sign_d          = sign_q;
    zcr_cnt_d       = zcr_cnt_q;
    win_cnt_d       = win_cnt_q;
    feature_ready_o = 1'b0;
    delta           = '0;

    if (en_i && sample_valid_i) begin
      // Runtime dynamic barrel-shifted single-pole IIR low-pass filter
      delta  = mag_raw - filt_q;
      filt_d = filt_q + (delta >>> cfg_iir_shift);

      sign_d = delta[DATA_W-1];
      if (win_cnt_q != '0 && sign_d != sign_q) begin
        zcr_cnt_d = zcr_cnt_q + 16'd1;
      end

      if (win_cnt_q >= (cfg_win_len - 16'd1)) begin
        win_cnt_d       = '0;
        feature_ready_o = 1'b1;
        zcr_cnt_d       = '0;
      end else begin
        win_cnt_d       = win_cnt_q + 16'd1;
      end
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      filt_q        <= '0;
      sign_q        <= 1'b0;
      zcr_cnt_q     <= '0;
      latched_zcr_q <= '0;
      win_cnt_q     <= '0;
    end else if (!en_i) begin
      filt_q        <= filt_q;
      sign_q        <= sign_q;
      zcr_cnt_q     <= zcr_cnt_q;
      latched_zcr_q <= latched_zcr_q;
      win_cnt_q     <= win_cnt_q;
    end else begin
      filt_q    <= filt_d;
      sign_q    <= sign_d;
      zcr_cnt_q <= zcr_cnt_d;
      win_cnt_q <= win_cnt_d;

      if (feature_ready_o) begin
        latched_zcr_q <= zcr_cnt_d;
      end
    end
  end

  assign feat_magnitude_o = filt_q;
  assign feat_zcr_o       = (feature_ready_o) ? zcr_cnt_d : latched_zcr_q;
  assign feat_cadence_o   = feat_zcr_o;

endmodule
