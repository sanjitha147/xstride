// =============================================================================
// accel_spi_intf.sv
// X-STRIDE Accelerometer SPI Interface
//
// Simple SPI master, mode 0 (CPOL=0, CPHA=0), that periodically issues a
// burst read of 3x 16-bit axis registers (X,Y,Z) from an SPI accelerometer
// (BMA400 / ADXL362-style read protocol: 1 command byte, then N data bytes).
//
// Sampling cadence is set by SAMPLE_PERIOD_CYCLES (in clk_i cycles), and the
// whole block is power-gated by en_i from the wake FSM (SLEEP state keeps
// this alive at reduced rate; IDLE/ACTIVE keep it fully alive).
//
// NOTE: READ_CMD is a placeholder byte -- swap for your actual accelerometer's
// "burst-read starting at X-axis register" command per its datasheet.
// =============================================================================

module accel_spi_intf #(
  parameter int unsigned CLK_DIV              = 8,        // spi_sclk = clk_i/(2*CLK_DIV)
  parameter int unsigned SAMPLE_PERIOD_CYCLES = 32'd500_000, // e.g. 100 Hz @ 50 MHz clk
  parameter logic [7:0]  READ_CMD             = 8'h0B      // placeholder burst-read opcode
) (
  input  logic clk_i,
  input  logic rst_ni,
  input  logic en_i,

  // SPI pins
  output logic spi_sclk_o,
  output logic spi_cs_no,
  output logic spi_mosi_o,
  input  logic spi_miso_i,

  // Sampled output
  output logic                sample_valid_o,   // one-cycle pulse
  output logic signed [15:0]  accel_x_o,
  output logic signed [15:0]  accel_y_o,
  output logic signed [15:0]  accel_z_o
);

  typedef enum logic [2:0] {
    ST_IDLE,
    ST_WAIT,
    ST_CS_ASSERT,
    ST_SHIFT,
    ST_CS_DEASSERT
  } state_e;

  localparam int unsigned TOTAL_BYTES = 7;  // 1 cmd byte + 6 data bytes (X,Y,Z x 16b)
  localparam int unsigned TOTAL_BITS  = TOTAL_BYTES * 8;

  state_e      state_q, state_d;
  logic [31:0] period_cnt_q, period_cnt_d;
  logic [$clog2(CLK_DIV+1)-1:0] div_cnt_q, div_cnt_d;
  logic [$clog2(TOTAL_BITS+1)-1:0] bit_cnt_q, bit_cnt_d;
  logic [TOTAL_BITS-1:0] tx_shreg_q, tx_shreg_d;
  logic [TOTAL_BITS-1:0] rx_shreg_q, rx_shreg_d;
  logic sclk_q, sclk_d;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q      <= ST_IDLE;
      period_cnt_q <= '0;
      div_cnt_q    <= '0;
      bit_cnt_q    <= '0;
      tx_shreg_q   <= '0;
      rx_shreg_q   <= '0;
      sclk_q       <= 1'b0;
    end else begin
      state_q      <= state_d;
      period_cnt_q <= period_cnt_d;
      div_cnt_q    <= div_cnt_d;
      bit_cnt_q    <= bit_cnt_d;
      tx_shreg_q   <= tx_shreg_d;
      rx_shreg_q   <= rx_shreg_d;
      sclk_q       <= sclk_d;
    end
  end

  always_comb begin
    state_d        = state_q;
    period_cnt_d   = period_cnt_q;
    div_cnt_d      = div_cnt_q;
    bit_cnt_d      = bit_cnt_q;
    tx_shreg_d     = tx_shreg_q;
    rx_shreg_d     = rx_shreg_q;
    sclk_d         = sclk_q;

    spi_cs_no      = 1'b1;
    spi_sclk_o     = 1'b0;
    spi_mosi_o     = tx_shreg_q[TOTAL_BITS-1];
    sample_valid_o = 1'b0;

    if (!en_i) begin
      state_d      = ST_IDLE;
      period_cnt_d = '0;
    end else begin
      unique case (state_q)

        ST_IDLE: begin
          period_cnt_d = '0;
          state_d      = ST_WAIT;
        end

        ST_WAIT: begin
          if (period_cnt_q >= SAMPLE_PERIOD_CYCLES) begin
            tx_shreg_d = {READ_CMD, {(TOTAL_BITS-8){1'b0}}};
            bit_cnt_d  = '0;
            div_cnt_d  = '0;
            state_d    = ST_CS_ASSERT;
          end else begin
            period_cnt_d = period_cnt_q + 32'd1;
          end
        end

        ST_CS_ASSERT: begin
          spi_cs_no = 1'b0;
          div_cnt_d = '0;
          sclk_d    = 1'b0;
          state_d   = ST_SHIFT;
        end

        ST_SHIFT: begin
          spi_cs_no = 1'b0;
          spi_sclk_o = sclk_q;

          if (div_cnt_q == CLK_DIV - 1) begin
            div_cnt_d = '0;
            sclk_d    = ~sclk_q;

            if (sclk_q == 1'b0) begin
              // rising edge coming: sample MISO on this transition (mode 0 sample @ rising)
              rx_shreg_d = {rx_shreg_q[TOTAL_BITS-2:0], spi_miso_i};
            end else begin
              // falling edge: advance MOSI shift, count the bit
              tx_shreg_d = {tx_shreg_q[TOTAL_BITS-2:0], 1'b0};
              if (bit_cnt_q == TOTAL_BITS - 1) begin
                state_d = ST_CS_DEASSERT;
              end else begin
                bit_cnt_d = bit_cnt_q + 1'b1;
              end
            end
          end else begin
            div_cnt_d = div_cnt_q + 1'b1;
          end
        end

        ST_CS_DEASSERT: begin
          spi_cs_no      = 1'b1;
          sample_valid_o = 1'b1;
          period_cnt_d   = '0;
          state_d        = ST_WAIT;
        end

        default: state_d = ST_IDLE;
      endcase
    end
  end

  // rx_shreg holds [CMD_ECHO(8) | X(16) | Y(16) | Z(16)] after full transfer
  assign accel_x_o = rx_shreg_q[47:32];
  assign accel_y_o = rx_shreg_q[31:16];
  assign accel_z_o = rx_shreg_q[15:0];

endmodule
