// =============================================================================
// calib_stage.sv
// X-STRIDE Sensor Calibration Stage (Zero-g Offset & Sensitivity Gain)
//
// Sits between sensor_hub and dsp_frontend:
//   out_axis = ((in_axis - offset_axis) * gain_axis) >>> 14
//
// Key Features:
//   - Time-shares a SINGLE 18x18 hardware multiplier across X, Y, Z axes,
//     reducing silicon die area and switching power.
//   - Multiplier operation completes in 3 clock cycles upon sample_valid_i.
//   - Saturated 16-bit signed output clamping (eliminates overflow wrap-around).
//   - Bit-exact bypass when offset = 0 and gain = 0x4000 (1.0 in Q2.14).
// =============================================================================

`timescale 1ns/1ps

module calib_stage #(
  parameter int unsigned DATA_W = 16
) (
  input  logic clk_i,
  input  logic rst_ni,
  input  logic en_i,

  // Input from Sensor Hub
  input  logic                      sample_valid_i,
  input  logic signed [DATA_W-1:0]  accel_x_i,
  input  logic signed [DATA_W-1:0]  accel_y_i,
  input  logic signed [DATA_W-1:0]  accel_z_i,

  // Calibration parameters from Active Config Bank (PD_AON)
  input  logic [15:0]               gain_x_i,      // Q2.14, 0x4000 = 1.0
  input  logic [15:0]               gain_y_i,
  input  logic [15:0]               gain_z_i,
  input  logic signed [15:0]        offset_x_i,    // Signed LSB zero-g bias
  input  logic signed [15:0]        offset_y_i,
  input  logic signed [15:0]        offset_z_i,

  // Calibrated output to DSP Front-End
  output logic                      sample_valid_o,
  output logic signed [DATA_W-1:0]  accel_x_o,
  output logic signed [DATA_W-1:0]  accel_y_o,
  output logic signed [DATA_W-1:0]  accel_z_o
);

  typedef enum logic [2:0] {
    ST_IDLE,
    ST_CALC_X,
    ST_CALC_Y,
    ST_CALC_Z,
    ST_DONE
  } calib_st_e;

  calib_st_e state_q, state_d;

  // Latch input samples on trigger
  logic signed [DATA_W-1:0] in_x_q, in_y_q, in_z_q;
  logic signed [DATA_W-1:0] res_x_q, res_x_d;
  logic signed [DATA_W-1:0] res_y_q, res_y_d;
  logic signed [DATA_W-1:0] res_z_q, res_z_d;

  // Time-shared arithmetic operand selection
  logic signed [16:0] mult_op_a; // 17-bit signed difference
  logic signed [16:0] mult_op_b; // 17-bit signed gain (zero-extended from 16-bit unsigned)
  logic signed [33:0] mult_result;
  logic signed [33:0] shifted_result;
  logic signed [15:0] sat_result;

  always_comb begin
    case (state_q)
      ST_CALC_X: begin
        mult_op_a = $signed(in_x_q) - $signed(offset_x_i);
        mult_op_b = $signed({1'b0, gain_x_i});
      end
      ST_CALC_Y: begin
        mult_op_a = $signed(in_y_q) - $signed(offset_y_i);
        mult_op_b = $signed({1'b0, gain_y_i});
      end
      ST_CALC_Z: begin
        mult_op_a = $signed(in_z_q) - $signed(offset_z_i);
        mult_op_b = $signed({1'b0, gain_z_i});
      end
      default: begin
        mult_op_a = '0;
        mult_op_b = '0;
      end
    endcase

    // Single time-shared multiplier
    mult_result    = mult_op_a * mult_op_b;
    shifted_result = mult_result >>> 14;

    // Symmetric saturation to 16-bit signed range [-32768, 32767]
    if (shifted_result > 34'sd32767) begin
      sat_result = 16'sd32767;
    end else if (shifted_result < -34'sd32768) begin
      sat_result = -16'sd32768;
    end else begin
      sat_result = shifted_result[15:0];
    end
  end

  // State sequencing
  always_comb begin
    state_d        = state_q;
    res_x_d        = res_x_q;
    res_y_d        = res_y_q;
    res_z_d        = res_z_q;
    sample_valid_o = 1'b0;

    if (!en_i) begin
      state_d = ST_IDLE;
    end else begin
      case (state_q)
        ST_IDLE: begin
          if (sample_valid_i) begin
            state_d = ST_CALC_X;
          end
        end

        ST_CALC_X: begin
          res_x_d = sat_result;
          state_d = ST_CALC_Y;
        end

        ST_CALC_Y: begin
          res_y_d = sat_result;
          state_d = ST_CALC_Z;
        end

        ST_CALC_Z: begin
          res_z_d = sat_result;
          state_d = ST_DONE;
        end

        ST_DONE: begin
          sample_valid_o = 1'b1;
          state_d        = ST_IDLE;
        end

        default: state_d = ST_IDLE;
      endcase
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q <= ST_IDLE;
      in_x_q  <= '0;
      in_y_q  <= '0;
      in_z_q  <= '0;
      res_x_q <= '0;
      res_y_q <= '0;
      res_z_q <= '0;
    end else begin
      state_q <= state_d;
      res_x_q <= res_x_d;
      res_y_q <= res_y_d;
      res_z_q <= res_z_d;

      if (state_q == ST_IDLE && sample_valid_i) begin
        in_x_q <= accel_x_i;
        in_y_q <= accel_y_i;
        in_z_q <= accel_z_i;
      end
    end
  end

  assign accel_x_o = res_x_q;
  assign accel_y_o = res_y_q;
  assign accel_z_o = res_z_q;

endmodule
