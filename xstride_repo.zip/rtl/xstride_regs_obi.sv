// =============================================================================
// xstride_regs_obi.sv
// X-STRIDE OBI Bus Register File with Dual-Bank Personalization & Statistics
//
// Compliant with standard OBI (Open Bus Interface) slave protocol.
//
// Architectural Invariants:
//   1. Two Configuration Banks in PD_AON:
//        - Pending bank: writable via OBI bus, protected by optional LOCK bit.
//        - Active bank:  applied atomically on sample_valid_i boundary via COMMIT bit.
//   2. Retained State:
//        - Active profile survives PD_DSP power-down in PD_AON.
//        - Step counters, shake events, and telemetry counters retained.
//   3. Hardware Mechanism, Software Policy:
//        - Comprehensive registers for thresholds, cadence, filter poles, calibration.
//        - Live hardware feature statistics tracking (min, max, peak avg, period avg, ZCR).
// =============================================================================

`timescale 1ns/1ps

import xstride_regs_pkg::*;

module xstride_regs_obi #(
  parameter logic [31:0] BASE_ADDR = 32'h0000_0000
) (
  input  logic clk_i,
  input  logic rst_ni,

  // ---- OBI slave port ----
  input  logic        req_i,
  output logic        gnt_o,
  input  logic [31:0] addr_i,
  input  logic        we_i,
  input  logic [3:0]  be_i,
  input  logic [31:0] wdata_i,
  output logic        rvalid_o,
  output logic [31:0] rdata_o,

  // ---- Sample Boundary Trigger for Atomic Commit ----
  input  logic        sample_valid_i,

  // ---- Wake FSM & DSP inputs ----
  input  logic [1:0]  fsm_state_i,
  input  logic        motion_detected_i,
  input  logic        feature_ready_i,
  input  logic [15:0] feat_magnitude_i,
  input  logic [15:0] feat_zcr_i,
  input  logic [15:0] feat_cadence_i,
  input  logic [7:0]  tinyml_class_i,

  // ---- Pedometer & Activity Classifier inputs ----
  input  logic [2:0]  activity_class_i,
  input  logic [31:0] step_count_total_i,
  input  logic [31:0] step_count_walk_i,
  input  logic [31:0] step_count_run_i,
  input  logic [31:0] shake_event_count_i,
  input  logic [31:0] shake_duration_sec_i,
  input  logic [15:0] cadence_spm_i,

  // ---- Raw Sensor & Mobile Telemetry inputs ----
  input  logic signed [15:0] accel_x_i,
  input  logic signed [15:0] accel_y_i,
  input  logic signed [15:0] accel_z_i,
  input  logic [7:0]         fifo_count_i,
  input  logic               fifo_empty_i,
  input  logic               fifo_full_i,
  input  logic [31:0]        fifo_rdata_i,

  // ---- Statistics Block Inputs ----
  input  logic [15:0]        stat_mag_min_i,
  input  logic [15:0]        stat_mag_max_i,
  input  logic [15:0]        stat_peak_avg_i,
  input  logic [15:0]        stat_period_avg_i,
  input  logic [15:0]        stat_zcr_max_i,

  // ---- Control outputs ----
  output logic        core_ack_o,
  output logic        ctrl_soft_en_o,
  output logic        shake_filter_en_o,
  output logic [1:0]  sensor_sel_o,
  output logic        self_test_en_o,
  output logic [1:0]  range_sel_o,
  output logic [15:0] step_threshold_o,
  output logic        fifo_pop_o,

  // ---- Statistics Block Controls ----
  output logic        stat_enable_o,
  output logic        stat_clear_o,

  // ---- Active Configuration Output Bus to Top/DSP/Classifier/AFE ----
  output xstride_cfg_t cfg_act_o
);

  logic [31:0] word_off;
  assign word_off = addr_i - BASE_ADDR;

  // ---------------------------------------------------------------------------
  // Base Control Registers
  // ---------------------------------------------------------------------------
  logic        ctrl_soft_en_q;
  logic        shake_filter_en_q;
  logic [1:0]  sensor_sel_q;
  logic        self_test_en_q;
  logic [1:0]  range_sel_q;
  logic        feat_ready_sticky_q;
  logic [31:0] rdata_q;
  logic        rvalid_q;
  logic        core_ack_q;
  logic        fifo_pop_q;

  // ---------------------------------------------------------------------------
  // Pending Configuration Bank (Software writes staged here)
  // ---------------------------------------------------------------------------
  logic [15:0]        step_thresh_pend_q;
  logic [15:0]        run_thresh_pend_q;
  logic [15:0]        min_period_pend_q;
  logic [15:0]        max_period_pend_q;
  logic [7:0]         shake_zcr_th_pend_q;
  logic [7:0]         dom_ratio_q4_pend_q;
  logic [15:0]        dom_floor_pend_q;
  logic [3:0]         lock_count_pend_q;
  logic [7:0]         iir_shift_pend_q;
  logic [15:0]        wake_thresh_pend_q;
  logic [15:0]        window_len_pend_q;
  logic [15:0]        odr_hz_pend_q;
  logic [15:0]        cadence_num_pend_q;
  logic [15:0]        gain_x_pend_q;
  logic [15:0]        gain_y_pend_q;
  logic [15:0]        gain_z_pend_q;
  logic signed [15:0] offset_x_pend_q;
  logic signed [15:0] offset_y_pend_q;
  logic signed [15:0] offset_z_pend_q;
  logic [15:0]        profile_version_pend_q;

  // Profile control flags
  logic commit_req_q;
  logic cfg_locked_q;
  logic profile_applied_q;
  logic range_error_q;

  // Statistics controls
  logic stat_enable_q;
  logic stat_clear_q;

  // ---------------------------------------------------------------------------
  // Active Configuration Bank (Retained in PD_AON; drives hardware)
  // ---------------------------------------------------------------------------
  xstride_cfg_t cfg_act_q;

  assign gnt_o             = req_i;
  assign rvalid_o          = rvalid_q;
  assign rdata_o           = rdata_q;
  assign core_ack_o        = core_ack_q;
  assign ctrl_soft_en_o    = ctrl_soft_en_q;
  assign shake_filter_en_o = shake_filter_en_q;
  assign sensor_sel_o      = sensor_sel_q;
  assign self_test_en_o    = self_test_en_q;
  assign range_sel_o       = range_sel_q;
  assign step_threshold_o  = cfg_act_q.step_thresh;
  assign fifo_pop_o        = fifo_pop_q;

  assign stat_enable_o     = stat_enable_q;
  assign stat_clear_o      = stat_clear_q;

  assign cfg_act_o         = cfg_act_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      ctrl_soft_en_q         <= 1'b1;   // default enabled
      shake_filter_en_q      <= 1'b1;   // default leg shaking filter enabled
      sensor_sel_q           <= 2'b00;  // default SPI
      self_test_en_q         <= 1'b0;
      range_sel_q            <= 2'b00;  // +/- 2g
      feat_ready_sticky_q    <= 1'b0;
      rdata_q                <= 32'h0;
      rvalid_q               <= 1'b0;
      core_ack_q             <= 1'b0;
      fifo_pop_q             <= 1'b0;

      // Pending Bank Defaults
      step_thresh_pend_q     <= DEFAULT_STEP_THRESH;
      run_thresh_pend_q      <= DEFAULT_RUN_THRESH;
      min_period_pend_q      <= DEFAULT_MIN_PERIOD;
      max_period_pend_q      <= DEFAULT_MAX_PERIOD;
      shake_zcr_th_pend_q    <= DEFAULT_SHAKE_ZCR_TH;
      dom_ratio_q4_pend_q    <= DEFAULT_DOM_RATIO_Q4;
      dom_floor_pend_q       <= DEFAULT_DOM_FLOOR;
      lock_count_pend_q      <= DEFAULT_LOCK_COUNT;
      iir_shift_pend_q       <= DEFAULT_IIR_SHIFT;
      wake_thresh_pend_q     <= DEFAULT_WAKE_THRESH;
      window_len_pend_q      <= DEFAULT_WINDOW_LEN;
      odr_hz_pend_q          <= DEFAULT_ODR_HZ;
      cadence_num_pend_q     <= DEFAULT_CADENCE_NUM;
      gain_x_pend_q          <= DEFAULT_GAIN_X;
      gain_y_pend_q          <= DEFAULT_GAIN_Y;
      gain_z_pend_q          <= DEFAULT_GAIN_Z;
      offset_x_pend_q        <= DEFAULT_OFFSET_X;
      offset_y_pend_q        <= DEFAULT_OFFSET_Y;
      offset_z_pend_q        <= DEFAULT_OFFSET_Z;
      profile_version_pend_q <= DEFAULT_PROFILE_VERSION;

      commit_req_q           <= 1'b0;
      cfg_locked_q           <= 1'b0;
      profile_applied_q      <= 1'b1; // Default profile loaded out of reset
      range_error_q          <= 1'b0;

      stat_enable_q          <= 1'b0;
      stat_clear_q           <= 1'b0;

      // Active Bank Default Initialisation
      cfg_act_q              <= DEFAULT_CFG;

    end else begin
      rvalid_q     <= req_i;
      core_ack_q   <= 1'b0;
      fifo_pop_q   <= 1'b0;
      stat_clear_q <= 1'b0;

      if (feature_ready_i) feat_ready_sticky_q <= 1'b1;

      // -----------------------------------------------------------------------
      // Atomic Commit Synchronization (Executes on sample_valid_i boundary)
      // -----------------------------------------------------------------------
      if (commit_req_q && sample_valid_i) begin
        // Range validation checks
        if ((min_period_pend_q <= max_period_pend_q) &&
            (min_period_pend_q >= 16'd4) &&
            (window_len_pend_q >= 16'd16) &&
            (lock_count_pend_q >= 4'd1 && lock_count_pend_q <= 4'd7) &&
            (iir_shift_pend_q >= 8'd1 && iir_shift_pend_q <= 8'd5)) begin

          cfg_act_q.step_thresh     <= step_thresh_pend_q;
          cfg_act_q.run_thresh      <= run_thresh_pend_q;
          cfg_act_q.min_period      <= min_period_pend_q;
          cfg_act_q.max_period      <= max_period_pend_q;
          cfg_act_q.shake_zcr_th    <= shake_zcr_th_pend_q;
          cfg_act_q.dom_ratio_q4    <= dom_ratio_q4_pend_q;
          cfg_act_q.dom_floor       <= dom_floor_pend_q;
          cfg_act_q.lock_count      <= lock_count_pend_q;
          cfg_act_q.iir_shift       <= iir_shift_pend_q;
          cfg_act_q.wake_thresh     <= wake_thresh_pend_q;
          cfg_act_q.window_len      <= window_len_pend_q;
          cfg_act_q.odr_hz          <= odr_hz_pend_q;
          cfg_act_q.cadence_num     <= cadence_num_pend_q;
          cfg_act_q.gain_x          <= gain_x_pend_q;
          cfg_act_q.gain_y          <= gain_y_pend_q;
          cfg_act_q.gain_z          <= gain_z_pend_q;
          cfg_act_q.offset_x        <= offset_x_pend_q;
          cfg_act_q.offset_y        <= offset_y_pend_q;
          cfg_act_q.offset_z        <= offset_z_pend_q;
          cfg_act_q.profile_version <= profile_version_pend_q;

          commit_req_q      <= 1'b0;
          profile_applied_q <= 1'b1;
          range_error_q     <= 1'b0;
        end else begin
          // Range check failed: reject commit, preserve previous active profile
          commit_req_q      <= 1'b0;
          range_error_q     <= 1'b1;
        end
      end

      // -----------------------------------------------------------------------
      // Register Writes (Staged to Pending Bank unless cfg_locked_q)
      // -----------------------------------------------------------------------
      if (req_i && we_i) begin
        case (word_off)
          OFF_CTRL: begin
            if (be_i[0]) ctrl_soft_en_q    <= wdata_i[0];
            if (be_i[0]) shake_filter_en_q <= wdata_i[1];
            if (be_i[0]) sensor_sel_q      <= wdata_i[3:2];
          end
          OFF_IRQ_ACK: begin
            core_ack_q <= 1'b1;
          end
          OFF_SENSOR_CTRL: begin
            if (be_i[0]) sensor_sel_q   <= wdata_i[1:0];
            if (be_i[0]) self_test_en_q <= wdata_i[2];
            if (be_i[0]) range_sel_q    <= wdata_i[4:3];
          end
          OFF_STEP_THRESHOLD: begin
            if (!cfg_locked_q) begin
              if (be_i[0]) step_thresh_pend_q[7:0]  <= wdata_i[7:0];
              if (be_i[1]) step_thresh_pend_q[15:8] <= wdata_i[15:8];
            end
          end
          OFF_RUN_THRESHOLD: begin
            if (!cfg_locked_q) begin
              if (be_i[0]) run_thresh_pend_q[7:0]   <= wdata_i[7:0];
              if (be_i[1]) run_thresh_pend_q[15:8]  <= wdata_i[15:8];
            end
          end
          OFF_PERIOD_CFG: begin
            if (!cfg_locked_q) begin
              if (be_i[0]) min_period_pend_q[7:0]   <= wdata_i[7:0];
              if (be_i[1]) min_period_pend_q[15:8]  <= wdata_i[15:8];
              if (be_i[2]) max_period_pend_q[7:0]   <= wdata_i[23:16];
              if (be_i[3]) max_period_pend_q[15:8]  <= wdata_i[31:24];
            end
          end
          OFF_SHAKE_CFG: begin
            if (!cfg_locked_q) begin
              if (be_i[0]) shake_zcr_th_pend_q      <= wdata_i[7:0];
              if (be_i[1]) dom_ratio_q4_pend_q      <= wdata_i[15:8];
              if (be_i[2]) dom_floor_pend_q[7:0]    <= wdata_i[23:16];
              if (be_i[3]) dom_floor_pend_q[15:8]   <= wdata_i[31:24];
            end
          end
          OFF_LOCK_CFG: begin
            if (!cfg_locked_q) begin
              if (be_i[0]) lock_count_pend_q        <= wdata_i[3:0];
              if (be_i[1]) iir_shift_pend_q         <= wdata_i[15:8];
            end
          end
          OFF_WAKE_CFG: begin
            if (!cfg_locked_q) begin
              if (be_i[0]) wake_thresh_pend_q[7:0]  <= wdata_i[7:0];
              if (be_i[1]) wake_thresh_pend_q[15:8] <= wdata_i[15:8];
              if (be_i[2]) window_len_pend_q[7:0]   <= wdata_i[23:16];
              if (be_i[3]) window_len_pend_q[15:8]  <= wdata_i[31:24];
            end
          end
          OFF_ODR_CFG: begin
            if (!cfg_locked_q) begin
              if (be_i[0]) odr_hz_pend_q[7:0]       <= wdata_i[7:0];
              if (be_i[1]) odr_hz_pend_q[15:8]      <= wdata_i[15:8];
              if (be_i[2]) cadence_num_pend_q[7:0]  <= wdata_i[23:16];
              if (be_i[3]) cadence_num_pend_q[15:8] <= wdata_i[31:24];
            end
          end
          OFF_GAIN_XY: begin
            if (!cfg_locked_q) begin
              if (be_i[0]) gain_x_pend_q[7:0]       <= wdata_i[7:0];
              if (be_i[1]) gain_x_pend_q[15:8]      <= wdata_i[15:8];
              if (be_i[2]) gain_y_pend_q[7:0]       <= wdata_i[23:16];
              if (be_i[3]) gain_y_pend_q[15:8]      <= wdata_i[31:24];
            end
          end
          OFF_GAIN_Z: begin
            if (!cfg_locked_q) begin
              if (be_i[0]) gain_z_pend_q[7:0]       <= wdata_i[7:0];
              if (be_i[1]) gain_z_pend_q[15:8]      <= wdata_i[15:8];
            end
          end
          OFF_OFFSET_XY: begin
            if (!cfg_locked_q) begin
              if (be_i[0]) offset_x_pend_q[7:0]     <= wdata_i[7:0];
              if (be_i[1]) offset_x_pend_q[15:8]    <= wdata_i[15:8];
              if (be_i[2]) offset_y_pend_q[7:0]     <= wdata_i[23:16];
              if (be_i[3]) offset_y_pend_q[15:8]    <= wdata_i[31:24];
            end
          end
          OFF_OFFSET_Z: begin
            if (!cfg_locked_q) begin
              if (be_i[0]) offset_z_pend_q[7:0]     <= wdata_i[7:0];
              if (be_i[1]) offset_z_pend_q[15:8]    <= wdata_i[15:8];
            end
          end
          OFF_PROFILE_CTRL: begin
            if (be_i[0]) begin
              if (wdata_i[0]) commit_req_q <= 1'b1;
              if (wdata_i[1]) begin
                // Reload defaults into pending bank
                step_thresh_pend_q     <= DEFAULT_STEP_THRESH;
                run_thresh_pend_q      <= DEFAULT_RUN_THRESH;
                min_period_pend_q      <= DEFAULT_MIN_PERIOD;
                max_period_pend_q      <= DEFAULT_MAX_PERIOD;
                shake_zcr_th_pend_q    <= DEFAULT_SHAKE_ZCR_TH;
                dom_ratio_q4_pend_q    <= DEFAULT_DOM_RATIO_Q4;
                dom_floor_pend_q       <= DEFAULT_DOM_FLOOR;
                lock_count_pend_q      <= DEFAULT_LOCK_COUNT;
                iir_shift_pend_q       <= DEFAULT_IIR_SHIFT;
                wake_thresh_pend_q     <= DEFAULT_WAKE_THRESH;
                window_len_pend_q      <= DEFAULT_WINDOW_LEN;
                odr_hz_pend_q          <= DEFAULT_ODR_HZ;
                cadence_num_pend_q     <= DEFAULT_CADENCE_NUM;
                gain_x_pend_q          <= DEFAULT_GAIN_X;
                gain_y_pend_q          <= DEFAULT_GAIN_Y;
                gain_z_pend_q          <= DEFAULT_GAIN_Z;
                offset_x_pend_q        <= DEFAULT_OFFSET_X;
                offset_y_pend_q        <= DEFAULT_OFFSET_Y;
                offset_z_pend_q        <= DEFAULT_OFFSET_Z;
                profile_version_pend_q <= DEFAULT_PROFILE_VERSION;
              end
              if (wdata_i[2]) cfg_locked_q <= 1'b1;
            end
            if (!cfg_locked_q) begin
              if (be_i[2]) profile_version_pend_q[7:0]  <= wdata_i[23:16];
              if (be_i[3]) profile_version_pend_q[15:8] <= wdata_i[31:24];
            end
          end
          OFF_STAT_CTRL: begin
            if (be_i[0]) stat_enable_q <= wdata_i[0];
            if (be_i[0] && wdata_i[1]) stat_clear_q <= 1'b1;
          end
          default: ;
        endcase
      end

      // -----------------------------------------------------------------------
      // Register Reads
      // -----------------------------------------------------------------------
      if (req_i && !we_i) begin
        case (word_off)
          OFF_CTRL:          rdata_q <= {28'b0, sensor_sel_q, shake_filter_en_q, ctrl_soft_en_q};
          OFF_STATUS: begin
            rdata_q <= {25'b0, activity_class_i, feat_ready_sticky_q, motion_detected_i, fsm_state_i};
            feat_ready_sticky_q <= 1'b0; // clear on read
          end
          OFF_FEAT_MAGNITUDE:  rdata_q <= {16'b0, feat_magnitude_i};
          OFF_FEAT_ZCR:        rdata_q <= {16'b0, feat_zcr_i};
          OFF_FEAT_CADENCE:    rdata_q <= {16'b0, feat_cadence_i};
          OFF_TINYML_CLASS:    rdata_q <= (tinyml_class_i != '0) ? {24'b0, tinyml_class_i} : {29'b0, activity_class_i};
          OFF_TOTAL_STEPS:     rdata_q <= step_count_total_i;
          OFF_WALK_STEPS:      rdata_q <= step_count_walk_i;
          OFF_RUN_STEPS:       rdata_q <= step_count_run_i;
          OFF_SHAKE_EVENTS:    rdata_q <= shake_event_count_i;
          OFF_SHAKE_DURATION:  rdata_q <= shake_duration_sec_i;
          OFF_CADENCE_SPM:     rdata_q <= {16'b0, cadence_spm_i};
          OFF_SENSOR_CTRL:     rdata_q <= {27'b0, range_sel_q, self_test_en_q, sensor_sel_q};
          OFF_RAW_ACCEL_XY:    rdata_q <= {accel_x_i, accel_y_i};
          OFF_RAW_ACCEL_Z:     rdata_q <= {16'b0, accel_z_i};
          OFF_MOBILE_STATUS:   rdata_q <= {22'b0, fifo_full_i, fifo_empty_i, fifo_count_i};
          OFF_MOBILE_FIFO_DATA: begin
            rdata_q    <= fifo_rdata_i;
            fifo_pop_q <= 1'b1;
          end
          // Config Readbacks (Pending bank readback)
          OFF_STEP_THRESHOLD:  rdata_q <= {16'b0, step_thresh_pend_q};
          OFF_RUN_THRESHOLD: rdata_q <= {16'b0, run_thresh_pend_q};
          OFF_PERIOD_CFG:    rdata_q <= {max_period_pend_q, min_period_pend_q};
          OFF_SHAKE_CFG:     rdata_q <= {dom_floor_pend_q, dom_ratio_q4_pend_q, shake_zcr_th_pend_q};
          OFF_LOCK_CFG:      rdata_q <= {16'b0, iir_shift_pend_q, 4'b0, lock_count_pend_q};
          OFF_WAKE_CFG:      rdata_q <= {window_len_pend_q, wake_thresh_pend_q};
          OFF_ODR_CFG:       rdata_q <= {cadence_num_pend_q, odr_hz_pend_q};
          OFF_GAIN_XY:       rdata_q <= {gain_y_pend_q, gain_x_pend_q};
          OFF_GAIN_Z:        rdata_q <= {16'b0, gain_z_pend_q};
          OFF_OFFSET_XY:     rdata_q <= {offset_y_pend_q, offset_x_pend_q};
          OFF_OFFSET_Z:      rdata_q <= {16'b0, offset_z_pend_q};
          OFF_PROFILE_CTRL:  rdata_q <= {profile_version_pend_q, 13'b0, cfg_locked_q, 2'b0};
          OFF_PROFILE_STATUS:rdata_q <= {cfg_act_q.profile_version, 13'b0, range_error_q, profile_applied_q, commit_req_q};
          // Hardware Feature Statistics Readbacks
          OFF_STAT_CTRL:     rdata_q <= {30'b0, stat_clear_q, stat_enable_q};
          OFF_STAT_MAG_MIN:  rdata_q <= {16'b0, stat_mag_min_i};
          OFF_STAT_MAG_MAX:  rdata_q <= {16'b0, stat_mag_max_i};
          OFF_STAT_PEAK_AVG: rdata_q <= {16'b0, stat_peak_avg_i};
          OFF_STAT_PERIOD_AVG:rdata_q<= {16'b0, stat_period_avg_i};
          OFF_STAT_ZCR_MAX:  rdata_q <= {16'b0, stat_zcr_max_i};

          default:           rdata_q <= 32'hDEAD_BEEF;
        endcase
      end
    end
  end

endmodule
