// =============================================================================
// wake_fsm.sv
// X-STRIDE Always-On Multi-Tier Wake & Power Controller
//
// States: SLEEP -> IDLE -> ACTIVE -> CORE_SYNC
//   SLEEP     : Ultra-low power (~15uW). Only sensor wake comparator active.
//   IDLE      : Sensor + DSP/Pedometer powered, verifying sustained rhythm.
//   ACTIVE    : Full tracking active: classifying walk vs run vs leg-shake.
//   CORE_SYNC : Core domain powered, IRQ asserted for host sync / telemetry.
// =============================================================================

`timescale 1ns/1ps

module wake_fsm #(
  parameter int unsigned MOTION_TIMEOUT_CYCLES = 32'd50_000,  // IDLE->SLEEP timeout
  parameter int unsigned SYNC_TIMEOUT_CYCLES   = 32'd64       // CORE_SYNC safety timeout
) (
  input  logic clk_i,
  input  logic rst_ni,

  // Wake triggers
  input  logic motion_detected_i,   // magnitude crossed wake threshold
  input  logic feature_ready_i,     // one-cycle pulse: feature window complete
  input  logic mobile_wake_i,       // mobile app request wake

  // Core handshake
  input  logic core_ack_i,          // core writes IRQ_ACK to clear
  output logic core_irq_o,          // level IRQ held through CORE_SYNC

  // Multi-tier power-gating enables (active-high = domain powered)
  output logic pg_accel_en_o,
  output logic pg_dsp_en_o,
  output logic pg_telemetry_en_o,
  output logic pg_core_domain_en_o,

  // Debug / register readback
  output logic [1:0] state_o
);

  typedef enum logic [1:0] {
    SLEEP     = 2'b00,
    IDLE      = 2'b01,
    ACTIVE    = 2'b10,
    CORE_SYNC = 2'b11
  } state_e;

  state_e      state_q, state_d;
  logic [31:0] idle_timer_q, idle_timer_d;
  logic [31:0] sync_timer_q, sync_timer_d;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q      <= SLEEP;
      idle_timer_q <= '0;
      sync_timer_q <= '0;
    end else begin
      state_q      <= state_d;
      idle_timer_q <= idle_timer_d;
      sync_timer_q <= sync_timer_d;
    end
  end

  always_comb begin
    state_d              = state_q;
    idle_timer_d         = idle_timer_q;
    sync_timer_d         = sync_timer_q;
    pg_accel_en_o        = 1'b0;
    pg_dsp_en_o          = 1'b0;
    pg_telemetry_en_o    = 1'b0;
    pg_core_domain_en_o  = 1'b0;
    core_irq_o           = 1'b0;

    case (state_q)
      SLEEP: begin
        pg_accel_en_o = 1'b1; // keep wake-comparator alive
        idle_timer_d  = '0;
        if (motion_detected_i || mobile_wake_i) begin
          state_d = IDLE;
        end
      end

      IDLE: begin
        pg_accel_en_o     = 1'b1;
        pg_dsp_en_o       = 1'b1;
        pg_telemetry_en_o = 1'b1;
        if (motion_detected_i) begin
          idle_timer_d = '0;
          state_d      = ACTIVE;
        end else if (idle_timer_q >= MOTION_TIMEOUT_CYCLES) begin
          state_d = SLEEP;
        end else begin
          idle_timer_d = idle_timer_q + 32'd1;
        end
      end

      ACTIVE: begin
        pg_accel_en_o     = 1'b1;
        pg_dsp_en_o       = 1'b1;
        pg_telemetry_en_o = 1'b1;
        idle_timer_d      = '0;
        if (feature_ready_i) begin
          sync_timer_d = '0;
          state_d      = CORE_SYNC;
        end
      end

      CORE_SYNC: begin
        pg_accel_en_o       = 1'b1;
        pg_dsp_en_o         = 1'b1;
        pg_telemetry_en_o   = 1'b1;
        pg_core_domain_en_o = 1'b1;
        core_irq_o          = 1'b1;
        if (core_ack_i) begin
          state_d = ACTIVE;
        end else if (sync_timer_q >= SYNC_TIMEOUT_CYCLES) begin
          state_d = ACTIVE;
        end else begin
          sync_timer_d = sync_timer_q + 32'd1;
        end
      end

      default: state_d = SLEEP;
    endcase
  end

  assign state_o = state_q;

endmodule
