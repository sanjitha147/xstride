// =============================================================================
// xstride_sva.sv
// SystemVerilog Formal Assertions (SVA) for X-STRIDE Pedometer SoC Subsystem
//
// Dual-mode architecture:
//   1. IEEE-1800 Concurrent Assertions for formal property verification (FPV)
//      and commercial simulators (Synopsys VCS, Cadence Jasper/Xcelium, Questa).
//   2. Runtime Immediate Assertions & Invariant Monitors for open-source simulators
//      (Icarus Verilog, Verilator) providing active dynamic verification.
//
// Formally verifies critical safety, low-power isolation, and classification rules:
//   1. Zero false steps during confirmed Leg Shaking episodes.
//   2. Strict mutual exclusion of sensor master enables (no bus contention).
//   3. Power domain output isolation clamping when domains are gated off.
//   4. UART TX Clamping on Telemetry Power-Down (safe Mark/idle state).
//   5. Chip Select deassertion when SPI is disabled.
//   6. I2C Tristate (oe==0) when I2C is disabled.
// =============================================================================

`timescale 1ns/1ps

module xstride_sva (
  input logic        clk_i,
  input logic        rst_ni,

  // Power gating controls
  input logic        pg_accel_en_i,
  input logic        pg_dsp_en_i,
  input logic        pg_telemetry_en_i,

  // Mutually gated sensor enables
  input logic        spi_en_i,
  input logic        i2c_en_i,
  input logic        onchip_en_i,

  // Sensor isolation signals
  input logic        spi_cs_no,
  input logic        i2c_scl_oe,
  input logic        i2c_sda_oe,

  // DSP & Classifier outputs
  input logic [2:0]  activity_class_i,
  input logic        step_detected_i,
  input logic        shake_detected_i,
  input logic [15:0] feat_magnitude_iso_i,
  input logic [2:0]  activity_class_iso_i,

  // Telemetry outputs
  input logic        uart_tx_i,
  input logic        fifo_empty_iso_i
);

  // Active assertion monitoring counters
  int unsigned sva_cycles_monitored = 0;
  int unsigned sva_violations       = 0;
  int unsigned checks_rule1         = 0;
  int unsigned checks_rule2         = 0;
  int unsigned checks_rule3         = 0;
  int unsigned checks_rule4         = 0;
  int unsigned checks_rule5         = 0;
  int unsigned checks_rule6         = 0;

  // ---------------------------------------------------------------------------
  // Runtime Dynamic Assertion Engine (Active in all simulators)
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      // Hold during reset
    end else begin
      sva_cycles_monitored <= sva_cycles_monitored + 1;

      // -----------------------------------------------------------------------
      // Rule 1: No False Steps During Leg Shaking (Golden Rule)
      // -----------------------------------------------------------------------
      if (activity_class_i == 3'd1) begin
        checks_rule1 <= checks_rule1 + 1;
        if (step_detected_i) begin
          $display("[SVA VIOLATION] Rule 1 FAILED @ t=%0t: False step asserted during ACT_LEG_SHAKE!", $time);
          sva_violations <= sva_violations + 1;
        end
      end

      // -----------------------------------------------------------------------
      // Rule 2: Strict Mutual Exclusion of Sensor Master Interfaces
      // -----------------------------------------------------------------------
      checks_rule2 <= checks_rule2 + 1;
      if (spi_en_i && i2c_en_i) begin
        $display("[SVA VIOLATION] Rule 2 FAILED @ t=%0t: SPI and I2C simultaneously enabled!", $time);
        sva_violations <= sva_violations + 1;
      end
      if (spi_en_i && onchip_en_i) begin
        $display("[SVA VIOLATION] Rule 2 FAILED @ t=%0t: SPI and On-Chip simultaneously enabled!", $time);
        sva_violations <= sva_violations + 1;
      end
      if (i2c_en_i && onchip_en_i) begin
        $display("[SVA VIOLATION] Rule 2 FAILED @ t=%0t: I2C and On-Chip simultaneously enabled!", $time);
        sva_violations <= sva_violations + 1;
      end

      // -----------------------------------------------------------------------
      // Rule 3: Isolation Clamping on Inactive DSP Domain
      // -----------------------------------------------------------------------
      if (!pg_dsp_en_i) begin
        checks_rule3 <= checks_rule3 + 1;
        if (feat_magnitude_iso_i != 16'h0000 || activity_class_iso_i != 3'b000) begin
          $display("[SVA VIOLATION] Rule 3 FAILED @ t=%0t: Floating DSP signal reached AON without clamp!", $time);
          sva_violations <= sva_violations + 1;
        end
      end

      // -----------------------------------------------------------------------
      // Rule 4: UART TX Clamping on Telemetry Power-Down
      // -----------------------------------------------------------------------
      if (!pg_telemetry_en_i) begin
        checks_rule4 <= checks_rule4 + 1;
        if (uart_tx_i != 1'b1 || fifo_empty_iso_i != 1'b1) begin
          $display("[SVA VIOLATION] Rule 4 FAILED @ t=%0t: UART TX not clamped high during power-down!", $time);
          sva_violations <= sva_violations + 1;
        end
      end

      // -----------------------------------------------------------------------
      // Rule 5: Chip Select Deassertion when SPI is Disabled
      // -----------------------------------------------------------------------
      if (!spi_en_i) begin
        checks_rule5 <= checks_rule5 + 1;
        if (spi_cs_no != 1'b1) begin
          $display("[SVA VIOLATION] Rule 5 FAILED @ t=%0t: SPI CS asserted low while disabled!", $time);
          sva_violations <= sva_violations + 1;
        end
      end

      // -----------------------------------------------------------------------
      // Rule 6: I2C Tristate when I2C is Disabled
      // -----------------------------------------------------------------------
      if (!i2c_en_i) begin
        checks_rule6 <= checks_rule6 + 1;
        if (i2c_scl_oe != 1'b0 || i2c_sda_oe != 1'b0) begin
          $display("[SVA VIOLATION] Rule 6 FAILED @ t=%0t: I2C OE active while disabled!", $time);
          sva_violations <= sva_violations + 1;
        end
      end
    end
  end

`ifndef __ICARUS__
  // ---------------------------------------------------------------------------
  // Concurrent Assertions for Commercial Formal & Simulation Engines
  // ---------------------------------------------------------------------------
  property p_no_steps_on_leg_shake;
    @(posedge clk_i) disable iff (!rst_ni)
    (activity_class_i == 3'd1) |-> (!step_detected_i);
  endproperty
  assert_no_steps_on_leg_shake: assert property (p_no_steps_on_leg_shake)
    else $error("[SVA VIOLATION] False step asserted during Leg Shaking!");

  property p_mutual_sensor_enable;
    @(posedge clk_i) disable iff (!rst_ni)
    !(spi_en_i && i2c_en_i);
  endproperty
  assert_mutual_sensor_enable: assert property (p_mutual_sensor_enable)
    else $error("[SVA VIOLATION] SPI and I2C masters simultaneously enabled!");

  property p_dsp_isolation_clamp;
    @(posedge clk_i) disable iff (!rst_ni)
    (!pg_dsp_en_i) |-> (feat_magnitude_iso_i == 16'h0000 && activity_class_iso_i == 3'b000);
  endproperty
  assert_dsp_isolation_clamp: assert property (p_dsp_isolation_clamp)
    else $error("[SVA VIOLATION] Floating DSP signal reached Always-On domain without clamping!");

  property p_telem_isolation_clamp;
    @(posedge clk_i) disable iff (!rst_ni)
    (!pg_telemetry_en_i) |-> (uart_tx_i == 1'b1 && fifo_empty_iso_i == 1'b1);
  endproperty
  assert_telem_isolation_clamp: assert property (p_telem_isolation_clamp)
    else $error("[SVA VIOLATION] UART TX did not clamp HIGH when Telemetry was power-gated!");

  property p_spi_cs_inactive;
    @(posedge clk_i) disable iff (!rst_ni)
    (!spi_en_i) |-> (spi_cs_no == 1'b1);
  endproperty
  assert_spi_cs_inactive: assert property (p_spi_cs_inactive)
    else $error("[SVA VIOLATION] SPI CS asserted low while SPI interface was disabled!");

  property p_i2c_oe_inactive;
    @(posedge clk_i) disable iff (!rst_ni)
    (!i2c_en_i) |-> (i2c_scl_oe == 1'b0 && i2c_sda_oe == 1'b0);
  endproperty
  assert_i2c_oe_inactive: assert property (p_i2c_oe_inactive)
    else $error("[SVA VIOLATION] I2C output enables active while I2C interface was disabled!");
`endif

  // Printable SVA verification summary task
  task automatic report_sva_status();
    $display("\n========================================================");
    $display(" SVA ASSERTION & PROTOCOL INVARIANT VERIFICATION REPORT");
    $display("========================================================");
    $display("  * Rule 1 (Leg Shake Step Lockout):   %6d checks [PASS]", checks_rule1);
    $display("  * Rule 2 (Sensor Mutual Exclusion):  %6d checks [PASS]", checks_rule2);
    $display("  * Rule 3 (DSP Isolation Clamping):   %6d checks [PASS]", checks_rule3);
    $display("  * Rule 4 (UART TX Mark Clamping):    %6d checks [PASS]", checks_rule4);
    $display("  * Rule 5 (SPI CS Inactive Clamping): %6d checks [PASS]", checks_rule5);
    $display("  * Rule 6 (I2C OE Tristate Inactive): %6d checks [PASS]", checks_rule6);
    $display("  ------------------------------------------------------");
    $display("  TOTAL SVA CYCLES MONITORED: %0d", sva_cycles_monitored);
    if (sva_violations == 0) begin
      $display("  RESULT: ALL SVA ASSERTIONS PASSED (0 VIOLATIONS)!");
    end else begin
      $display("  RESULT: %0d SVA ASSERTION VIOLATIONS DETECTED!", sva_violations);
    end
    $display("========================================================\n");
  endtask

endmodule
