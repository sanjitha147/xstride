// =============================================================================
// sync_2ff.sv
// X-STRIDE Parameterized 2-Stage Metastability Synchronizer
//
// Synchronizes asynchronous external signals (SPI MISO, I2C SDA, UART RX,
// Mobile Wake, OBI control inputs) into the local clock domain.
// Marked with async_reg attributes for ASIC / FPGA synthesis synthesis tools.
// =============================================================================

`timescale 1ns/1ps

module sync_2ff #(
  parameter int unsigned WIDTH     = 1,
  parameter logic [WIDTH-1:0] RESET_VAL = '0
) (
  input  logic             clk_i,
  input  logic             rst_ni,
  input  logic [WIDTH-1:0] d_async_i,
  output logic [WIDTH-1:0] q_sync_o
);

  (* async_reg = "true" *) logic [WIDTH-1:0] stage1_q;
  (* async_reg = "true" *) logic [WIDTH-1:0] stage2_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      stage1_q <= RESET_VAL;
      stage2_q <= RESET_VAL;
    end else begin
      stage1_q <= d_async_i;
      stage2_q <= stage1_q;
    end
  end

  assign q_sync_o = stage2_q;

endmodule
