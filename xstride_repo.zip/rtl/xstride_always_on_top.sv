// =============================================================================
// xstride_always_on_top.sv
// X-STRIDE Always-On Subsystem + Sensor Hub + Pedometer Engine + Mobile Telemetry
//
// Complete Headless Wearable SoC Subsystem:
//   - Asynchronous-Assert Synchronous-Deassert Reset Synchronizer (rst_sync)
//   - 2-Stage Metastability Synchronizers (sync_2ff) on all asynchronous inputs:
//       * mobile_wake_i, spi_miso_i, i2c_sda_i, uart_rx_i, and OBI bus inputs
//   - Strictly Mutually Exclusive Sensor Master Gating (SPI, I2C, On-Chip MEMS)
//   - Explicit Power Domain Partitioning & Active Output Isolation Clamping:
//       * PD_AON (Always-On): Reset sync, Input syncs, Wake FSM, OBI Regs,
//         and Non-Volatile/Retention Step & Activity Metric Accumulators
//       * PD_SENSOR (Switchable): SPI, I2C, On-chip MEMS AFE+ADC, Sensor Hub
//       * PD_DSP (Switchable): DSP magnitude/rate filters, Pedometer Classifier
//       * PD_TELEM (Switchable): BLE UART transceiver, FIFO, Frame Packetizer
//   - Integrated Mixed-Signal Capacitive MEMS AFE & 14-bit SAR ADC Macro
//   - Retention Registers surviving complete DSP / Telemetry Power-Down
//   - Compliant with IEEE 1801 Unified Power Format (UPF)
// =============================================================================

`timescale 1ns/1ps

import xstride_regs_pkg::*;

module xstride_always_on_top #(
  parameter logic [31:0] BASE_ADDR             = 32'h0000_0000,
  parameter int unsigned SPI_CLK_DIV           = 8,
  parameter int unsigned I2C_CLK_DIV           = 16,
  parameter int unsigned SAMPLE_PERIOD_CYCLES  = 32'd500_000,
  parameter int unsigned WINDOW_SAMPLES        = 128,
  parameter int unsigned MOTION_TIMEOUT_CYCLES = 32'd50_000,
  parameter bit          SYNC_OBI              = 1'b1,
  parameter int unsigned CLK_FREQ_HZ           = 50_000_000,
  parameter int unsigned BAUD_RATE             = 115200
) (
  input  logic clk_i,
  input  logic rst_ni,

  // External SPI to Accelerometer / IMU (PD_SENSOR)
  output logic spi_sclk_o,
  output logic spi_cs_no,
  output logic spi_mosi_o,
  input  logic spi_miso_i,

  // External I2C to Accelerometer / IMU (PD_SENSOR)
  output logic i2c_scl_o,
  output logic i2c_scl_oe,
  output logic i2c_sda_o,
  output logic i2c_sda_oe,
  input  logic i2c_sda_i,

  // Mobile App BLE / UART Interface (PD_TELEM / PD_AON)
  output logic uart_tx_o,
  input  logic uart_rx_i,
  output logic mobile_wake_o,
  input  logic mobile_wake_i,

  // Integrated On-Chip MEMS Differential Capacitive Sense Inputs (PD_SENSOR)
  input  logic signed [15:0] mems_analog_x_i,
  input  logic signed [15:0] mems_analog_y_i,
  input  logic signed [15:0] mems_analog_z_i,

  // OBI slave port (connect to Core / Interconnect - PD_AON)
  input  logic         obi_req_i,
  output logic         obi_gnt_o,
  input  logic [31:0]  obi_addr_i,
  input  logic         obi_we_i,
  input  logic [3:0]   obi_be_i,
  input  logic [31:0]  obi_wdata_i,
  output logic         obi_rvalid_o,
  output logic [31:0]  obi_rdata_o,

  // Core Wake IRQ (PD_AON)
  output logic core_irq_o
);

  // ===========================================================================
  // 1. Reset Synchronizer (PD_AON)
  // Ensures clean synchronous release to eliminate metastability / removal hazards.
  // ===========================================================================
  logic rst_n_sync;

  rst_sync u_rst_sync (
    .clk_i        (clk_i),
    .rst_ni       (rst_ni),
    .rst_n_sync_o (rst_n_sync)
  );

  // ===========================================================================
  // 2. 2-Stage Metastability Synchronizers on Asynchronous Inputs (PD_AON)
  // ===========================================================================
  logic mobile_wake_sync;
  sync_2ff #(
    .WIDTH     (1),
    .RESET_VAL (1'b0)
  ) u_sync_mobile_wake (
    .clk_i     (clk_i),
    .rst_ni    (rst_n_sync),
    .d_async_i (mobile_wake_i),
    .q_sync_o  (mobile_wake_sync)
  );

  logic spi_miso_sync;
  sync_2ff #(
    .WIDTH     (1),
    .RESET_VAL (1'b0)
  ) u_sync_spi_miso (
    .clk_i     (clk_i),
    .rst_ni    (rst_n_sync),
    .d_async_i (spi_miso_i),
    .q_sync_o  (spi_miso_sync)
  );

  logic i2c_sda_sync;
  sync_2ff #(
    .WIDTH     (1),
    .RESET_VAL (1'b1) // I2C pulls up to 1
  ) u_sync_i2c_sda (
    .clk_i     (clk_i),
    .rst_ni    (rst_n_sync),
    .d_async_i (i2c_sda_i),
    .q_sync_o  (i2c_sda_sync)
  );

  logic uart_rx_sync;
  sync_2ff #(
    .WIDTH     (1),
    .RESET_VAL (1'b1) // UART idle is 1
  ) u_sync_uart_rx (
    .clk_i     (clk_i),
    .rst_ni    (rst_n_sync),
    .d_async_i (uart_rx_i),
    .q_sync_o  (uart_rx_sync)
  );

  // OBI Bus Synchronizers / Retiming
  logic        obi_req_eff;
  logic        obi_we_eff;
  logic [3:0]  obi_be_eff;
  logic [31:0] obi_addr_eff;
  logic [31:0] obi_wdata_eff;

  generate
    if (SYNC_OBI) begin : gen_obi_sync
      logic        s_req, s_we;
      logic [3:0]  s_be;
      logic [31:0] s_addr, s_wdata;

      sync_2ff #(.WIDTH(1),  .RESET_VAL(1'b0))  u_s_req   (.clk_i(clk_i), .rst_ni(rst_n_sync), .d_async_i(obi_req_i),   .q_sync_o(s_req));
      sync_2ff #(.WIDTH(1),  .RESET_VAL(1'b0))  u_s_we    (.clk_i(clk_i), .rst_ni(rst_n_sync), .d_async_i(obi_we_i),    .q_sync_o(s_we));
      sync_2ff #(.WIDTH(4),  .RESET_VAL(4'h0))  u_s_be    (.clk_i(clk_i), .rst_ni(rst_n_sync), .d_async_i(obi_be_i),    .q_sync_o(s_be));
      sync_2ff #(.WIDTH(32), .RESET_VAL(32'h0)) u_s_addr  (.clk_i(clk_i), .rst_ni(rst_n_sync), .d_async_i(obi_addr_i),  .q_sync_o(s_addr));
      sync_2ff #(.WIDTH(32), .RESET_VAL(32'h0)) u_s_wdata (.clk_i(clk_i), .rst_ni(rst_n_sync), .d_async_i(obi_wdata_i), .q_sync_o(s_wdata));

      assign obi_req_eff   = s_req;
      assign obi_we_eff    = s_we;
      assign obi_be_eff    = s_be;
      assign obi_addr_eff  = s_addr;
      assign obi_wdata_eff = s_wdata;
    end else begin : gen_obi_direct
      assign obi_req_eff   = obi_req_i;
      assign obi_we_eff    = obi_we_i;
      assign obi_be_eff    = obi_be_i;
      assign obi_addr_eff  = obi_addr_i;
      assign obi_wdata_eff = obi_wdata_i;
    end
  endgenerate

  // ---- Power Domain Controls (PD_AON) ----
  logic pg_accel_en, pg_dsp_en, pg_telemetry_en, pg_core_domain_en;
  logic [1:0] fsm_state;
  logic       core_ack;

  // ---- Register Control Signals (PD_AON) ----
  logic        ctrl_soft_en;
  logic        shake_filter_en;
  logic [1:0]  sensor_sel;
  logic        self_test_en;
  logic [1:0]  range_sel;
  logic [15:0] step_threshold;
  logic        fifo_pop;

  // Active Personalization Profile Bank & Feature Statistics Controls (PD_AON)
  xstride_cfg_t cfg_act;
  logic         stat_enable;
  logic         stat_clear;

  // ===========================================================================
  // 3. Mutually Exclusive Sensor Interface Gating (PD_SENSOR)
  // Guarantees SPI and I2C masters never run simultaneously or drive inactive buses.
  // ===========================================================================
  logic spi_en;
  logic i2c_en;
  logic onchip_en;

  assign spi_en    = pg_accel_en && ctrl_soft_en && (sensor_sel == 2'b00);
  assign i2c_en    = pg_accel_en && ctrl_soft_en && (sensor_sel == 2'b01);
  assign onchip_en = pg_accel_en && ctrl_soft_en && (sensor_sel == 2'b10);

  // Raw sensor wires from modules
  logic               spi_valid;
  logic signed [15:0] spi_x, spi_y, spi_z;
  logic               spi_sclk_raw, spi_cs_n_raw, spi_mosi_raw;

  accel_spi_intf #(
    .CLK_DIV             (SPI_CLK_DIV),
    .SAMPLE_PERIOD_CYCLES (SAMPLE_PERIOD_CYCLES)
  ) u_accel_spi (
    .clk_i          (clk_i),
    .rst_ni         (rst_n_sync),
    .en_i           (spi_en),
    .spi_sclk_o     (spi_sclk_raw),
    .spi_cs_no      (spi_cs_n_raw),
    .spi_mosi_o     (spi_mosi_raw),
    .spi_miso_i     (spi_miso_sync),
    .sample_valid_o (spi_valid),
    .accel_x_o      (spi_x),
    .accel_y_o      (spi_y),
    .accel_z_o      (spi_z)
  );

  logic               i2c_valid;
  logic signed [15:0] i2c_x, i2c_y, i2c_z;
  logic               i2c_scl_raw, i2c_scl_oe_raw, i2c_sda_raw, i2c_sda_oe_raw;

  accel_i2c_intf #(
    .CLK_DIV             (I2C_CLK_DIV),
    .SAMPLE_PERIOD_CYCLES (SAMPLE_PERIOD_CYCLES)
  ) u_accel_i2c (
    .clk_i          (clk_i),
    .rst_ni         (rst_n_sync),
    .en_i           (i2c_en),
    .scl_o          (i2c_scl_raw),
    .scl_oe         (i2c_scl_oe_raw),
    .sda_o          (i2c_sda_raw),
    .sda_oe         (i2c_sda_oe_raw),
    .sda_i          (i2c_sda_sync),
    .sample_valid_o (i2c_valid),
    .accel_x_o      (i2c_x),
    .accel_y_o      (i2c_y),
    .accel_z_o      (i2c_z)
  );

  logic               onchip_valid;
  logic signed [15:0] onchip_x, onchip_y, onchip_z;
  logic               onchip_self_test_rdy;

  onchip_mems_sensor #(
    .SAMPLE_PERIOD_CYCLES (SAMPLE_PERIOD_CYCLES),
    .SAR_CYCLES           (14)
  ) u_onchip_mems (
    .clk_i             (clk_i),
    .rst_ni            (rst_n_sync),
    .en_i              (onchip_en),
    .mems_analog_x_i   (mems_analog_x_i),
    .mems_analog_y_i   (mems_analog_y_i),
    .mems_analog_z_i   (mems_analog_z_i),
    .self_test_en_i    (self_test_en),
    .range_sel_i       (range_sel),
    .trim_x_i          (16'sd0),
    .trim_y_i          (16'sd0),
    .trim_z_i          (16'sd0),
    .sample_valid_o    (onchip_valid),
    .accel_x_o         (onchip_x),
    .accel_y_o         (onchip_y),
    .accel_z_o         (onchip_z),
    .self_test_ready_o (onchip_self_test_rdy)
  );

  // External Sensor Output Clamping (Active Low CS clamps High, I2C OE clamps Low)
  assign spi_sclk_o = (spi_en) ? spi_sclk_raw : 1'b0;
  assign spi_cs_no  = (spi_en) ? spi_cs_n_raw  : 1'b1; // Clamp High (inactive)
  assign spi_mosi_o = (spi_en) ? spi_mosi_raw : 1'b0;

  assign i2c_scl_o  = (i2c_en) ? i2c_scl_raw    : 1'b1;
  assign i2c_scl_oe = (i2c_en) ? i2c_scl_oe_raw : 1'b0; // High-Z
  assign i2c_sda_o  = (i2c_en) ? i2c_sda_raw    : 1'b1;
  assign i2c_sda_oe = (i2c_en) ? i2c_sda_oe_raw : 1'b0; // High-Z

  // Unified Sensor Hub (PD_SENSOR)
  logic               hub_valid_raw;
  logic signed [15:0] hub_x_raw, hub_y_raw, hub_z_raw;

  sensor_hub #(
    .DATA_W (16)
  ) u_sensor_hub (
    .clk_i                 (clk_i),
    .rst_ni                (rst_n_sync),
    .sensor_sel_i          (sensor_sel),
    .axis_remap_i          (3'b000),
    .axis_invert_i         (3'b000),
    .spi_sample_valid_i    (spi_valid),
    .spi_accel_x_i         (spi_x),
    .spi_accel_y_i         (spi_y),
    .spi_accel_z_i         (spi_z),
    .i2c_sample_valid_i    (i2c_valid),
    .i2c_accel_x_i         (i2c_x),
    .i2c_accel_y_i         (i2c_y),
    .i2c_accel_z_i         (i2c_z),
    .onchip_sample_valid_i (onchip_valid),
    .onchip_accel_x_i      (onchip_x),
    .onchip_accel_y_i      (onchip_y),
    .onchip_accel_z_i      (onchip_z),
    .direct_sample_valid_i (1'b0),
    .direct_accel_x_i      (16'sd0),
    .direct_accel_y_i      (16'sd0),
    .direct_accel_z_i      (16'sd0),
    .sample_valid_o        (hub_valid_raw),
    .accel_x_o             (hub_x_raw),
    .accel_y_o             (hub_y_raw),
    .accel_z_o             (hub_z_raw)
  );

  // Sensor Calibration Stage (Zero-g Offset & Sensitivity Gain - PD_SENSOR)
  logic               calib_valid_raw;
  logic signed [15:0] calib_x_raw, calib_y_raw, calib_z_raw;

  calib_stage #(
    .DATA_W (16)
  ) u_calib_stage (
    .clk_i          (clk_i),
    .rst_ni         (rst_n_sync),
    .en_i           (pg_accel_en && ctrl_soft_en),
    .sample_valid_i (hub_valid_raw),
    .accel_x_i      (hub_x_raw),
    .accel_y_i      (hub_y_raw),
    .accel_z_i      (hub_z_raw),
    .gain_x_i       (cfg_act.gain_x),
    .gain_y_i       (cfg_act.gain_y),
    .gain_z_i       (cfg_act.gain_z),
    .offset_x_i     (cfg_act.offset_x),
    .offset_y_i     (cfg_act.offset_y),
    .offset_z_i     (cfg_act.offset_z),
    .sample_valid_o (calib_valid_raw),
    .accel_x_o      (calib_x_raw),
    .accel_y_o      (calib_y_raw),
    .accel_z_o      (calib_z_raw)
  );

  // Sensor Isolation Clamps crossing from PD_SENSOR to PD_DSP / PD_AON
  logic               hub_valid_iso;
  logic signed [15:0] hub_x_iso, hub_y_iso, hub_z_iso;

  assign hub_valid_iso = pg_accel_en ? calib_valid_raw : 1'b0;
  assign hub_x_iso     = pg_accel_en ? calib_x_raw     : 16'sd0;
  assign hub_y_iso     = pg_accel_en ? calib_y_raw     : 16'sd0;
  assign hub_z_iso     = pg_accel_en ? calib_z_raw     : 16'sd0;

  // Ultra-Low-Power Motion Wake Comparator (PD_SENSOR / PD_AON)
  // Evaluates raw sensor activity during SLEEP to wake DSP and Core
  logic sensor_motion_detected;
  logic [15:0] abs_hx, abs_hy, abs_hz;
  assign abs_hx = (hub_x_raw[15]) ? -hub_x_raw : hub_x_raw;
  assign abs_hy = (hub_y_raw[15]) ? -hub_y_raw : hub_y_raw;
  assign abs_hz = (hub_z_raw[15]) ? -hub_z_raw : hub_z_raw;

  always_ff @(posedge clk_i or negedge rst_n_sync) begin
    if (!rst_n_sync) begin
      sensor_motion_detected <= 1'b0;
    end else if (pg_accel_en) begin
      if (hub_valid_raw) begin
        sensor_motion_detected <= (abs_hx > 16'd400) || (abs_hy > 16'd400) || (abs_hz > 16'd400);
      end
    end else begin
      sensor_motion_detected <= 1'b0;
    end
  end

  // ===========================================================================
  // 4. DSP Front-End (PD_DSP)
  // ===========================================================================
  logic        motion_detected_raw, feature_ready_raw;
  logic [15:0] feat_mag_raw, feat_zcr_raw, feat_cad_raw;

  dsp_frontend #(
    .WINDOW_SAMPLES (WINDOW_SAMPLES)
  ) u_dsp_frontend (
    .clk_i             (clk_i),
    .rst_ni            (rst_n_sync),
    .en_i              (pg_dsp_en && ctrl_soft_en),
    .sample_valid_i    (hub_valid_iso),
    .accel_x_i         (hub_x_iso),
    .accel_y_i         (hub_y_iso),
    .accel_z_i         (hub_z_iso),
    .motion_th_i       (cfg_act.wake_thresh),
    .iir_shift_i       (cfg_act.iir_shift),
    .win_len_i         (cfg_act.window_len),
    .motion_detected_o (motion_detected_raw),
    .feature_ready_o   (feature_ready_raw),
    .feat_magnitude_o  (feat_mag_raw),
    .feat_zcr_o        (feat_zcr_raw),
    .feat_cadence_o    (feat_cad_raw)
  );

  // ===========================================================================
  // 5. Advanced Pedometer Classifier (PD_DSP)
  // ===========================================================================
  logic [2:0]  activity_class_raw;
  logic        step_pulse_raw, shake_pulse_raw;
  logic [31:0] class_total_steps, class_walk_steps, class_run_steps;
  logic [31:0] class_shake_events, class_shake_duration, class_active_time;
  logic [15:0] cadence_spm_raw;
  logic        app_clear_counters_iso;
  logic [15:0] class_peak_mag_raw;
  logic [15:0] class_step_period_raw;

  pedometer_classifier #(
    .DATA_W (16)
  ) u_pedometer_classifier (
    .clk_i                (clk_i),
    .rst_ni               (rst_n_sync),
    .en_i                 (pg_dsp_en && ctrl_soft_en),
    .sample_valid_i       (hub_valid_iso),
    .accel_x_i            (hub_x_iso),
    .accel_y_i            (hub_y_iso),
    .accel_z_i            (hub_z_iso),
    .feat_magnitude_i     (feat_mag_raw),
    .feat_zcr_i           (feat_zcr_raw),
    .shake_filter_en_i    (shake_filter_en),
    .step_threshold_i     (cfg_act.step_thresh),
    .run_threshold_i      (cfg_act.run_thresh),
    .min_step_period_i    (cfg_act.min_period),
    .max_step_period_i    (cfg_act.max_period),
    .shake_zcr_th_i       (cfg_act.shake_zcr_th),
    .dom_ratio_q4_i       (cfg_act.dom_ratio_q4),
    .dom_floor_i          (cfg_act.dom_floor),
    .lock_cnt_i           (cfg_act.lock_count),
    .cad_num_i            (cfg_act.cadence_num),
    .clear_counters_i     (app_clear_counters_iso),
    .activity_class_o     (activity_class_raw),
    .step_detected_o      (step_pulse_raw),
    .shake_detected_o     (shake_pulse_raw),
    .step_count_total_o   (class_total_steps),
    .step_count_walk_o    (class_walk_steps),
    .step_count_run_o     (class_run_steps),
    .shake_event_count_o  (class_shake_events),
    .shake_duration_sec_o (class_shake_duration),
    .active_time_sec_o    (class_active_time),
    .cadence_spm_o        (cadence_spm_raw),
    .peak_mag_o           (class_peak_mag_raw),
    .step_period_o        (class_step_period_raw)
  );

  // Hardware Biomechanical Feature Statistics Tracker (PD_DSP)
  logic [15:0] stat_mag_min_raw, stat_mag_max_raw;
  logic [15:0] stat_peak_avg_raw, stat_period_avg_raw, stat_zcr_max_raw;

  feature_stats #(
    .DATA_W (16)
  ) u_feature_stats (
    .clk_i             (clk_i),
    .rst_ni            (rst_n_sync),
    .en_i              (pg_dsp_en && ctrl_soft_en),
    .stat_enable_i     (stat_enable),
    .stat_clear_i      (stat_clear),
    .sample_valid_i    (hub_valid_iso),
    .feat_magnitude_i  (feat_mag_raw),
    .feat_zcr_i        (feat_zcr_raw),
    .step_detected_i   (step_pulse_raw),
    .peak_mag_i        (class_peak_mag_raw),
    .step_period_i     (class_step_period_raw),
    .stat_mag_min_o    (stat_mag_min_raw),
    .stat_mag_max_o    (stat_mag_max_raw),
    .stat_peak_avg_o   (stat_peak_avg_raw),
    .stat_period_avg_o (stat_period_avg_raw),
    .stat_zcr_max_o    (stat_zcr_max_raw)
  );

  // Statistics Isolation Clamps crossing from PD_DSP into PD_AON
  logic [15:0] stat_mag_min_iso;
  logic [15:0] stat_mag_max_iso;
  logic [15:0] stat_peak_avg_iso;
  logic [15:0] stat_period_avg_iso;
  logic [15:0] stat_zcr_max_iso;

  assign stat_mag_min_iso    = pg_dsp_en ? stat_mag_min_raw    : 16'h0000;
  assign stat_mag_max_iso    = pg_dsp_en ? stat_mag_max_raw    : 16'h0000;
  assign stat_peak_avg_iso   = pg_dsp_en ? stat_peak_avg_raw   : 16'h0000;
  assign stat_period_avg_iso = pg_dsp_en ? stat_period_avg_raw : 16'h0000;
  assign stat_zcr_max_iso    = pg_dsp_en ? stat_zcr_max_raw    : 16'h0000;

  // DSP & Classifier Output Clamping crossing from PD_DSP into PD_AON
  logic        motion_detected_iso;
  logic        feature_ready_iso;
  logic [15:0] feat_mag_iso, feat_zcr_iso, feat_cad_iso;
  logic [2:0]  activity_class_iso;
  logic        step_pulse_iso, shake_pulse_iso;
  logic [15:0] cadence_spm_iso;

  assign motion_detected_iso = pg_dsp_en ? motion_detected_raw : sensor_motion_detected;
  assign feature_ready_iso   = pg_dsp_en ? feature_ready_raw   : 1'b0;
  assign feat_mag_iso        = pg_dsp_en ? feat_mag_raw        : 16'h0000;
  assign feat_zcr_iso        = pg_dsp_en ? feat_zcr_raw        : 16'h0000;
  assign feat_cad_iso        = pg_dsp_en ? feat_cad_raw        : 16'h0000;
  assign activity_class_iso  = pg_dsp_en ? activity_class_raw  : 3'b000;
  assign step_pulse_iso      = pg_dsp_en ? step_pulse_raw      : 1'b0;
  assign shake_pulse_iso     = pg_dsp_en ? shake_pulse_raw     : 1'b0;
  assign cadence_spm_iso     = pg_dsp_en ? cadence_spm_raw     : 16'h0000;

  // ===========================================================================
  // 6. Non-Volatile / Retained Accumulators in PD_AON
  // These counters live permanently in PD_AON so their values survive when
  // PD_DSP and PD_TELEM are powered completely off.
  // ===========================================================================
  logic [31:0] aon_total_steps_q;
  logic [31:0] aon_walk_steps_q;
  logic [31:0] aon_run_steps_q;
  logic [31:0] aon_shake_events_q;
  logic [31:0] aon_shake_duration_q;

  always_ff @(posedge clk_i or negedge rst_n_sync) begin
    if (!rst_n_sync) begin
      aon_total_steps_q    <= 32'd0;
      aon_walk_steps_q     <= 32'd0;
      aon_run_steps_q      <= 32'd0;
      aon_shake_events_q   <= 32'd0;
      aon_shake_duration_q <= 32'd0;
    end else if (app_clear_counters_iso) begin
      aon_total_steps_q    <= 32'd0;
      aon_walk_steps_q     <= 32'd0;
      aon_run_steps_q      <= 32'd0;
      aon_shake_events_q   <= 32'd0;
      aon_shake_duration_q <= 32'd0;
    end else begin
      if (step_pulse_iso) begin
        aon_total_steps_q <= aon_total_steps_q + 32'd1;
        if (activity_class_iso == 3'd2)
          aon_walk_steps_q <= aon_walk_steps_q + 32'd1;
        else if (activity_class_iso == 3'd3)
          aon_run_steps_q  <= aon_run_steps_q + 32'd1;
      end
      if (shake_pulse_iso) begin
        aon_shake_events_q <= aon_shake_events_q + 32'd1;
      end
      if (activity_class_iso == 3'd1) begin
        aon_shake_duration_q <= aon_shake_duration_q + 32'd1;
      end
    end
  end

  // ===========================================================================
  // 7. Headless Low-Power Mobile App Telemetry Unit (PD_TELEM)
  // ===========================================================================
  logic        uart_tx_raw;
  logic [7:0]  fifo_count_raw;
  logic        fifo_empty_raw, fifo_full_raw;
  logic [31:0] fifo_rdata_raw;
  logic        clear_counters_raw;

  mobile_telemetry_unit #(
    .CLK_FREQ_HZ (CLK_FREQ_HZ),
    .BAUD_RATE   (BAUD_RATE)
  ) u_mobile_telemetry (
    .clk_i                (clk_i),
    .rst_ni               (rst_n_sync),
    .en_i                 (pg_telemetry_en && ctrl_soft_en),
    .step_pulse_i         (step_pulse_iso),
    .shake_pulse_i        (shake_pulse_iso),
    .activity_class_i     (activity_class_iso),
    .step_count_total_i   (aon_total_steps_q),
    .step_count_walk_i    (aon_walk_steps_q),
    .step_count_run_i     (aon_run_steps_q),
    .shake_event_count_i  (aon_shake_events_q),
    .shake_duration_sec_i (aon_shake_duration_q),
    .cadence_spm_i        (cadence_spm_iso),
    .feat_magnitude_i     (feat_mag_iso),
    .uart_tx_o            (uart_tx_raw),
    .uart_rx_i            (uart_rx_sync),
    .mobile_wake_o        (mobile_wake_o),
    .mobile_wake_i        (mobile_wake_sync),
    .stream_en_i          (1'b1),
    .fifo_pop_i           (fifo_pop),
    .fifo_rdata_o         (fifo_rdata_raw),
    .fifo_count_o         (fifo_count_raw),
    .fifo_empty_o         (fifo_empty_raw),
    .fifo_full_o          (fifo_full_raw),
    .clear_counters_o     (clear_counters_raw)
  );

  // Telemetry Output Clamping crossing from PD_TELEM into PD_AON & Pads
  logic [7:0]  fifo_count_iso;
  logic        fifo_empty_iso, fifo_full_iso;
  logic [31:0] fifo_rdata_iso;

  assign uart_tx_o              = pg_telemetry_en ? uart_tx_raw          : 1'b1; // Clamp High (UART idle)
  assign fifo_count_iso         = pg_telemetry_en ? fifo_count_raw     : 8'h00;
  assign fifo_empty_iso         = pg_telemetry_en ? fifo_empty_raw     : 1'b1;
  assign fifo_full_iso          = pg_telemetry_en ? fifo_full_raw      : 1'b0;
  assign fifo_rdata_iso         = pg_telemetry_en ? fifo_rdata_raw     : 32'h0000_0000;
  assign app_clear_counters_iso = pg_telemetry_en ? clear_counters_raw : 1'b0;

  // ===========================================================================
  // 8. Wake & Power Management FSM (PD_AON)
  // ===========================================================================
  wake_fsm #(
    .MOTION_TIMEOUT_CYCLES (MOTION_TIMEOUT_CYCLES)
  ) u_wake_fsm (
    .clk_i               (clk_i),
    .rst_ni              (rst_n_sync),
    .motion_detected_i   (motion_detected_iso),
    .feature_ready_i     (feature_ready_iso),
    .mobile_wake_i       (mobile_wake_sync),
    .core_ack_i          (core_ack),
    .core_irq_o          (core_irq_o),
    .pg_accel_en_o       (pg_accel_en),
    .pg_dsp_en_o         (pg_dsp_en),
    .pg_telemetry_en_o   (pg_telemetry_en),
    .pg_core_domain_en_o (pg_core_domain_en),
    .state_o             (fsm_state)
  );

  // ===========================================================================
  // 9. OBI Register File (PD_AON)
  // ===========================================================================
  xstride_regs_obi #(
    .BASE_ADDR (BASE_ADDR)
  ) u_regs (
    .clk_i                (clk_i),
    .rst_ni               (rst_n_sync),
    .req_i                (obi_req_eff),
    .gnt_o                (obi_gnt_o),
    .addr_i               (obi_addr_eff),
    .we_i                 (obi_we_eff),
    .be_i                 (obi_be_eff),
    .wdata_i              (obi_wdata_eff),
    .rvalid_o             (obi_rvalid_o),
    .rdata_o              (obi_rdata_o),
    .fsm_state_i          (fsm_state),
    .motion_detected_i    (motion_detected_iso),
    .feature_ready_i      (feature_ready_iso),
    .feat_magnitude_i     (feat_mag_iso),
    .feat_zcr_i           (feat_zcr_iso),
    .feat_cadence_i       (feat_cad_iso),
    .tinyml_class_i       ({5'b0, activity_class_iso}),
    .activity_class_i     (activity_class_iso),
    .step_count_total_i   (class_total_steps),
    .step_count_walk_i    (class_walk_steps),
    .step_count_run_i     (class_run_steps),
    .shake_event_count_i  (class_shake_events),
    .shake_duration_sec_i (class_shake_duration),
    .cadence_spm_i        (cadence_spm_iso),
    .accel_x_i            (hub_x_iso),
    .accel_y_i            (hub_y_iso),
    .accel_z_i            (hub_z_iso),
    .fifo_count_i         (fifo_count_iso),
    .fifo_empty_i         (fifo_empty_iso),
    .fifo_full_i          (fifo_full_iso),
    .fifo_rdata_i         (fifo_rdata_iso),
    .core_ack_o           (core_ack),
    .ctrl_soft_en_o       (ctrl_soft_en),
    .shake_filter_en_o    (shake_filter_en),
    .sensor_sel_o         (sensor_sel),
    .self_test_en_o       (self_test_en),
    .range_sel_o          (range_sel),
    .step_threshold_o     (step_threshold),
    .fifo_pop_o           (fifo_pop),
    .sample_valid_i       (hub_valid_raw),
    .cfg_act_o            (cfg_act),
    .stat_enable_o        (stat_enable),
    .stat_clear_o         (stat_clear),
    .stat_mag_min_i       (stat_mag_min_iso),
    .stat_mag_max_i       (stat_mag_max_iso),
    .stat_peak_avg_i      (stat_peak_avg_iso),
    .stat_period_avg_i    (stat_period_avg_iso),
    .stat_zcr_max_i       (stat_zcr_max_iso)
  );

endmodule
