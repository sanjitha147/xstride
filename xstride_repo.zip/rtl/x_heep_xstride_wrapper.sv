// =============================================================================
// x_heep_xstride_wrapper.sv
// X-HEEP Host Platform Wrapper for X-STRIDE Pedometer & Physiological Coprocessor
//
// Bridges the X-STRIDE Always-On Subsystem to the EPFL X-HEEP SoC platform:
//   - Host CPU: CV32E40P RISC-V 32-bit Core (RV32IMC)
//   - Interconnect: Standard Open Bus Interface (OBI) Peripheral Bus
//   - Interrupt Routing: Direct mapping to CV32E40P Fast Interrupt lines (irq_fast_i)
//       * bit 0 (IRQ 16): Core Wake Interrupt (Sleep to Active state transition)
//       * bit 1 (IRQ 17): Physiological Leg-Shake / Fidget Alert (Instant tremor detection)
//       * bit 2 (IRQ 18): Confirmed Gait Stride Pulse (Walking / Running footfall)
//       * bit 3 (IRQ 19): Telemetry BLE FIFO Watermark (FIFO >= 16 words or full)
//   - Power Manager Interface:
//       * Supports autonomous AON operation while CV32E40P core domain is power-gated
//       * Handshakes with X-HEEP Power Manager via req / ack protocol
//       * Provides autonomous asynchronous wakeup assertion (cpu_wakeup_req_o)
// =============================================================================

`timescale 1ns/1ps

module x_heep_xstride_wrapper #(
  parameter logic [31:0] BASE_ADDR             = 32'h2000_0000,
  parameter int unsigned SPI_CLK_DIV           = 8,
  parameter int unsigned I2C_CLK_DIV           = 16,
  parameter int unsigned SAMPLE_PERIOD_CYCLES  = 32'd500_000,
  parameter int unsigned WINDOW_SAMPLES        = 128,
  parameter int unsigned MOTION_TIMEOUT_CYCLES = 32'd50_000,
  parameter int unsigned CLK_FREQ_HZ           = 50_000_000,
  parameter int unsigned BAUD_RATE             = 115200
) (
  // ---------------------------------------------------------------------------
  // System Clock & Reset (From X-HEEP Clock / Reset Controller)
  // ---------------------------------------------------------------------------
  input  logic clk_i,
  input  logic rst_ni,

  // ---------------------------------------------------------------------------
  // X-HEEP OBI Slave Bus Interface (from X-HEEP Peripheral Crossbar)
  // ---------------------------------------------------------------------------
  input  logic        obi_req_i,
  output logic        obi_gnt_o,
  input  logic [31:0] obi_addr_i,
  input  logic        obi_we_i,
  input  logic [3:0]  obi_be_i,
  input  logic [31:0] obi_wdata_i,
  output logic        obi_rvalid_o,
  output logic [31:0] obi_rdata_o,

  // ---------------------------------------------------------------------------
  // CV32E40P Fast Interrupt Vector (irq_fast_o -> connected to core irq_fast_i)
  // ---------------------------------------------------------------------------
  output logic [3:0]  intr_vector_o,

  // ---------------------------------------------------------------------------
  // X-HEEP Power Manager Handshake Interface
  // ---------------------------------------------------------------------------
  input  logic        cpu_powergate_req_i, // X-HEEP PM requests CPU domain sleep
  output logic        cpu_powergate_ack_o, // X-STRIDE AON acknowledges autonomous mode
  output logic        cpu_wakeup_req_o,    // X-STRIDE asserts wakeup pulse to PM

  // ---------------------------------------------------------------------------
  // External Pad / Pin Mappings (Accelerometers & BLE Telemetry)
  // ---------------------------------------------------------------------------
  // External SPI
  output logic        spi_sclk_o,
  output logic        spi_cs_no,
  output logic        spi_mosi_o,
  input  logic        spi_miso_i,

  // External I2C
  output logic        i2c_scl_o,
  output logic        i2c_scl_oe,
  output logic        i2c_sda_o,
  output logic        i2c_sda_oe,
  input  logic        i2c_sda_i,

  // BLE UART Telemetry & Mobile Wake
  output logic        uart_tx_o,
  input  logic        uart_rx_i,
  output logic        mobile_wake_o,
  input  logic        mobile_wake_i,

  // Integrated Differential Capacitive MEMS Sensing Inputs
  input  logic signed [15:0] mems_analog_x_i,
  input  logic signed [15:0] mems_analog_y_i,
  input  logic signed [15:0] mems_analog_z_i
);

  // Address Decoding: Verify request target falls within peripheral window
  localparam logic [31:0] ADDR_MASK = 32'hFFFF_FC00; // 1 KB window
  logic obi_req_qualified;
  assign obi_req_qualified = obi_req_i && ((obi_addr_i & ADDR_MASK) == (BASE_ADDR & ADDR_MASK));

  // Core IRQ wire from X-STRIDE top
  logic xstride_core_irq;

  // ---------------------------------------------------------------------------
  // Instantiation of Always-On X-STRIDE Core Subsystem
  // ---------------------------------------------------------------------------
  xstride_always_on_top #(
    .BASE_ADDR             (BASE_ADDR),
    .SPI_CLK_DIV           (SPI_CLK_DIV),
    .I2C_CLK_DIV           (I2C_CLK_DIV),
    .SAMPLE_PERIOD_CYCLES  (SAMPLE_PERIOD_CYCLES),
    .WINDOW_SAMPLES        (WINDOW_SAMPLES),
    .MOTION_TIMEOUT_CYCLES (MOTION_TIMEOUT_CYCLES),
    .SYNC_OBI              (1'b0), // OBI inputs already synchronous in X-HEEP fabric
    .CLK_FREQ_HZ           (CLK_FREQ_HZ),
    .BAUD_RATE             (BAUD_RATE)
  ) u_xstride_aon (
    .clk_i           (clk_i),
    .rst_ni          (rst_ni),
    .spi_sclk_o      (spi_sclk_o),
    .spi_cs_no       (spi_cs_no),
    .spi_mosi_o      (spi_mosi_o),
    .spi_miso_i      (spi_miso_i),
    .i2c_scl_o       (i2c_scl_o),
    .i2c_scl_oe      (i2c_scl_oe),
    .i2c_sda_o       (i2c_sda_o),
    .i2c_sda_oe      (i2c_sda_oe),
    .i2c_sda_i       (i2c_sda_i),
    .uart_tx_o       (uart_tx_o),
    .uart_rx_i       (uart_rx_i),
    .mobile_wake_o   (mobile_wake_o),
    .mobile_wake_i   (mobile_wake_i),
    .mems_analog_x_i (mems_analog_x_i),
    .mems_analog_y_i (mems_analog_y_i),
    .mems_analog_z_i (mems_analog_z_i),
    .obi_req_i       (obi_req_qualified),
    .obi_gnt_o       (obi_gnt_o),
    .obi_addr_i      (obi_addr_i),
    .obi_we_i        (obi_we_i),
    .obi_be_i        (obi_be_i),
    .obi_wdata_i     (obi_wdata_i),
    .obi_rvalid_o    (obi_rvalid_o),
    .obi_rdata_o     (obi_rdata_o),
    .core_irq_o      (xstride_core_irq)
  );

  // ---------------------------------------------------------------------------
  // Interrupt Vector Generation (Mapped to CV32E40P irq_fast_i[19:16])
  // ---------------------------------------------------------------------------
  logic step_pulse_prev, shake_pulse_prev;
  logic fifo_full_w;
  logic [7:0] fifo_count_w;

  assign fifo_full_w  = u_xstride_aon.fifo_full_iso;
  assign fifo_count_w = u_xstride_aon.fifo_count_iso;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      step_pulse_prev  <= 1'b0;
      shake_pulse_prev <= 1'b0;
      intr_vector_o    <= 4'b0000;
    end else begin
      step_pulse_prev  <= u_xstride_aon.step_pulse_iso;
      shake_pulse_prev <= u_xstride_aon.shake_pulse_iso;

      // [0]: Core Wake / Motion IRQ
      intr_vector_o[0] <= xstride_core_irq;

      // [1]: Leg Shake / Fidget Event Detected
      intr_vector_o[1] <= u_xstride_aon.shake_pulse_iso;

      // [2]: Valid Gait Stride (Walk / Run Footfall)
      intr_vector_o[2] <= u_xstride_aon.step_pulse_iso;

      // [3]: Mobile Telemetry FIFO Watermark (>= 16 words or Full)
      intr_vector_o[3] <= (fifo_count_w >= 8'd16) || fifo_full_w;
    end
  end

  // ---------------------------------------------------------------------------
  // X-HEEP Power Manager Handshake & Sleep Coordination FSM
  // ---------------------------------------------------------------------------
  typedef enum logic [1:0] {
    PM_ACTIVE,
    PM_HANDSHAKE,
    PM_CPU_SLEEP
  } pm_state_e;

  pm_state_e pm_state_q, pm_state_d;
  logic      cpu_pg_ack_q, cpu_pg_ack_d;
  logic      cpu_wake_q, cpu_wake_d;

  always_comb begin
    pm_state_d   = pm_state_q;
    cpu_pg_ack_d = cpu_pg_ack_q;
    cpu_wake_d   = 1'b0;

    case (pm_state_q)
      PM_ACTIVE: begin
        cpu_pg_ack_d = 1'b0;
        if (cpu_powergate_req_i) begin
          pm_state_d   = PM_HANDSHAKE;
          cpu_pg_ack_d = 1'b1;
        end
      end

      PM_HANDSHAKE: begin
        cpu_pg_ack_d = 1'b1;
        if (cpu_powergate_req_i) begin
          pm_state_d = PM_CPU_SLEEP;
        end else begin
          pm_state_d = PM_ACTIVE;
        end
      end

      PM_CPU_SLEEP: begin
        cpu_pg_ack_d = 1'b1;
        // Wakeup condition: X-STRIDE detects motion, tremor, step, or mobile app requests wake
        if (xstride_core_irq || u_xstride_aon.step_pulse_iso ||
            u_xstride_aon.shake_pulse_iso || mobile_wake_i) begin
          cpu_wake_d = 1'b1;
        end
        if (!cpu_powergate_req_i) begin
          pm_state_d   = PM_ACTIVE;
          cpu_pg_ack_d = 1'b0;
        end
      end

      default: pm_state_d = PM_ACTIVE;
    endcase
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      pm_state_q   <= PM_ACTIVE;
      cpu_pg_ack_q <= 1'b0;
      cpu_wake_q   <= 1'b0;
    end else begin
      pm_state_q   <= pm_state_d;
      cpu_pg_ack_q <= cpu_pg_ack_d;
      cpu_wake_q   <= cpu_wake_d;
    end
  end

  assign cpu_powergate_ack_o = cpu_pg_ack_q;
  assign cpu_wakeup_req_o    = cpu_wake_q;

endmodule
